# Boohx_bot

Бот шукає вільні Telegram username довжиною 5–6 символів.

## Як працює перевірка

Фінальне слово про «вільний» завжди за Telegram (MTProto `account.CheckUsernameRequest`).
HTTP-запити (`t.me`, Fragment) — лише **префільтр**, який відсіює зайняті ніки; вони
ніколи самі не роблять нік «вільним».

| Довжина | Шлях |
|---|---|
| 6 літер | кеш → `t.me` → Fragment → **MTProto** (лише для тих, кого префільтр не заперечив) |
| 5 літер | кеш → `t.me` → Fragment → **MTProto** (як для 6; вимкнути: `PREFILTER_5=0`) |

Конвеєр у `username_engine.PipelineScanner` має дві незалежні стадії:

1. **HTTP-воркери** (за замовчуванням 20) — кеш + `t.me` + Fragment, паралельно. Вони не чекають на Telegram.
2. **MTProto-верифікатори** (≈2 на сесію, максимум 8) — єдине місце, де витрачається ліміт `checkUsername`.
   Між стадіями — обмежена черга: коли MTProto зайнятий, HTTP-воркери природно притримуються.

Вердикти `error` / timeout / FloodWait **ніколи** не стають `free`, не кешуються й не показуються.
Без Telethon-сесії результат позначається «не підтверджено» (`unconfirmed`), а не `free`.

Кеш (`checked_cache.db`): `taken`/`invalid`/`fragment`/`auction` — 7 днів, підтверджений `free` — 10 хв,
`error` не кешується.

Під час пошуку бот **не редагує** повідомлення: одне початкове «Скануємо…» і потім фінальний результат.

## 5-літерні ніки: шаблони

Реальні 5-літерні слова в Telegram майже всі зайняті, тому `five_letter.py` шукає гарні вимовні
«слова-схожі» за шаблонами (C = приголосний, V = голосний): `w5_cv` CVCVC (zokel), `w5_cvccv` (tarko),
`w5_vcvcv` (avelo), `w5_cvvcv` (kaizo), `w5_sfx` (zorix, kalyn), `w5_pfx` (luxor, zenix),
`w5_dbl` (bella), `w5_ycv` (karky), `w5_pal` (ABCBA), `w5_abab` (ABABA) + з `words5.txt`:
`w5_mut`, `w5_markov`. Це мільйони комбінацій, пул не вичерпується; вдалі шаблони крутяться частіше
(статистика в `pattern_stats.db`). `words5.txt` необов'язковий (формат `слово оцінка`, оцінка ≥ 4 = «напевно зайняте»).

## Швидкість

Пропускна здатність MTProto = `кількість сесій / TG_VERIFY_INTERVAL`. Більше потоків її не збільшує.
У `bot_config.txt`:

```text
TG_VERIFY_INTERVAL=1.0     # мін. пауза між запитами однієї сесії (не зменшуйте без тесту — ризик FloodWait)
TG_VERIFY_MAX_WAIT=120
TG_VERIFY_TTL_FREE=600
TG_VERIFY_TTL_FINAL=604800
```

Реальний спосіб прискорити — додати власні авторизовані сесії: `SESSION_STRING_2`, `SESSION_STRING_3`, …

## Запуск

1. `pip install -r requirements.txt`
2. Відкрийте `bot_config.txt` (вже лежить поруч, порожній) і заповніть `BOT_TOKEN`, `OWNER_ID`,
   а для MTProto — `API_ID`, `API_HASH`, `SESSION_STRING` (`python make_session.py`).
3. `python main.py`  (Windows: `run.bat`)

> Файл має називатися саме `bot_config.txt`. Якщо він раптом став `bot_config.txt.example`:
> `ren bot_config.txt.example bot_config.txt`

## База користувачів

Архів уже містить `boohx_uqoza_max_v24.db` з перенесеними користувачами зі старого Boohx_bot-22.
Щоб повторити/оновити міграцію зі свого старого файлу:

```text
python migrate_old_db.py <шлях_до_старої_boohx_uqoza_max_v24.db>
```

Скрипт лише читає стару базу, перед змінами робить `*.bak-<час>`, ідемпотентний і переносить тільки дані
людей (users, спроби, Premium, реферали, платежі, знайдені ніки, watchlist, партнери, канали).

## Тести

`python -m unittest -v`

Не комітьте `bot_config.txt`, `session_string.txt`, `*.db`, логи.
