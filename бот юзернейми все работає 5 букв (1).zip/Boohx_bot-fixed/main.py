import os
import sys
import time
import random
import secrets
import sqlite3
import logging
import threading
import re
import base64
import atexit
import concurrent.futures
from datetime import datetime, timedelta
from typing import List, Dict, Optional, Any, Tuple

import requests
from bs4 import BeautifulSoup
import telebot
from telebot import types

# ── BOOHX Smart Engine ────────────────────────────────────────────────────────
from username_engine import (
    find_free_username_fast, check_single,
    parallel_check_list, get_shared_cache,
)
import tg_verify   # авторитетна перевірка через MTProto (Telethon)
# Один спільний кеш на весь процес (ніколи не перевіряємо одне ім'я двічі)

# ==============================================================================
# БЛОК 1: КОНФИГУРАЦИЯ
# ==============================================================================
_BASE_DIR = os.path.dirname(os.path.abspath(__file__))
_ENGINE_CACHE = get_shared_cache(db_dir=_BASE_DIR)  # спільний кеш для всього бота

logging.basicConfig(
    level=logging.INFO,
    format='[%(asctime)s] [%(levelname)s] [%(name)s] %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler(os.path.join(_BASE_DIR, 'boohx_proxy_core.log'), encoding='utf-8')
    ]
)
logger = logging.getLogger("BOOHX_Core")

# Позначка для результатів без підтвердження через Telegram (сесія не налаштована)
UNCONFIRMED_NOTE = {
    "ua": "⚠️ не підтверджено через Telegram",
    "ru": "⚠️ не подтверждено через Telegram",
    "en": "⚠️ not confirmed via Telegram",
}


def _load_bot_config() -> Dict[str, str]:
    cfg: Dict[str, str] = {}
    path = os.path.join(_BASE_DIR, "bot_config.txt")
    if not os.path.exists(path):
        return cfg
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, val = line.split("=", 1)
            cfg[key.strip()] = val.strip()
    return cfg


_CFG = _load_bot_config()

BOT_TOKEN = os.environ.get("BOT_TOKEN") or _CFG.get("BOT_TOKEN", "")
if not BOT_TOKEN or ":" not in BOT_TOKEN:
    logger.critical("[INIT] BOT_TOKEN не задан! Додайте у bot_config.txt або змінну BOT_TOKEN.")
    sys.exit(1)

bot = telebot.TeleBot(BOT_TOKEN, parse_mode=None)

OWNER_ID    = int(os.environ.get("OWNER_ID") or _CFG.get("OWNER_ID") or "8689285693")

# Вайтліст: ID через кому у bot_config.txt → WHITELIST_IDS=123,456,789
_raw_wl = _CFG.get("WHITELIST_IDS", "")
WHITELIST_IDS: list[int] = []
for _wid in _raw_wl.split(","):
    _wid = _wid.strip()
    if _wid.lstrip("-").isdigit():
        WHITELIST_IDS.append(int(_wid))

DB_FILE     = os.path.join(_BASE_DIR, "boohx_uqoza_max_v24.db")
OUTPUT_FILE = os.path.join(_BASE_DIR, "free_found.txt")
SUPPORT_USER = "@sefice"
TON_RATE    = float(_CFG.get("TON_RATE", "6.20"))
TON_WALLET  = _CFG.get("TON_WALLET", "UQAkRRWR4XBuIW2Qc5QJSRvgyV44krtbY7nru6Lq95bajRPC")

# Cooldown між сканами (секунди). Free = 15с, Premium = 5с.
SCAN_COOLDOWN_SEC         = int(_CFG.get("SCAN_COOLDOWN_SEC",         "15"))
SCAN_COOLDOWN_PREMIUM_SEC = int(_CFG.get("SCAN_COOLDOWN_PREMIUM_SEC", "5"))

# Реклама: посилання та нагорода за перегляд
AD_LINK            = _CFG.get("AD_LINK", "https://t.me/boohx_promo")
AD_REWARD_ATTEMPTS = int(_CFG.get("AD_REWARD_ATTEMPTS", "3"))
AD_COOLDOWN_HOURS  = int(_CFG.get("AD_COOLDOWN_HOURS", "24"))

# Максимум нікнеймів у /scan (free / premium)
MULTI_SCAN_LIMIT_FREE    = 5
MULTI_SCAN_LIMIT_PREMIUM = 20

# Антіспам для @username перевірок (секунди між запитами)
AT_CHECK_COOLDOWN_SEC = 10

# Канал, на який обов'язково потрібна підписка
REQUIRED_CHANNEL = "@boohx"

# ── Підключаємо модуль перевірки підписки ─────────────────────────────────────
import channel_guard as _cg
_cg.REQUIRED_CHANNEL = REQUIRED_CHANNEL

# Семафор — не більше 3 одночасних сканів від free-юзерів
_FREE_SCAN_SEMAPHORE = threading.Semaphore(3)

# Антіспам для @username
_at_check_times: Dict[int, float] = {}
_at_check_lock = threading.Lock()


def _acquire_single_instance_lock() -> bool:
    """Запобігає запуску двох копій бота (причина помилки 409)."""
    lock_path = os.path.join(_BASE_DIR, ".boohx_bot.lock")
    try:
        fd = os.open(lock_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        os.write(fd, str(os.getpid()).encode())
        os.close(fd)

        def _release():
            try:
                os.remove(lock_path)
            except OSError:
                pass

        atexit.register(_release)
        return True
    except FileExistsError:
        try:
            with open(lock_path, encoding="utf-8") as f:
                pid = f.read().strip()
        except OSError:
            pid = "?"
        logger.critical(
            f"[INIT] Бот вже запущений (PID {pid}). "
            "Зупиніть інший процес перед новим запуском."
        )
        return False


if not _acquire_single_instance_lock():
    sys.exit(1)

# Ініціалізуємо вайтліст: OWNER_ID завжди + WHITELIST_IDS з конфігу
_cg.init_guard(owner_id=OWNER_ID, extra_ids=WHITELIST_IDS)


def is_subscribed_to_channel(user_id: int) -> bool:
    """Обгортка навколо channel_guard.check_subscription.
    Повертає True якщо підписаний АБО у вайтліст АБО API недоступний."""
    result = _cg.check_subscription(bot, user_id)
    # None = API недоступний → fail-open (пропускаємо)
    return result is not False


def send_subscribe_prompt(chat_id: int, lang: str) -> None:
    """Делегуємо у channel_guard."""
    _cg.send_subscribe_prompt(bot, chat_id, lang)


# Premium тарифи
PREMIUM_PLANS = {
    "1m": {"ton": 1.0, "days": 30,  "label_ua": "1 місяць",   "label_ru": "1 месяц",   "label_en": "1 Month"},
    "3m": {"ton": 2.5, "days": 90,  "label_ua": "3 місяці",   "label_ru": "3 месяца",  "label_en": "3 Months"},
    "lf": {"ton": 5.0, "days": 0,   "label_ua": "Назавжди",   "label_ru": "Навсегда",  "label_en": "Lifetime"},
}
MIN_PLAN_TON = min(p["ton"] for p in PREMIUM_PLANS.values())

BRAND_PREFIXES = ["lo","ga","zi","ku","rk","so","ma","fe","bo","pa","za","le","re","wi","ca","tu","ne","ve","de","be"]
BRAND_CORES    = ["s","w","h","p","a","o","u","i","e","z","x","c","v","b","n","m","r","t","k","l"]
BRAND_SUFFIXES = ["zi","fi","cu","fo","qu","ox","co","do","ix","on","ro","to","za","zo","va","ra","li","me","no","ki"]

# ==============================================================================
# БЛОК 2: МОВНІ ПАКЕТИ
# ==============================================================================
LANG_PACKS: Dict[str, Dict[str, str]] = {
    "ua": {
        "welcome": (
            "👋 *Ласкаво просимо до BOOHX!*\n\n"
            "🔍 Знаходимо вільні ніки у Telegram та Fragment.\n"
            "💎 5-літерні ніки — тільки для Premium-користувачів!\n\n"
            "Оберіть дію нижче:"
        ),
        "btn_search":   "🔍 Пошук вільних ніків",
        "btn_profile":  "👤 Мій Профіль",

        "btn_giveaway": "🎁 Розіграші",
        "btn_donate":   "💎 Premium / Донат",
        "btn_help":     "❓ Допомога",
        "btn_watch":    "👁 Watchlist",
        "select_len":   "🎛 Оберіть довжину юзернейма для сканування:",
        "len_5":        "📝 5 Літер (Premium)",
        "len_6":        "📝 6 Літер (Безкоштовно)",
        "no_attempts":  "❌ Спроби вичерпано! Запросіть друзів або придбайте Premium.",
        "scanning":     "⏳ Скануємо, це може тривати трохи довше...",
        "not_found":    "😔 Вільних варіантів не знайдено. Спробуйте ще раз!",
        "premium_alert":"🛑 Пошук на 5 літер — тільки для PREMIUM!",
        "cooldown":     "⏱ Зачекайте ще {sec} сек. перед наступним скануванням.",
        "profile_card": (
            "📋 *ТВІЙ ПРОФІЛЬ BOOHX:*\n"
            "├ ID: `{user_id}`\n"
            "├ Статус: *{status}*\n"
            "├ Premium до: *{premium_until}*\n"
            "├ Спроби: *{attempts}*\n"
            "├ Сканувань: *{scans}*\n"
            "└ Друзів: *{referrals}*\n\n"
            "🔗 *Реферальне посилання (+5 спроб):*\n`{ref_link}`"
        ),
        "status_owner":   "Власник 👑",
        "status_premium": "Premium 💎",
        "status_free":    "Безкоштовний 🆓",
        "donate_menu": (
            "💎 *BOOHX Premium*\n\n"
            "🚀 *Що дає Premium:*\n"
            "• Пошук 5-літерних ніків\n"
            "• Необмежені спроби\n"
            "• Без cooldown між сканами\n"
            "• Пріоритетна підтримка\n\n"
            "💰 *Тарифи:*\n"
            "• 🥉 1 місяць — **1 TON** (~${usd_1m})\n"
            "• 🥈 3 місяці — **2.5 TON** (~${usd_3m})\n"
            "• 🏆 Назавжди — **5 TON** (~${usd_lf})\n\n"
            "Або задонатьте будь-яку суму 🙏"
        ),
        "premium_invoice": (
            "📋 *Інструкція з оплати — {plan_label}*\n\n"
            "1️⃣ Відкрийте TON-гаманець (Tonkeeper / MyTonWallet)\n"
            "2️⃣ Відправте **{ton} TON** на:\n`{wallet}`\n\n"
            "3️⃣ У полі *Коментар / Memo* вкажіть ТОЧНО:\n`{memo}`\n\n"
            "⚠️ *Без коментаря активація неможлива!*\n"
            "⏳ Активація — автоматично за 1–2 хвилини."
        ),
        "premium_activated": (
            "🎉 *PREMIUM АКТИВОВАНО!*\n\n"
            "✅ План: {plan}\n"
            "📅 Діє до: {until}\n\n"
            "Тепер доступний пошук 5-літерних ніків!"
        ),
        "already_premium": "💎 Premium активний до {until}!",
        "help_text": (
            "❓ *ДОПОМОГА BOOHX*\n\n"
            "━━━━━━━━━━━━━━━━━\n"
            "📌 *ОСНОВНІ КОМАНДИ:*\n\n"
            "🎲 /scan — знайти випадковий вільний нік\n"
            "🔍 /find слово — пошук ніків з твоїм словом 💎 Premium\n"
            "   Приклад: `/find ton` → tonbo, zaton, ratonki...\n"
            "   🔠 6 літер: шаблон *приголосний-голосний×3* (CVCVCV)\n"
            "   🗣 5 літер: покращений рандом зі складами\n"
            "🤖 /nickai слово — AI крипто-ніки тільки з літер 💎 Premium\n"
            "   Приклад: `/nickai ton` → tonvault, darkton, gemton...\n"
            "📋 /scan @n1 @n2 — перевірити свої ніки (до 5 free / 20 premium)\n"
            "👤 /mystats — мій профіль (спроби, статус, реферали)\n"
            "🔎 /profile — повний профіль зі знайденими ніками\n"
            "👥 /myref — список запрошених друзів\n"
            "📊 /stats — статистика бота 💎 Premium\n"
            "💸 /ad — переглянь рекламу → отримай +{ad_r} спроб\n"
            "❓ /help — ця довідка\n\n"
            "━━━━━━━━━━━━━━━━━\n"
            "👁 *WATCHLIST (стежити за ніком):*\n\n"
            "/watch @username — додати нік до списку спостереження\n"
            "/unwatch @username — видалити нік зі списку\n"
            "/watchlist — переглянути весь список\n"
            "💡 Або просто надішліть @username — бот сам все зробить!\n\n"
            "━━━━━━━━━━━━━━━━━\n"
            "🔠 *ПАТЕРНИ ПОШУКУ:*\n\n"
            "• 6 літер: CVCVCV — легко вимовляються, коштують більше\n"
            "  Приклад: *to-mi-ka*, *bo-la-re*, *za-re-lo*\n"
            "• 5 літер: CVCVC + складові слова\n"
            "  Приклад: *tonik*, *balko*, *razme*\n\n"
            "━━━━━━━━━━━━━━━━━\n"
            "💎 *PREMIUM:*\n\n"
            "• /find — пошук ніків зі своїм словом + CVCVCV патерн\n"
            "• /nickai — AI крипто-ніки (тільки літери, будь-яка довжина)\n"
            "• Пошук 5-літерних ніків (рідкісні!)\n"
            "• Необмежені спроби, без затримки між сканами\n"
            "• Watchlist: необмежено ніків (free — до 3)\n\n"
            "━━━━━━━━━━━━━━━━━\n"
            f"📞 Підтримка: {SUPPORT_USER}\n"
            f"💰 TON-гаманець:\n`UQAkRRWR4XBuIW2Qc5QJSRvgyV44krtbY7nru6Lq95bajRPC`"
        ),
        "watch_added":        "👁 *@{nick}* додано до Watchlist!\n📬 Повідомлю як тільки стане вільним.",
        "watch_exists":       "⚠️ *@{nick}* вже у вашому Watchlist.",
        "watch_limit":        "❌ Ліміт досягнуто! Free: до 3 нікнеймів, Premium: необмежено.",
        "watch_removed":      "✅ *@{nick}* видалено з Watchlist.",
        "watch_not_found":    "⚠️ *@{nick}* не знайдено у вашому Watchlist.",
        "watch_empty":        "📋 Ваш Watchlist порожній.\nДодайте: /watch @username",
        "watch_list_header":  "👁 *Ваш Watchlist* ({count} нік(ів)):\n\n",
        "watch_check_now":    "🔍 Миттєва перевірка *@{nick}*...",
        "watch_is_free":      "✅ *@{nick}* — ВІЛЬНИЙ! Реєструйте зараз:\n🔗 [Fragment](https://fragment.com/@{nick}) · [Telegram](https://t.me/{nick})",
        "watch_is_taken":     "🔒 *@{nick}* — зайнятий.",
        "watch_notify":       "🔔 *ВІЛЬНИЙ НІК!*\n\n`@{nick}` щойно став вільним!\n🔗 [Fragment](https://fragment.com/@{nick}) · [Telegram](https://t.me/{nick})",
        "watch_status_free":  "✅ вільний",
        "watch_status_taken": "🔒 зайнятий",
        "watch_usage":        "📝 Використання: /watch @username\nАбо просто надішліть @username",
        "scan_usage":         "📝 Використання: `/scan @nick1 @nick2 ...`\nМаксимум: {limit} нікнеймів.",
        "scan_header":        "🔍 *Масова перевірка* ({count} нік(ів)):\n\n",
        "scan_row_free":      "✅ `@{nick}` — вільний",
        "scan_row_taken":     "🔒 `@{nick}` — зайнятий",
        "scan_row_auction":   "⚡ `@{nick}` — аукціон ({price})",
        "scan_row_unknown":   "❓ `@{nick}` — невідомо",
        "scan_running":       "⏳ Перевіряю {count} нікнеймів...",
        "stats_premium_only": "🛑 Статистика знахідок — тільки для *Premium* користувачів!",
        "stats_text": (
            "📊 *Статистика BOOHX:*\n\n"
            "🆕 Знайдено сьогодні: *{today}*\n"
            "📅 За тиждень: *{week}*\n"
            "📦 Всього: *{total}*\n\n"
            "👥 Користувачів: *{users}*\n"
            "💎 Premium: *{premium}*"
        ),
        "ad_text": (
            "💸 *Переглянь рекламу — отримай +{reward} спроб!*\n\n"
            "1️⃣ Натисни кнопку нижче\n"
            "2️⃣ Перейди за посиланням\n"
            "3️⃣ Повернись і натисни *✅ Отримати*\n\n"
            "⏱ Доступно раз на {hours} год."
        ),
        "ad_claimed":         "✅ +{reward} спроб нараховано! Тепер у вас: {total}",
        "ad_cooldown":        "⏱ Наступна реклама доступна через {hours} год.",
        "ad_btn_view":        "🔗 Переглянути рекламу",
        "ad_btn_claim":       "✅ Отримати спроби",
        "myref_empty":        "👥 Ви ще нікого не запросили.\n🔗 Ваше посилання:\n`{ref_link}`",
        "myref_header":       "👥 *Ваші реферали* ({count}):\n\n",
        "sell_nick_btn":      "💰 Продати нік адміну",
        "sell_nick_sent":     "✅ Заявку на продаж `@{nick}` надіслано адміністратору!",
        "banned_msg":         "🚫 Ваш акаунт заблокований. Зверніться до підтримки: {support}",
        "at_cooldown":        "⏱ Зачекайте {sec} сек. між перевірками.",
        "btn_change_lang":    "🌐 Змінити мову",
        "lang_change_prompt": "🌐 Оберіть мову / Select language / Выберите язык:",
        "giveaway_active":    "🎉 *РОЗІГРАШ!*\nПриз: {prize} спроб.\nНатисніть кнопку нижче!",
        "giveaway_no_active": "😔 Активних розіграшів немає. Слідкуйте за оновленнями!",
        "giveaway_btn_join":  "🎉 Взяти участь!",
        "giveaway_joined":    "🎉 Ви в списку учасників! Бажаємо удачі!",
        "giveaway_already":   "⚠️ Ви вже зареєстровані або розіграш неактивний.",
        "watch_footer":       "\n📝 /watch @username — додати\n🗑 /unwatch @username — видалити",
        "winner_msg":         "🎉 Ви виграли {prize} спроб! Вітаємо!",
        "btn_nick_details":   "🔍 Детальніше",
        "nick_details_title": "📋 *ДЕТАЛЬНА ІНФОРМАЦІЯ* про `@{nick}`\n\n",
        "nick_similar_header":"🔗 *Схожі ніки на Fragment:*\n",
        "nick_liquidity":     "💧 *Ліквідність:* {level}\n",
        "nick_sell_time":     "⏱ *Орієнтовний час продажу:* {days}\n",
        "nick_demand":        "📈 *Попит:* {demand}\n",
        "profile_search_title":  "🔍 *Профіль користувача* `{user_id}`:\n\n",
        "profile_found_nicks":   "🎯 *Знайдені ніки ({count}):*\n",
        "profile_watchlist":     "👁 *Watchlist ({count}):*\n",
        "profile_not_found":     "❌ Користувача `{user_id}` не знайдено в базі.",
        "profile_no_nicks":      "📭 Ще не знаходив ніків.",
        "profile_no_watchlist":  "📭 Watchlist порожній.",
        "cmd_profile_usage":     "📝 Використання:\n`/profile` — свій профіль\n`/profile <user_id>` — профіль іншого (тільки для адміна)",
        "profile_admin_only":    "🛑 Перегляд чужих профілів — тільки для адміністраторів.",
        "profile_channels":      "📢 *Канали ({count}):*\n",
        "profile_no_channels":   "📢 Немає доданих каналів.",
        "profile_add_channel_btn": "➕ Додати юз каналу",
        "channel_add_instructions": (
            "📢 *Як додати юз свого каналу до профілю:*\n\n"
            "1️⃣ Відкрий свій Telegram-канал → Адміністратори\n"
            "2️⃣ Додай `@{bot_username}` як адміністратора\n"
            "   *(достатньо права «Публікація повідомлень»)*\n\n"
            "✅ Після додавання юз каналу автоматично з'явиться у твоєму профілі.\n"
            "🌟 Понтуйся своїм юзом!"
        ),
        "channel_added_notify": "✅ Канал `@{username}` *({title})* доданий до твого профілю! 🎉",
    },
    "ru": {
        "welcome": (
            "👋 *Добро пожаловать в BOOHX!*\n\n"
            "🔍 Находим свободные ники в Telegram и Fragment.\n"
            "💎 5-буквенные ники — только для Premium!\n\n"
            "Выберите действие ниже:"
        ),
        "btn_search":   "🔍 Поиск свободных ников",
        "btn_profile":  "👤 Мой Профиль",

        "btn_giveaway": "🎁 Розыгрыши",
        "btn_donate":   "💎 Premium / Донат",
        "btn_help":     "❓ Помощь",
        "btn_watch":    "👁 Watchlist",
        "select_len":   "🎛 Выберите длину юзернейма для сканирования:",
        "len_5":        "📝 5 Букв (Premium)",
        "len_6":        "📝 6 Букв (Бесплатно)",
        "no_attempts":  "❌ Попытки закончились! Пригласите друзей или купите Premium.",
        "scanning":     "⏳ Сканируем, это может занять немного времени...",
        "not_found":    "😔 Свободных вариантов нет. Попробуйте ещё раз!",
        "premium_alert":"🛑 Поиск на 5 букв — только для PREMIUM!",
        "cooldown":     "⏱ Подождите ещё {sec} сек. перед следующим сканированием.",
        "profile_card": (
            "📋 *ТВОЙ ПРОФИЛЬ BOOHX:*\n"
            "├ ID: `{user_id}`\n"
            "├ Статус: *{status}*\n"
            "├ Premium до: *{premium_until}*\n"
            "├ Попытки: *{attempts}*\n"
            "├ Сканирований: *{scans}*\n"
            "└ Друзей: *{referrals}*\n\n"
            "🔗 *Реферальная ссылка (+5 попыток):*\n`{ref_link}`"
        ),
        "status_owner":   "Владелец 👑",
        "status_premium": "Premium 💎",
        "status_free":    "Бесплатный 🆓",
        "donate_menu": (
            "💎 *BOOHX Premium*\n\n"
            "🚀 *Что даёт Premium:*\n"
            "• Поиск 5-буквенных ников\n"
            "• Неограниченные попытки\n"
            "• Без cooldown между сканами\n"
            "• Приоритетная поддержка\n\n"
            "💰 *Тарифы:*\n"
            "• 🥉 1 месяц — **1 TON** (~${usd_1m})\n"
            "• 🥈 3 месяца — **2.5 TON** (~${usd_3m})\n"
            "• 🏆 Навсегда — **5 TON** (~${usd_lf})\n\n"
            "Или задонатьте любую сумму 🙏"
        ),
        "premium_invoice": (
            "📋 *Инструкция по оплате — {plan_label}*\n\n"
            "1️⃣ Откройте TON-кошелёк (Tonkeeper / MyTonWallet)\n"
            "2️⃣ Отправьте **{ton} TON** на:\n`{wallet}`\n\n"
            "3️⃣ В поле *Комментарий / Memo* укажите ТОЧНО:\n`{memo}`\n\n"
            "⚠️ *Без комментария активация невозможна!*\n"
            "⏳ Активация — автоматически за 1–2 минуты."
        ),
        "premium_activated": (
            "🎉 *PREMIUM АКТИВИРОВАН!*\n\n"
            "✅ План: {plan}\n"
            "📅 Действует до: {until}\n\n"
            "Теперь доступен поиск 5-буквенных ников!"
        ),
        "already_premium": "💎 Premium активен до {until}!",
        "help_text": (
            "❓ *ПОМОЩЬ BOOHX*\n\n"
            "━━━━━━━━━━━━━━━━━\n"
            "📌 *ОСНОВНЫЕ КОМАНДЫ:*\n\n"
            "🎲 /scan — найти случайный свободный ник\n"
            "🔍 /find слово — поиск ников с твоим словом 💎 Premium\n"
            "   Пример: `/find ton` → tonpro, mytons, legalton...\n"
            "🤖 /nickai слово — AI крипто-ники только из букв 💎 Premium\n"
            "   Пример: `/nickai ton` → tonvault, darkton, gemton...\n"
            "📋 /scan @n1 @n2 — проверить свои ники (до 5 free / 20 premium)\n"
            "👤 /mystats — мой профиль (попытки, статус, рефералы)\n"
            "🔎 /profile — полный профиль с найденными никами\n"
            "👥 /myref — список приглашённых друзей\n"
            "📊 /stats — статистика бота 💎 Premium\n"
            "💸 /ad — посмотри рекламу → получи +{ad_r} попыток\n"
            "❓ /help — эта справка\n\n"
            "━━━━━━━━━━━━━━━━━\n"
            "👁 *WATCHLIST (следить за ником):*\n\n"
            "/watch @username — добавить ник в список наблюдения\n"
            "/unwatch @username — удалить ник из списка\n"
            "/watchlist — посмотреть весь список\n"
            "💡 Или просто отправь @username — бот всё сделает сам!\n\n"
            "━━━━━━━━━━━━━━━━━\n"
            "💎 *PREMIUM:*\n\n"
            "• /find — ники с твоим словом внутри\n"
            "• /nickai — AI крипто-ники (только буквы, любая длина)\n"
            "• Поиск 5-буквенных ников (редкие!)\n"
            "• Неограниченные попытки, без задержки\n"
            "• Watchlist: без ограничений (free — до 3)\n\n"
            "━━━━━━━━━━━━━━━━━\n"
            f"📞 Поддержка: {SUPPORT_USER}\n"
            f"💰 TON-кошелёк:\n`UQAkRRWR4XBuIW2Qc5QJSRvgyV44krtbY7nru6Lq95bajRPC`"
        ),
        "watch_added":        "👁 *@{nick}* добавлен в Watchlist!\n📬 Уведомлю как только освободится.",
        "watch_exists":       "⚠️ *@{nick}* уже в вашем Watchlist.",
        "watch_limit":        "❌ Лимит достигнут! Free: до 3 ников, Premium: неограниченно.",
        "watch_removed":      "✅ *@{nick}* удалён из Watchlist.",
        "watch_not_found":    "⚠️ *@{nick}* не найден в вашем Watchlist.",
        "watch_empty":        "📋 Ваш Watchlist пуст.\nДобавьте: /watch @username",
        "watch_list_header":  "👁 *Ваш Watchlist* ({count} ник(ов)):\n\n",
        "watch_check_now":    "🔍 Мгновенная проверка *@{nick}*...",
        "watch_is_free":      "✅ *@{nick}* — СВОБОДЕН! Регистрируйте сейчас:\n🔗 [Fragment](https://fragment.com/@{nick}) · [Telegram](https://t.me/{nick})",
        "watch_is_taken":     "🔒 *@{nick}* — занят.",
        "watch_notify":       "🔔 *НИК СВОБОДЕН!*\n\n`@{nick}` только что освободился!\n🔗 [Fragment](https://fragment.com/@{nick}) · [Telegram](https://t.me/{nick})",
        "watch_status_free":  "✅ свободен",
        "watch_status_taken": "🔒 занят",
        "watch_usage":        "📝 Использование: /watch @username\nИли просто отправьте @username",
        "scan_usage":         "📝 Использование: `/scan @nick1 @nick2 ...`\nМаксимум: {limit} ников.",
        "scan_header":        "🔍 *Массовая проверка* ({count} ник(ов)):\n\n",
        "scan_row_free":      "✅ `@{nick}` — свободен",
        "scan_row_taken":     "🔒 `@{nick}` — занят",
        "scan_row_auction":   "⚡ `@{nick}` — аукцион ({price})",
        "scan_row_unknown":   "❓ `@{nick}` — неизвестно",
        "scan_running":       "⏳ Проверяю {count} ников...",
        "stats_premium_only": "🛑 Статистика находок — только для *Premium* пользователей!",
        "stats_text": (
            "📊 *Статистика BOOHX:*\n\n"
            "🆕 Найдено сегодня: *{today}*\n"
            "📅 За неделю: *{week}*\n"
            "📦 Всего: *{total}*\n\n"
            "👥 Пользователей: *{users}*\n"
            "💎 Premium: *{premium}*"
        ),
        "ad_text": (
            "💸 *Посмотри рекламу — получи +{reward} попыток!*\n\n"
            "1️⃣ Нажми кнопку ниже\n"
            "2️⃣ Перейди по ссылке\n"
            "3️⃣ Вернись и нажми *✅ Получить*\n\n"
            "⏱ Доступно раз в {hours} ч."
        ),
        "ad_claimed":         "✅ +{reward} попыток начислено! Теперь у вас: {total}",
        "ad_cooldown":        "⏱ Следующая реклама доступна через {hours} ч.",
        "ad_btn_view":        "🔗 Посмотреть рекламу",
        "ad_btn_claim":       "✅ Получить попытки",
        "myref_empty":        "👥 Вы ещё никого не пригласили.\n🔗 Ваша ссылка:\n`{ref_link}`",
        "myref_header":       "👥 *Ваши рефералы* ({count}):\n\n",
        "sell_nick_btn":      "💰 Продать ник админу",
        "sell_nick_sent":     "✅ Заявка на продажу `@{nick}` отправлена администратору!",
        "banned_msg":         "🚫 Ваш аккаунт заблокирован. Обратитесь в поддержку: {support}",
        "at_cooldown":        "⏱ Подождите {sec} сек. между проверками.",
        "btn_change_lang":    "🌐 Изменить язык",
        "lang_change_prompt": "🌐 Оберіть мову / Select language / Выберите язык:",
        "giveaway_active":    "🎉 *РОЗЫГРЫШ!*\nПриз: {prize} попыток.\nНажмите кнопку ниже!",
        "giveaway_no_active": "😔 Активных розыгрышей нет. Следите за обновлениями!",
        "giveaway_btn_join":  "🎉 Участвовать!",
        "giveaway_joined":    "🎉 Вы в списке участников! Удачи!",
        "giveaway_already":   "⚠️ Вы уже зарегистрированы или розыгрыш неактивен.",
        "watch_footer":       "\n📝 /watch @username — добавить\n🗑 /unwatch @username — удалить",
        "winner_msg":         "🎉 Вы выиграли {prize} попыток! Поздравляем!",
        "btn_nick_details":   "🔍 Подробнее",
        "nick_details_title": "📋 *ПОДРОБНАЯ ИНФОРМАЦИЯ* о `@{nick}`\n\n",
        "nick_similar_header":"🔗 *Похожие ники на Fragment:*\n",
        "nick_liquidity":     "💧 *Ликвидность:* {level}\n",
        "nick_sell_time":     "⏱ *Ориентировочное время продажи:* {days}\n",
        "nick_demand":        "📈 *Спрос:* {demand}\n",
        "profile_search_title":  "🔍 *Профиль пользователя* `{user_id}`:\n\n",
        "profile_found_nicks":   "🎯 *Найденные ники ({count}):*\n",
        "profile_watchlist":     "👁 *Watchlist ({count}):*\n",
        "profile_not_found":     "❌ Пользователь `{user_id}` не найден в базе.",
        "profile_no_nicks":      "📭 Ещё не находил ников.",
        "profile_no_watchlist":  "📭 Watchlist пуст.",
        "cmd_profile_usage":     "📝 Использование:\n`/profile` — свой профиль\n`/profile <user_id>` — профиль другого (только для админа)",
        "profile_admin_only":    "🛑 Просмотр чужих профилей — только для администраторов.",
        "profile_channels":      "📢 *Каналы ({count}):*\n",
        "profile_no_channels":   "📢 Нет добавленных каналов.",
        "profile_add_channel_btn": "➕ Добавить юз канала",
        "channel_add_instructions": (
            "📢 *Как добавить юз своего канала в профиль:*\n\n"
            "1️⃣ Открой свой Telegram-канал → Администраторы\n"
            "2️⃣ Добавь `@{bot_username}` как администратора\n"
            "   *(достаточно права «Публикация сообщений»)*\n\n"
            "✅ После добавления юз канала автоматически появится в твоём профиле.\n"
            "🌟 Понтуйся своим юзом!"
        ),
        "channel_added_notify": "✅ Канал `@{username}` *({title})* добавлен в твой профиль! 🎉",
    },
    "en": {
        "welcome": (
            "👋 *Welcome to BOOHX!*\n\n"
            "🔍 We find free usernames on Telegram & Fragment.\n"
            "💎 5-letter usernames require Premium!\n\n"
            "Select an action below:"
        ),
        "btn_search":   "🔍 Search Free Names",
        "btn_profile":  "👤 My Profile",

        "btn_giveaway": "🎁 Giveaways",
        "btn_donate":   "💎 Premium / Donate",
        "btn_help":     "❓ Help",
        "btn_watch":    "👁 Watchlist",
        "select_len":   "🎛 Select username length for scanning:",
        "len_5":        "📝 5 Letters (Premium)",
        "len_6":        "📝 6 Letters (Free)",
        "no_attempts":  "❌ Out of attempts! Invite friends or get Premium.",
        "scanning":     "⏳ Scanning, this may take a little while...",
        "not_found":    "😔 No free variants found. Try again!",
        "premium_alert":"🛑 5-letter search is PREMIUM only!",
        "cooldown":     "⏱ Wait {sec} more seconds before the next scan.",
        "profile_card": (
            "📋 *YOUR BOOHX PROFILE:*\n"
            "├ ID: `{user_id}`\n"
            "├ Status: *{status}*\n"
            "├ Premium until: *{premium_until}*\n"
            "├ Attempts: *{attempts}*\n"
            "├ Total scans: *{scans}*\n"
            "└ Friends: *{referrals}*\n\n"
            "🔗 *Referral Link (+5 attempts):*\n`{ref_link}`"
        ),
        "status_owner":   "Owner 👑",
        "status_premium": "Premium 💎",
        "status_free":    "Free 🆓",
        "donate_menu": (
            "💎 *BOOHX Premium*\n\n"
            "🚀 *Premium benefits:*\n"
            "• 5-letter username search\n"
            "• Unlimited scan attempts\n"
            "• No cooldown between scans\n"
            "• Priority support\n\n"
            "💰 *Plans:*\n"
            "• 🥉 1 Month — **1 TON** (~${usd_1m})\n"
            "• 🥈 3 Months — **2.5 TON** (~${usd_3m})\n"
            "• 🏆 Lifetime — **5 TON** (~${usd_lf})\n\n"
            "Or donate any amount 🙏"
        ),
        "premium_invoice": (
            "📋 *Payment Instructions — {plan_label}*\n\n"
            "1️⃣ Open your TON wallet (Tonkeeper / MyTonWallet)\n"
            "2️⃣ Send **{ton} TON** to:\n`{wallet}`\n\n"
            "3️⃣ In the *Comment / Memo* field enter EXACTLY:\n`{memo}`\n\n"
            "⚠️ *Comment is required — no activation without it!*\n"
            "⏳ Activation happens automatically within 1–2 minutes."
        ),
        "premium_activated": (
            "🎉 *PREMIUM ACTIVATED!*\n\n"
            "✅ Plan: {plan}\n"
            "📅 Valid until: {until}\n\n"
            "5-letter username search is now unlocked!"
        ),
        "already_premium": "💎 Premium active until {until}!",
        "help_text": (
            "❓ *BOOHX HELP*\n\n"
            "━━━━━━━━━━━━━━━━━\n"
            "📌 *COMMANDS:*\n\n"
            "🎲 /scan — find a random free username\n"
            "🔍 /find word — search nicks containing your word 💎 Premium\n"
            "   Example: `/find ton` → tonbo, zaton, ratonki...\n"
            "   🔠 6-letter: *consonant-vowel×3* pattern (CVCVCV)\n"
            "   🗣 5-letter: improved random with syllables\n"
            "🤖 /nickai word — AI crypto nicks, letters only 💎 Premium\n"
            "   Example: `/nickai ton` → tonvault, darkton, gemton...\n"
            "📋 /scan @n1 @n2 — check specific nicks (up to 5 free / 20 premium)\n"
            "👤 /mystats — my profile (attempts, status, referrals)\n"
            "🔎 /profile — full profile with found usernames\n"
            "👥 /myref — list of invited friends\n"
            "📊 /stats — bot statistics 💎 Premium\n"
            "💸 /ad — watch an ad → get +{ad_r} attempts\n"
            "❓ /help — this help page\n\n"
            "━━━━━━━━━━━━━━━━━\n"
            "👁 *WATCHLIST (monitor a username):*\n\n"
            "/watch @username — add a nick to watch list\n"
            "/unwatch @username — remove a nick from list\n"
            "/watchlist — view your full list\n"
            "💡 Or just send @username — the bot handles it!\n\n"
            "━━━━━━━━━━━━━━━━━\n"
            "💎 *PREMIUM:*\n\n"
            "• /find — nicks with your word inside\n"
            "• /nickai — AI crypto nicks (letters only, any length)\n"
            "• 5-letter username search (rare & valuable!)\n"
            "• Unlimited attempts, no cooldown\n"
            "• Watchlist: unlimited nicks (free — up to 3)\n\n"
            "━━━━━━━━━━━━━━━━━\n"
            f"📞 Support: {SUPPORT_USER}\n"
            f"💰 TON Wallet:\n`UQAkRRWR4XBuIW2Qc5QJSRvgyV44krtbY7nru6Lq95bajRPC`"
        ),
        "watch_added":        "👁 *@{nick}* added to Watchlist!\n📬 I'll notify you when it becomes free.",
        "watch_exists":       "⚠️ *@{nick}* is already in your Watchlist.",
        "watch_limit":        "❌ Limit reached! Free: up to 3 usernames, Premium: unlimited.",
        "watch_removed":      "✅ *@{nick}* removed from Watchlist.",
        "watch_not_found":    "⚠️ *@{nick}* not found in your Watchlist.",
        "watch_empty":        "📋 Your Watchlist is empty.\nAdd one: /watch @username",
        "watch_list_header":  "👁 *Your Watchlist* ({count} username(s)):\n\n",
        "watch_check_now":    "🔍 Instant check *@{nick}*...",
        "watch_is_free":      "✅ *@{nick}* — FREE! Register now:\n🔗 [Fragment](https://fragment.com/@{nick}) · [Telegram](https://t.me/{nick})",
        "watch_is_taken":     "🔒 *@{nick}* — taken.",
        "watch_notify":       "🔔 *USERNAME FREE!*\n\n`@{nick}` just became available!\n🔗 [Fragment](https://fragment.com/@{nick}) · [Telegram](https://t.me/{nick})",
        "watch_status_free":  "✅ free",
        "watch_status_taken": "🔒 taken",
        "watch_usage":        "📝 Usage: /watch @username\nOr just send @username",
        "scan_usage":         "📝 Usage: `/scan @nick1 @nick2 ...`\nMax: {limit} usernames.",
        "scan_header":        "🔍 *Bulk Check* ({count} username(s)):\n\n",
        "scan_row_free":      "✅ `@{nick}` — free",
        "scan_row_taken":     "🔒 `@{nick}` — taken",
        "scan_row_auction":   "⚡ `@{nick}` — auction ({price})",
        "scan_row_unknown":   "❓ `@{nick}` — unknown",
        "scan_running":       "⏳ Checking {count} username(s)...",
        "stats_premium_only": "🛑 Stats are available for *Premium* users only!",
        "stats_text": (
            "📊 *BOOHX Statistics:*\n\n"
            "🆕 Found today: *{today}*\n"
            "📅 This week: *{week}*\n"
            "📦 All time: *{total}*\n\n"
            "👥 Users: *{users}*\n"
            "💎 Premium: *{premium}*"
        ),
        "ad_text": (
            "💸 *Watch an ad — get +{reward} attempts!*\n\n"
            "1️⃣ Click the button below\n"
            "2️⃣ Follow the link\n"
            "3️⃣ Come back and press *✅ Claim*\n\n"
            "⏱ Available once every {hours} hrs."
        ),
        "ad_claimed":         "✅ +{reward} attempts added! You now have: {total}",
        "ad_cooldown":        "⏱ Next ad available in {hours} hrs.",
        "ad_btn_view":        "🔗 View Ad",
        "ad_btn_claim":       "✅ Claim Attempts",
        "myref_empty":        "👥 You haven't invited anyone yet.\n🔗 Your link:\n`{ref_link}`",
        "myref_header":       "👥 *Your Referrals* ({count}):\n\n",
        "sell_nick_btn":      "💰 Sell nick to admin",
        "sell_nick_sent":     "✅ Sell request for `@{nick}` sent to admin!",
        "banned_msg":         "🚫 Your account is banned. Contact support: {support}",
        "at_cooldown":        "⏱ Wait {sec}s between checks.",
        "btn_change_lang":    "🌐 Change Language",
        "lang_change_prompt": "🌐 Оберіть мову / Select language / Выберите язык:",
        "giveaway_active":    "🎉 *GIVEAWAY!*\nPrize: {prize} attempts.\nClick the button below!",
        "giveaway_no_active": "😔 No active giveaways. Stay tuned for updates!",
        "giveaway_btn_join":  "🎉 Join Giveaway!",
        "giveaway_joined":    "🎉 You're in the giveaway! Good luck!",
        "giveaway_already":   "⚠️ You're already registered or the giveaway is inactive.",
        "watch_footer":       "\n📝 /watch @username — add\n🗑 /unwatch @username — remove",
        "winner_msg":         "🎉 You won {prize} attempts! Congratulations!",
        "btn_nick_details":   "🔍 More Details",
        "nick_details_title": "📋 *DETAILED INFO* about `@{nick}`\n\n",
        "nick_similar_header":"🔗 *Similar usernames on Fragment:*\n",
        "nick_liquidity":     "💧 *Liquidity:* {level}\n",
        "nick_sell_time":     "⏱ *Estimated sell time:* {days}\n",
        "nick_demand":        "📈 *Demand:* {demand}\n",
        "profile_search_title":  "🔍 *Profile of user* `{user_id}`:\n\n",
        "profile_found_nicks":   "🎯 *Found usernames ({count}):*\n",
        "profile_watchlist":     "👁 *Watchlist ({count}):*\n",
        "profile_not_found":     "❌ User `{user_id}` not found in database.",
        "profile_no_nicks":      "📭 No usernames found yet.",
        "profile_no_watchlist":  "📭 Watchlist is empty.",
        "cmd_profile_usage":     "📝 Usage:\n`/profile` — your own profile\n`/profile <user_id>` — another user's profile (admin only)",
        "profile_admin_only":    "🛑 Viewing other profiles is for administrators only.",
        "profile_channels":      "📢 *Channels ({count}):*\n",
        "profile_no_channels":   "📢 No channels added.",
        "profile_add_channel_btn": "➕ Add channel username",
        "channel_add_instructions": (
            "📢 *How to add your channel username to your profile:*\n\n"
            "1️⃣ Open your Telegram channel → Administrators\n"
            "2️⃣ Add `@{bot_username}` as an administrator\n"
            "   *(only 'Post Messages' permission is needed)*\n\n"
            "✅ Once added, your channel's username will appear in your profile automatically.\n"
            "🌟 Flex your username!"
        ),
        "channel_added_notify": "✅ Channel `@{username}` *({title})* added to your profile! 🎉",
    }
}

if not os.path.exists(OUTPUT_FILE):
    with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
        f.write("# BOOHX Free Found Logs\n")

logger.info("[INIT] Блок 1: конфіг та мовні пакети завантажено.")

# ==============================================================================
# БЛОК 3: ПРОКСІ-РУШІЙ
# ==============================================================================
RAW_PROXIES: List[str] = []

class ProxyRotator:
    def __init__(self, lst: List[str]):
        self.proxies: List[Dict] = self._fmt(lst)
        self.lock = threading.Lock()

    def _fmt(self, lst):
        out = []
        for p in lst:
            p = p.strip()
            if not p: continue
            if not p.startswith(("http://","https://","socks5://","socks4://")):
                p = f"http://{p}"
            out.append({"http": p, "https": p})
        return out

    def get(self) -> Optional[Dict]:
        with self.lock:
            return random.choice(self.proxies) if self.proxies else None

    def mark_dead(self, d: Dict):
        with self.lock:
            if d in self.proxies:
                self.proxies.remove(d)

proxy_manager = ProxyRotator(RAW_PROXIES)

USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/122.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 Chrome/121.0.0.0 Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X) AppleWebKit/605.1.15 Mobile/15E148 Safari/604.1",
]

logger.info("[INIT] Блок 2: проксі-рушій.")

# ==============================================================================
# БЛОК 3b: АНАЛІЗАТОР ЯКОСТІ НІКНЕЙМІВ
# ==============================================================================
class NickQualityAnalyzer:
    VOWELS     = set("aeiou")
    CONSONANTS = set("bcdfghjklmnpqrstvwxyz")
    # Популярні 2-літерні початки брендів
    BRAND_START = {"go","my","up","on","ai","io","ex","ox","in","be","we","us","do"}
    # Популярні закінчення
    BRAND_END   = {"ly","fy","io","co","ai","me","app","hub","lab","bit","bot","net","pro"}

    @classmethod
    def analyze(cls, nick: str) -> Dict:
        nick = nick.lower().lstrip("@")
        score = 0
        details = []

        # 1. Довжина
        ln = len(nick)
        if   ln == 4: score += 45; details.append(("📏", f"4 символи — рідкість! +45"))
        elif ln == 5: score += 35; details.append(("📏", f"5 символів — преміум! +35"))
        elif ln == 6: score += 20; details.append(("📏", f"6 символів +20"))
        elif ln == 7: score += 10; details.append(("📏", f"7 символів +10"))
        else:         score +=  5; details.append(("📏", f"{ln} символів +5"))

        # 2. Тільки літери (без цифр/підкреслень)
        if nick.isalpha():
            score += 15
            details.append(("🔤", "Тільки літери +15"))

        # 3. Вимовність (чергування голосних-приголосних)
        vowel_count = sum(1 for c in nick if c in cls.VOWELS)
        cons_count  = ln - vowel_count
        if 0 < vowel_count < ln:
            cons_runs = [
                len(list(g)) for k, g in
                __import__("itertools").groupby(nick, lambda c: c in cls.CONSONANTS)
                if k
            ]
            max_cons_run = max(cons_runs) if cons_runs else 0
            if max_cons_run <= 2:
                score += 20
                details.append(("🗣", "Легко вимовляється +20"))
            else:
                score += 5
                details.append(("🗣", "Складно вимовляється +5"))
        else:
            details.append(("🗣", "Не вимовляється +0"))

        # 4. Брендовий початок/кінець
        for n in range(2, 4):
            if nick[:n] in cls.BRAND_START or nick[-n:] in cls.BRAND_END:
                score += 10
                details.append(("🏷", "Брендовий паттерн +10"))
                break

        # 5. Відсутність повторів
        if len(set(nick)) >= ln * 0.7:
            score += 5
            details.append(("✨", "Унікальні символи +5"))

        # Оцінка
        if   score >= 80: grade = "A+"; stars = "⭐⭐⭐⭐⭐"
        elif score >= 65: grade = "A";  stars = "⭐⭐⭐⭐"
        elif score >= 45: grade = "B";  stars = "⭐⭐⭐"
        elif score >= 25: grade = "C";  stars = "⭐⭐"
        else:             grade = "D";  stars = "⭐"

        # Орієнтовна вартість (реалістична, на основі реальних даних Fragment)
        # Базові ціни за довжину + множник якості
        base_ranges = {
            4: (400, 1200),   # 4-символи: дуже рідкісні, 400–1200 TON
            5: (60,  300),    # 5-символів: 60–300 TON
            6: (8,   60),     # 6-символів: 8–60 TON
            7: (2,   15),     # 7-символів: 2–15 TON
        }
        lo, hi = base_ranges.get(ln, (1, 8))
        quality_ratio = score / 100.0
        value_ton = round(lo + (hi - lo) * quality_ratio)
        value_usd = int(value_ton * TON_RATE)

        return {
            "score": score,
            "grade": grade,
            "stars": stars,
            "details": details,
            "value_ton": value_ton,
            "value_usd": value_usd,
            "length": ln,
        }

    @classmethod
    def grade_bar(cls, score: int) -> str:
        filled = min(10, int(score / 10))
        return "█" * filled + "░" * (10 - filled)


# ==============================================================================
# БЛОК 4: ДВОЕТАПНА ПЕРЕВІРКА (TELEGRAM + FRAGMENT) + ПАРАЛЕЛЬНИЙ ПОШУК
# ==============================================================================
class HighSpeedNetworkChecker:

    @staticmethod
    def _check_telegram(username: str, proxy: Optional[Dict]) -> Optional[bool]:
        url = f"https://t.me/{username}"
        try:
            r = requests.get(
                url,
                headers={"User-Agent": random.choice(USER_AGENTS)},
                proxies=proxy,
                timeout=2.0,
                allow_redirects=True,
            )
            if r.status_code == 429:
                return None
            if r.status_code == 404:
                return True
            if r.status_code != 200:
                return None
            html = r.text
            # Найнадійніші сигнали зайнятості
            if "tgme_page_photo" in html:          # аватар — є у всіх зайнятих
                return False
            if "tgme_page_action_button" in html:  # кнопка Join/Send/Open
                return False
            if "tgme_page_extra" in html:          # підписники/учасники
                return False
            if "tgme_widget" in html:              # вбудований widget
                return False
            soup = BeautifulSoup(html, "html.parser")
            meta = soup.find("meta", property="og:description")
            if meta and len(meta.get("content", "").strip()) > 5:
                return False
            og_title = soup.find("meta", property="og:title")
            if og_title:
                t = og_title.get("content", "")
                if "@" in t or (t.strip() and t.strip().lower() not in ("telegram", "")):
                    return False
            return True
        except Exception:
            return None

    @staticmethod
    def _parse_fragment_html(html: str) -> Dict:
        """Розбирає HTML Fragment — покращений парсер v2.
        Підтримує: auction, free, taken, buy_now ціну, auction_ends час.
        Намагається витягти дані з 4 джерел: CSS-класи, OpenGraph, JSON-LD, regex.
        """
        empty = {
            "status": "unknown",
            "auction_price": None,
            "auction_bids": None,
            "auction_ends": None,
            "buy_now": None,
        }
        result = dict(empty)
        low = html.lower()

        # ── 1. CSS-класи (найнадійніші) ─────────────────────────────────────
        soup = BeautifulSoup(html, "lxml")

        # Статус через окремі span-класи
        _status_map = {
            "tm-status-avail":    "free",
            "tm-status-unavail":  "taken",
            "tm-status-taken":    "taken",
            "tm-status-sale":     "free",      # "Available for sale"
        }
        for cls_name, st in _status_map.items():
            tag = soup.find(class_=cls_name)
            if tag:
                txt = tag.get_text(strip=True).lower()
                if "auction" in txt:
                    result["status"] = "auction"
                elif "available" in txt or "sale" in txt or cls_name in ("tm-status-avail", "tm-status-sale"):
                    result["status"] = "free"
                else:
                    result["status"] = st
                break

        # Auction-блок → завжди auction
        if soup.find(class_="tm-auction") or soup.find(class_="tm-auction-info"):
            result["status"] = "auction"

        # Buy-username секція → free (продається без аукціону)
        if soup.find(class_="tm-section-buy-username") or soup.find(id="buy-username-btn"):
            if result["status"] == "unknown":
                result["status"] = "free"

        # ── 2. Текстові сигнали у HTML ───────────────────────────────────────
        if result["status"] == "unknown":
            if any(s in low for s in ("an auction for this username", "place a bid", "place bid", "current bid")):
                result["status"] = "auction"
            elif any(s in low for s in ("username taken", ".t.me taken", "already claimed",
                                         "has been purchased", "js-unavailable-text", "tm-section-unavail")):
                result["status"] = "taken"
            elif any(s in low for s in ("tm-status-avail", "available for", "buy for", "buy now")):
                result["status"] = "free"

        # ── 3. Ціни ─────────────────────────────────────────────────────────
        # Auction price
        for sel in ("tm-auction-price", "tm-section-auction-price",
                    "tm-auction-bid-value", "tm-section-header-value"):
            tag = soup.find(class_=sel)
            if tag:
                result["auction_price"] = tag.get_text(strip=True)
                break

        # Buy-now price (окрема від auction)
        buy_tag = soup.find(class_="tm-section-buy-price") or soup.find(class_="tm-buy-price")
        if buy_tag:
            result["buy_now"] = buy_tag.get_text(strip=True)

        # Regex fallback для ціни
        if not result["auction_price"] and not result["buy_now"]:
            ton_matches = re.findall(r"([\d\s,]+(?:\.\d+)?)\s*TON", html, re.I)
            for m in ton_matches:
                price_str = m.strip().replace(" ", "").replace(",", "")
                try:
                    val = float(price_str)
                    if val > 0:
                        formatted = f"{val:g} TON"
                        if result["status"] == "auction":
                            result["auction_price"] = result["auction_price"] or formatted
                        else:
                            result["buy_now"] = result["buy_now"] or formatted
                        break
                except ValueError:
                    continue

        # ── 4. Кількість ставок ──────────────────────────────────────────────
        bids_tag = (soup.find(class_="tm-auction-bids")
                    or soup.find(class_="tm-auction-bids-count"))
        if bids_tag:
            result["auction_bids"] = bids_tag.get_text(strip=True)
        else:
            m = re.search(r"(\d+)\s+bid", html, re.I)
            if m:
                result["auction_bids"] = m.group(1)

        # ── 5. Auction ends ──────────────────────────────────────────────────
        ends_tag = (soup.find(class_="tm-auction-ends")
                    or soup.find(class_="tm-auction-timer")
                    or soup.find(attrs={"data-end": True}))
        if ends_tag:
            # Час може бути в атрибуті data-end або в тексті
            ts = ends_tag.get("data-end") or ends_tag.get("data-timestamp")
            if ts:
                try:
                    result["auction_ends"] = datetime.fromtimestamp(int(ts)).strftime("%d.%m.%Y %H:%M")
                except Exception:
                    result["auction_ends"] = ts
            else:
                result["auction_ends"] = ends_tag.get_text(strip=True) or None

        # ── 6. JSON-LD / meta OG як останній засіб ───────────────────────────
        if result["status"] == "unknown":
            ld = soup.find("script", type="application/ld+json")
            if ld:
                try:
                    import json as _json
                    data = _json.loads(ld.string or "{}")
                    desc = str(data.get("description", "")).lower()
                    if "available" in desc:
                        result["status"] = "free"
                    elif "taken" in desc or "unavailable" in desc:
                        result["status"] = "taken"
                except Exception:
                    pass

            og_desc = soup.find("meta", property="og:description")
            if og_desc:
                d = (og_desc.get("content") or "").lower()
                if "available" in d:
                    result["status"] = "free"
                elif "taken" in d or "unavailable" in d:
                    result["status"] = "taken"
                elif "auction" in d:
                    result["status"] = "auction"

        return result

    @staticmethod
    def _check_fragment(username: str, proxy: Optional[Dict]) -> Dict:
        """Повна перевірка Fragment — 3 методи, від швидкого до детального.

        Метод 0: JSON API  → найшвидший, повертає структурований результат.
        Метод 1: /username/{nick} legacy endpoint (302 = free, 200 = розбираємо HTML).
        Метод 2: /@{nick} публічна сторінка — найповніший HTML (ціна, ставки, таймер).
        """
        empty = {
            "status": "unknown",
            "auction_price": None,
            "auction_bids": None,
            "auction_ends": None,
            "buy_now": None,
        }
        headers_html = {
            "User-Agent": random.choice(USER_AGENTS),
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.9",
            "Cache-Control": "no-cache",
            "Referer": "https://fragment.com/",
        }
        headers_json = {
            "User-Agent": random.choice(USER_AGENTS),
            "Accept": "application/json, text/javascript, */*; q=0.01",
            "X-Requested-With": "XMLHttpRequest",
            "Referer": f"https://fragment.com/@{username}",
        }

        # ── Метод 0: Fragment JSON API ────────────────────────────────────────
        try:
            r0 = requests.post(
                "https://fragment.com/api",
                data={
                    "method": "searchAuctions",
                    "query": username,
                    "filter": "username",
                },
                headers=headers_json,
                proxies=proxy,
                timeout=4.0,
            )
            if r0.status_code == 200:
                import json as _json
                try:
                    data = r0.json()
                    auctions = data.get("auctions") or []
                    for item in auctions:
                        item_name = (item.get("username") or "").lower().lstrip("@")
                        if item_name == username.lower():
                            state = str(item.get("state", "")).lower()
                            res = dict(empty)
                            if state in ("active", "auction"):
                                res["status"] = "auction"
                                price = item.get("price")
                                if price:
                                    res["auction_price"] = f"{price} TON"
                                bids = item.get("bids")
                                if bids:
                                    res["auction_bids"] = str(bids)
                                ends = item.get("end_date") or item.get("date_end")
                                if ends:
                                    try:
                                        res["auction_ends"] = datetime.fromtimestamp(int(ends)).strftime("%d.%m.%Y %H:%M")
                                    except Exception:
                                        res["auction_ends"] = str(ends)
                            elif state in ("sold", "taken", "unavailable"):
                                res["status"] = "taken"
                            elif state in ("available", "sale"):
                                res["status"] = "free"
                                buy = item.get("buy_price") or item.get("price")
                                if buy:
                                    res["buy_now"] = f"{buy} TON"
                            if res["status"] != "unknown":
                                return res
                except Exception:
                    pass
        except Exception:
            pass

        # ── Метод 1: legacy endpoint (/username/{nick}) ───────────────────────
        try:
            r1 = requests.get(
                f"https://fragment.com/username/{username}",
                headers=headers_html,
                proxies=proxy,
                timeout=4.0,
                allow_redirects=False,
            )
            if r1.status_code in (403, 429):
                logger.debug("[Fragment] Rate-limited on /username/%s", username)
                time.sleep(1.0)
                return {**empty, "status": None}
            if r1.status_code in (302, 404):
                # 302 = redirect → не продається там → free
                return {**empty, "status": "free"}
            if r1.status_code == 200:
                parsed = HighSpeedNetworkChecker._parse_fragment_html(r1.text)
                if parsed["status"] != "unknown":
                    return parsed
        except Exception:
            pass

        # ── Метод 2: публічна @-сторінка (найдетальніша) ─────────────────────
        try:
            r2 = requests.get(
                f"https://fragment.com/@{username}",
                headers=headers_html,
                proxies=proxy,
                timeout=5.0,
                allow_redirects=True,
            )
            if r2.status_code in (403, 429):
                return {**empty, "status": None}
            if r2.status_code == 404:
                return {**empty, "status": "free"}
            if r2.status_code != 200:
                return empty
            return HighSpeedNetworkChecker._parse_fragment_html(r2.text)
        except Exception:
            return empty

    @staticmethod
    def _check_fragment_quick(username: str, proxy: Optional[Dict]) -> Dict:
        """Швидка перевірка Fragment — тільки /username/{nick}, 2.0s timeout.
        Використовується в scan-циклі для підтвердження TG-вільного ніку."""
        empty: Dict = {"status": "unknown", "auction_price": None,
                       "auction_bids": None, "auction_ends": None, "buy_now": None}
        headers = {
            "User-Agent": random.choice(USER_AGENTS),
            "Accept": "text/html,application/xhtml+xml,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.9",
        }
        try:
            r = requests.get(
                f"https://fragment.com/username/{username}",
                headers=headers,
                proxies=proxy,
                timeout=2.0,
                allow_redirects=False,
            )
            if r.status_code in (403, 429):
                return {**empty, "status": None}
            if r.status_code == 302:
                return {**empty, "status": "free"}
            if r.status_code == 404:
                return {**empty, "status": "free"}
            if r.status_code == 200:
                return HighSpeedNetworkChecker._parse_fragment_html(r.text)
        except Exception:
            pass
        return empty

    @staticmethod
    def _is_fragment_free(frag: Dict, tg_free: bool) -> bool:
        st = frag.get("status", "unknown")
        if st == "free":
            return True
        if st in ("taken", "auction"):
            return False
        # Fragment не відповів → це НЕ «вільний». Остаточно вирішує tg_verify.
        return False

    @classmethod
    def check_availability(cls, username: str, fast: bool = False) -> Tuple[str, Dict]:
        """
        ЄДИНА точка рішення «вільний/ні» для main.py.
        Повертає (status, frag):
          'free'        — ПІДТВЕРДЖЕНО через Telegram (MTProto checkUsername)
          'unconfirmed' — префільтр (t.me + Fragment) не заперечує, але сесія
                          Telegram не налаштована → показуємо з ⚠️
          'taken' | 'invalid' | 'fragment' — не вільний
          'error'       — не вдалося визначити (НЕ вільний)

        Швидкі перевірки (t.me, Fragment) — лише префільтр; MTProto — фінал.
        fast=True: без ретраїв, коротші очікування (для scan-циклу).
        """
        empty: Dict = {"status": "unknown", "auction_price": None,
                       "auction_bids": None, "auction_ends": None, "buy_now": None}
        username = username.strip().lower().lstrip("@")
        if not re.fullmatch(r"[a-z][a-z0-9_]{3,31}", username):
            return "invalid", empty

        configured = tg_verify.is_configured()
        proxy = proxy_manager.get()

        # Швидкий шлях для 6-літерних кандидатів (scan-цикл): паралельний HTTP-префільтр
        # t.me → Fragment відсіює зайняті / виставлені на Fragment ніки, щоб дорогий
        # MTProto-слот (≈1 запит/с на сесію) витрачався лише на тих, кого префільтр
        # не заперечив. Префільтр ЛИШЕ відсіює — «вільний» підтверджує тільки MTProto.
        # Збій префільтра (None / unknown) не означає «вільний»: кандидат просто йде далі.
        if configured and fast and len(username) == 6:
            tg_fast = cls._check_telegram(username, proxy)
            if tg_fast is False:
                return "taken", empty
            frag_pre = cls._check_fragment_quick(username, proxy)
            if frag_pre.get("status") in ("taken", "auction"):
                return "taken", frag_pre

        # MTProto checkUsername — авторитетне джерело. Fragment перевіряється
        # лише після успішного результату для деталей.
        if configured:
            verdict = tg_verify.verify_username_telegram(
                username, max_wait=20.0 if fast else None)
            if verdict == "free":
                frag = (cls._check_fragment_quick(username, proxy) if fast
                        else cls._check_fragment(username, proxy))
                return verdict, frag
            return verdict, empty

        # ── Префільтр 1: t.me ────────────────────────────────────────────────
        tg: Optional[bool] = None
        for _ in range(1 if fast else 3):
            tg = cls._check_telegram(username, proxy)
            if tg is not None:
                break
            if proxy:
                proxy_manager.mark_dead(proxy)
            proxy = proxy_manager.get()
            time.sleep(0.3 if fast else 0.5)
        if tg is False:                   # профіль на t.me → точно зайнятий
            return "taken", empty
        if tg is None and not configured:  # перевірити нічим
            return "error", empty

        # ── Префільтр 2: Fragment (unknown/None → перепитуємо) ───────────────
        frag = dict(empty)
        if tg is True:
            for _ in range(1 if fast else 3):
                got = (cls._check_fragment_quick(username, proxy) if fast
                       else cls._check_fragment(username, proxy))
                if got.get("status") is None:       # rate-limit
                    if proxy:
                        proxy_manager.mark_dead(proxy)
                    proxy = proxy_manager.get()
                    time.sleep(0.3 if fast else 0.5)
                    continue
                frag = got
                if frag.get("status") in ("free", "taken", "auction"):
                    break
                time.sleep(0.2)
            if frag.get("status") in ("taken", "auction"):
                return "taken", frag

        # ── ФІНАЛ: MTProto ───────────────────────────────────────────────────
        if configured:
            verdict = tg_verify.verify_username_telegram(
                username, max_wait=20.0 if fast else None)
            return verdict, frag          # free|taken|invalid|fragment|error
        return "unconfirmed", frag

    @classmethod
    def is_username_free(cls, username: str) -> bool:
        """Повна перевірка для /scan і watchlist. True = 'free' (підтверджено)
        або 'unconfirmed' (сесії нема — виклик check_availability, щоб показати ⚠️)."""
        status, _ = cls.check_availability(username, fast=False)
        return status in ("free", "unconfirmed")

    @classmethod
    def is_username_free_fast(cls, username: str) -> bool:
        """Швидка версія для scan-циклу (без ретраїв). Та сама семантика «вільного»."""
        status, _ = cls.check_availability(username, fast=True)
        return status in ("free", "unconfirmed")

    @classmethod
    def parallel_find_free(
        cls,
        candidates: List[str],
        chat_id: int,
        msg_id: int,
        label: str,
        lang: str,
        workers: int = 16,
    ) -> Optional[Tuple[str, Dict]]:
        """
        Перевіряє кандидатів ПАРАЛЕЛЬНО у N потоків.
        Повертає (nick, frag_data) першого реально вільного або None.
        Повідомлення про прогрес НЕ надсилаються і не редагуються.
        """
        stop = threading.Event()
        winner: List[Optional[Tuple[str, Dict]]] = [None]
        lock = threading.Lock()
        checked = [0]

        def _check_one(nick: str) -> None:
            if stop.is_set():
                return
            # Префільтр (t.me + Fragment) → фінальна MTProto-перевірка
            try:
                status, _pre = cls.check_availability(nick, fast=True)
            except Exception:
                status = "error"
            free = status in ("free", "unconfirmed")
            with lock:
                checked[0] += 1
            # Прогрес у чат не оновлюємо: часті edit_message_text — зайві запити до
            # Bot API; користувач бачить одне початкове повідомлення і фінальний результат.

            if free and not stop.is_set():
                # Нік пройшов перевірку → Fragment ще раз, лише для деталей звіту
                proxy = proxy_manager.get()
                frag = dict(cls._check_fragment(nick, proxy))
                if frag.get("status") is None:
                    frag["status"] = "unknown"
                frag["confirmed"] = (status == "free")
                with lock:
                    if not stop.is_set():
                        stop.set()
                        winner[0] = (nick, frag)

        with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as executor:
            futs = [executor.submit(_check_one, c) for c in candidates]
            try:
                concurrent.futures.wait(futs, timeout=300,
                                        return_when=concurrent.futures.ALL_COMPLETED)
            except Exception:
                pass
            if stop.is_set():
                for f in futs:
                    f.cancel()

        return winner[0]

    @classmethod
    def check_username_deep(cls, username: str) -> Dict:
        """Повний аналіз ніку: TG + Fragment + якість.
        Повертає:
        {"tg_free": bool, "frag": {...}, "quality": {...}}
        """
        username = username.strip().lower().lstrip("@")
        result = {
            "username": username,
            "tg_free": False,
            "tg_error": False,
            "frag": {"status": "unknown", "auction_price": None,
                     "auction_bids": None, "auction_ends": None, "buy_now": None},
            "quality": NickQualityAnalyzer.analyze(username),
        }
        proxy = proxy_manager.get()
        for attempt in range(3):
            tg = cls._check_telegram(username, proxy)
            if tg is None:
                if proxy: proxy_manager.mark_dead(proxy); proxy = proxy_manager.get()
                time.sleep(0.5); continue
            result["tg_free"] = tg
            if not tg:
                break
            frag = cls._check_fragment(username, proxy)
            if frag.get("status") is None:
                if proxy: proxy_manager.mark_dead(proxy); proxy = proxy_manager.get()
                time.sleep(0.5); continue
            result["frag"] = frag
            break
        # Остаточне слово — Telegram (MTProto)
        result["verify"] = "unverified"
        result["confirmed"] = False
        if result["tg_free"]:
            if tg_verify.is_configured():
                v = tg_verify.verify_username_telegram(username)
                result["verify"] = v
                result["confirmed"] = (v == "free")
                result["tg_free"] = (v == "free")
            elif result["frag"].get("status") in ("taken", "auction"):
                result["tg_free"] = False
        return result

logger.info("[INIT] Блок 3: валідатор TG+Fragment.")

# ==============================================================================
# БЛОК 5: БАЗА ДАНИХ
# ==============================================================================
class PotokoSafeDatabaseManager:
    def __init__(self):
        self.db_path = DB_FILE
        self.lock = threading.Lock()
        self._create_tables()

    def _create_tables(self):
        with self.lock:
            conn = sqlite3.connect(self.db_path, timeout=30)
            c = conn.cursor()
            c.execute('''CREATE TABLE IF NOT EXISTS users (
                user_id          INTEGER PRIMARY KEY,
                username         TEXT,
                attempts         INTEGER DEFAULT 10,
                is_premium       INTEGER DEFAULT 0,
                premium_until    REAL    DEFAULT 0.0,
                referrals        INTEGER DEFAULT 0,
                is_admin         INTEGER DEFAULT 0,
                referrer_id      INTEGER DEFAULT NULL,
                registration_date TEXT,
                lang             TEXT    DEFAULT 'ua',
                total_scans      INTEGER DEFAULT 0,
                last_scan_ts     REAL    DEFAULT 0.0
            )''')
            # Міграція: додаємо нові стовпці якщо їх немає
            for col, defval in [("total_scans","INTEGER DEFAULT 0"),
                                 ("last_scan_ts","REAL DEFAULT 0.0"),
                                 ("lang_chosen","INTEGER DEFAULT 0")]:
                try:
                    c.execute(f"ALTER TABLE users ADD COLUMN {col} {defval}")
                except Exception:
                    pass
            c.execute(
                "UPDATE users SET lang_chosen=1 "
                "WHERE lang_chosen=0 AND (total_scans > 0 OR is_admin=1 OR is_premium=1)"
            )
            c.execute('''CREATE TABLE IF NOT EXISTS attempts_history (
                log_id      INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id     INTEGER,
                action_type TEXT,
                amount      INTEGER,
                timestamp   TEXT
            )''')
            c.execute('''CREATE TABLE IF NOT EXISTS processed_tx (
                tx_hash    TEXT PRIMARY KEY,
                user_id    INTEGER,
                plan       TEXT,
                ton_amount REAL,
                activated_at TEXT
            )''')
            c.execute('''CREATE TABLE IF NOT EXISTS found_nicks (
                id         INTEGER PRIMARY KEY AUTOINCREMENT,
                nick       TEXT,
                length     INTEGER,
                found_by   INTEGER,
                found_at   TEXT
            )''')
            c.execute('''CREATE TABLE IF NOT EXISTS watchlist (
                id         INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id    INTEGER,
                nick       TEXT,
                added_at   TEXT,
                last_check TEXT,
                UNIQUE(user_id, nick)
            )''')
            c.execute('''CREATE TABLE IF NOT EXISTS ad_clicks (
                id         INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id    INTEGER,
                clicked_at REAL
            )''')
            c.execute('''CREATE TABLE IF NOT EXISTS partners (
                user_id    INTEGER PRIMARY KEY,
                percent    INTEGER DEFAULT 10,
                ref_count  INTEGER DEFAULT 0,
                total_ton  REAL    DEFAULT 0.0,
                created_at TEXT
            )''')
            c.execute('''CREATE TABLE IF NOT EXISTS channel_usernames (
                id               INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id          INTEGER NOT NULL,
                channel_id       INTEGER NOT NULL UNIQUE,
                channel_username TEXT,
                channel_title    TEXT,
                added_at         TEXT
            )''')
            # Міграція: якщо стара схема без UNIQUE(channel_id), drop+recreate не потрібно
            # — UNIQUE задано прямо на стовпці, вже enforced SQLite-ом
            # Міграція нових стовпців users
            for col, defval in [("banned",           "INTEGER DEFAULT 0"),
                                 ("partner_percent",  "INTEGER DEFAULT 0"),
                                 ("nick_sell_price",  "REAL DEFAULT 0.0")]:
                try:
                    c.execute(f"ALTER TABLE users ADD COLUMN {col} {defval}")
                except Exception:
                    pass
            conn.commit()
            conn.close()
            logger.info("[DATABASE] Таблиці ініціалізовано.")

    def _conn(self):
        return sqlite3.connect(self.db_path, timeout=30)

    def get_user_profile(self, user_id: int, username: str = "User") -> Dict[str, Any]:
        with self.lock:
            conn = self._conn()
            c = conn.cursor()
            is_owner = (user_id == OWNER_ID)
            now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            c.execute(
                "INSERT OR IGNORE INTO users (user_id,username,attempts,is_premium,premium_until,"
                "referrals,is_admin,registration_date,lang,total_scans,last_scan_ts) "
                "VALUES (?,?,10,?,0.0,0,?,?,?,0,0.0)",
                (user_id, username, 1 if is_owner else 0, 1 if is_owner else 0, now_str,
                 "ua")
            )
            conn.commit()
            c.execute("SELECT attempts,is_premium,premium_until,referrals,is_admin,"
                      "referrer_id,lang,total_scans,last_scan_ts,lang_chosen FROM users WHERE user_id=?",
                      (user_id,))
            row = c.fetchone()
            conn.close()
            if not row:
                return {"attempts":10,"is_premium":is_owner,"premium_until":0.0,
                        "referrals":0,"is_admin":is_owner,"username":username,
                        "lang":"ua","total_scans":0,"last_scan_ts":0.0,"lang_chosen":0}
            att,prem,puntil,refs,adm,ref_id,lang,scans,lsts,lang_chosen = row
            current_premium = bool(prem)
            if not is_owner and current_premium and puntil > 0 and time.time() > puntil:
                conn2 = self._conn()
                conn2.cursor().execute(
                    "UPDATE users SET is_premium=0,premium_until=0 WHERE user_id=?", (user_id,))
                conn2.commit(); conn2.close()
                current_premium = False; puntil = 0.0
            return {
                "attempts": att,
                "is_premium": current_premium or is_owner,
                "premium_until": puntil,
                "referrals": refs,
                "is_admin": bool(adm) or is_owner,
                "username": username,
                "referrer_id": ref_id,
                "lang": lang if lang in LANG_PACKS else "ua",
                "total_scans": scans or 0,
                "last_scan_ts": lsts or 0.0,
                "lang_chosen": bool(lang_chosen),
            }

    def update_user_field(self, user_id: int, field: str, value: Any):
        with self.lock:
            conn = self._conn()
            conn.cursor().execute(f"UPDATE users SET {field}=? WHERE user_id=?", (value, user_id))
            conn.commit(); conn.close()

    def increment_scans(self, user_id: int):
        with self.lock:
            conn = self._conn()
            conn.cursor().execute(
                "UPDATE users SET total_scans=total_scans+1, last_scan_ts=? WHERE user_id=?",
                (time.time(), user_id))
            conn.commit(); conn.close()

    def activate_premium(self, user_id: int, plan_key: str) -> float:
        plan = PREMIUM_PLANS[plan_key]
        with self.lock:
            conn = self._conn()
            c = conn.cursor()
            c.execute("SELECT premium_until FROM users WHERE user_id=?", (user_id,))
            row = c.fetchone()
            now_ts = time.time()
            if plan["days"] == 0:
                new_until = 0.0
            else:
                base = max(now_ts, (row[0] if row and row[0] and row[0] > now_ts else now_ts))
                new_until = base + plan["days"] * 86400
            # Безмежні спроби для premium
            c.execute("UPDATE users SET is_premium=1, premium_until=?, attempts=9999 WHERE user_id=?",
                      (new_until, user_id))
            conn.commit(); conn.close()
            return new_until

    def register_referral_link(self, target_id: int, target_uname: str, referrer_id: int) -> bool:
        if target_id == referrer_id: return False
        with self.lock:
            conn = self._conn()
            c = conn.cursor()
            c.execute("SELECT user_id FROM users WHERE user_id=?", (target_id,))
            if c.fetchone(): conn.close(); return False
            now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            c.execute(
                "INSERT INTO users (user_id,username,attempts,is_premium,premium_until,"
                "referrals,is_admin,referrer_id,registration_date,lang,total_scans,last_scan_ts) "
                "VALUES (?,?,15,0,0.0,0,0,?,?,?,0,0.0)",
                (target_id, target_uname, referrer_id, now_str, "ua")
            )
            c.execute("UPDATE users SET referrals=referrals+1, attempts=attempts+5 WHERE user_id=?",
                      (referrer_id,))
            conn.commit(); conn.close()
            return True

    def save_found_nick(self, nick: str, length: int, user_id: int):
        with self.lock:
            conn = self._conn()
            now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            conn.cursor().execute(
                "INSERT INTO found_nicks (nick,length,found_by,found_at) VALUES (?,?,?,?)",
                (nick, length, user_id, now_str))
            conn.commit(); conn.close()

    def is_tx_processed(self, tx_hash: str) -> bool:
        with self.lock:
            conn = self._conn()
            r = conn.cursor().execute(
                "SELECT 1 FROM processed_tx WHERE tx_hash=?", (tx_hash,)).fetchone()
            conn.close(); return r is not None

    def save_processed_tx(self, tx_hash: str, user_id: int, plan: str, ton: float):
        with self.lock:
            conn = self._conn()
            conn.cursor().execute(
                "INSERT OR IGNORE INTO processed_tx (tx_hash,user_id,plan,ton_amount,activated_at) "
                "VALUES (?,?,?,?,?)",
                (tx_hash, user_id, plan, ton, datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
            conn.commit(); conn.close()

    def get_all_user_ids(self) -> List[int]:
        with self.lock:
            conn = self._conn()
            rows = conn.cursor().execute("SELECT user_id FROM users").fetchall()
            conn.close(); return [r[0] for r in rows]

    def count_users(self) -> int:
        with self.lock:
            conn = self._conn()
            val = conn.cursor().execute("SELECT COUNT(*) FROM users").fetchone()[0]
            conn.close(); return val

    def count_premium(self) -> int:
        with self.lock:
            conn = self._conn()
            val = conn.cursor().execute(
                "SELECT COUNT(*) FROM users WHERE is_premium=1").fetchone()[0]
            conn.close(); return val

    def count_found_nicks(self) -> int:
        with self.lock:
            conn = self._conn()
            val = conn.cursor().execute("SELECT COUNT(*) FROM found_nicks").fetchone()[0]
            conn.close(); return val

    def get_top_users(self, limit: int = 5) -> List[tuple]:
        with self.lock:
            conn = self._conn()
            rows = conn.cursor().execute(
                "SELECT user_id, username, total_scans FROM users ORDER BY total_scans DESC LIMIT ?",
                (limit,)).fetchall()
            conn.close(); return rows

    # --- Watchlist methods ---
    def watchlist_add(self, user_id: int, nick: str) -> str:
        """Returns: 'added' | 'exists' | 'limit'"""
        nick = nick.lower().lstrip("@")
        with self.lock:
            conn = self._conn()
            c = conn.cursor()
            c.execute("SELECT COUNT(*) FROM watchlist WHERE user_id=?", (user_id,))
            count = c.fetchone()[0]
            # Check if already exists
            c.execute("SELECT 1 FROM watchlist WHERE user_id=? AND nick=?", (user_id, nick))
            if c.fetchone():
                conn.close(); return "exists"
            # Check limit for non-premium (we pass is_premium separately)
            if count >= 3:
                conn.close(); return "limit"
            now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            c.execute("INSERT INTO watchlist (user_id,nick,added_at,last_check) VALUES (?,?,?,?)",
                      (user_id, nick, now_str, now_str))
            conn.commit(); conn.close()
            return "added"

    def watchlist_add_premium(self, user_id: int, nick: str) -> str:
        """For premium — no limit"""
        nick = nick.lower().lstrip("@")
        with self.lock:
            conn = self._conn()
            c = conn.cursor()
            c.execute("SELECT 1 FROM watchlist WHERE user_id=? AND nick=?", (user_id, nick))
            if c.fetchone():
                conn.close(); return "exists"
            now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            c.execute("INSERT INTO watchlist (user_id,nick,added_at,last_check) VALUES (?,?,?,?)",
                      (user_id, nick, now_str, now_str))
            conn.commit(); conn.close()
            return "added"

    def watchlist_remove(self, user_id: int, nick: str) -> bool:
        nick = nick.lower().lstrip("@")
        with self.lock:
            conn = self._conn()
            c = conn.cursor()
            c.execute("DELETE FROM watchlist WHERE user_id=? AND nick=?", (user_id, nick))
            changed = c.rowcount > 0
            conn.commit(); conn.close()
            return changed

    def watchlist_get(self, user_id: int) -> List[str]:
        with self.lock:
            conn = self._conn()
            rows = conn.cursor().execute(
                "SELECT nick FROM watchlist WHERE user_id=? ORDER BY added_at", (user_id,)).fetchall()
            conn.close(); return [r[0] for r in rows]

    def watchlist_get_all(self) -> List[tuple]:
        """Returns [(user_id, nick, id), ...]"""
        with self.lock:
            conn = self._conn()
            rows = conn.cursor().execute(
                "SELECT user_id, nick, id FROM watchlist").fetchall()
            conn.close(); return rows

    def watchlist_update_check(self, entry_id: int):
        with self.lock:
            conn = self._conn()
            conn.cursor().execute(
                "UPDATE watchlist SET last_check=? WHERE id=?",
                (datetime.now().strftime("%Y-%m-%d %H:%M:%S"), entry_id))
            conn.commit(); conn.close()

    def watchlist_remove_by_id(self, entry_id: int):
        with self.lock:
            conn = self._conn()
            conn.cursor().execute("DELETE FROM watchlist WHERE id=?", (entry_id,))
            conn.commit(); conn.close()

    # --- Ban ---
    def is_banned(self, user_id: int) -> bool:
        if user_id == OWNER_ID: return False
        with self.lock:
            conn = self._conn()
            r = conn.cursor().execute(
                "SELECT banned FROM users WHERE user_id=?", (user_id,)).fetchone()
            conn.close()
            return bool(r and r[0])

    def ban_user(self, user_id: int, banned: bool = True):
        with self.lock:
            conn = self._conn()
            conn.cursor().execute("UPDATE users SET banned=? WHERE user_id=?",
                                  (1 if banned else 0, user_id))
            conn.commit(); conn.close()

    # --- Referrals list ---
    def get_referred_users(self, referrer_id: int) -> List[Tuple[int, str]]:
        with self.lock:
            conn = self._conn()
            rows = conn.cursor().execute(
                "SELECT user_id, username FROM users WHERE referrer_id=? ORDER BY registration_date DESC",
                (referrer_id,)).fetchall()
            conn.close()
            return [(r[0], r[1] or "—") for r in rows]

    # --- Revenue ---
    def get_revenue_stats(self) -> Dict[str, float]:
        with self.lock:
            conn = self._conn()
            c = conn.cursor()
            now = datetime.now()
            day_ago   = (now - timedelta(days=1)).strftime("%Y-%m-%d %H:%M:%S")
            week_ago  = (now - timedelta(days=7)).strftime("%Y-%m-%d %H:%M:%S")
            month_ago = (now - timedelta(days=30)).strftime("%Y-%m-%d %H:%M:%S")
            def _sum(since):
                r = c.execute(
                    "SELECT COALESCE(SUM(ton_amount),0) FROM processed_tx WHERE activated_at>=?",
                    (since,)).fetchone()
                return round(float(r[0]), 3) if r else 0.0
            day_ton   = _sum(day_ago)
            week_ton  = _sum(week_ago)
            month_ton = _sum(month_ago)
            total     = c.execute(
                "SELECT COALESCE(SUM(ton_amount),0) FROM processed_tx").fetchone()[0]
            conn.close()
            return {"day": day_ton, "week": week_ton,
                    "month": month_ton, "total": round(float(total), 3)}

    # --- Partners ---
    def get_all_partners(self) -> List[tuple]:
        with self.lock:
            conn = self._conn()
            rows = conn.cursor().execute(
                "SELECT p.user_id, u.username, p.percent, p.ref_count, p.total_ton "
                "FROM partners p LEFT JOIN users u ON p.user_id=u.user_id"
            ).fetchall()
            conn.close()
            return rows

    def add_partner(self, user_id: int, percent: int):
        with self.lock:
            conn = self._conn()
            now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            conn.cursor().execute(
                "INSERT OR REPLACE INTO partners (user_id, percent, created_at) VALUES (?,?,?)",
                (user_id, percent, now_str))
            conn.commit(); conn.close()

    # --- Found nicks by user ---
    def add_channel_username(self, user_id: int, channel_id: int,
                             username: str, title: str) -> None:
        with self.lock:
            conn = self._conn()
            conn.cursor().execute(
                "INSERT OR REPLACE INTO channel_usernames "
                "(user_id, channel_id, channel_username, channel_title, added_at) "
                "VALUES (?, ?, ?, ?, ?)",
                (user_id, channel_id, username, title, datetime.now().isoformat()))
            conn.commit()
            conn.close()

    def remove_channel_by_id(self, channel_id: int) -> None:
        with self.lock:
            conn = self._conn()
            conn.cursor().execute(
                "DELETE FROM channel_usernames WHERE channel_id=?", (channel_id,))
            conn.commit()
            conn.close()

    def get_channel_usernames(self, user_id: int) -> List[Dict[str, str]]:
        with self.lock:
            conn = self._conn()
            rows = conn.cursor().execute(
                "SELECT channel_username, channel_title FROM channel_usernames "
                "WHERE user_id=? ORDER BY added_at DESC", (user_id,)).fetchall()
            conn.close()
            return [{"username": r[0], "title": r[1]} for r in rows]

    def get_found_nicks_by_user(self, user_id: int, limit: int = 20) -> List[str]:
        with self.lock:
            conn = self._conn()
            rows = conn.cursor().execute(
                "SELECT nick FROM found_nicks WHERE found_by=? ORDER BY found_at DESC LIMIT ?",
                (user_id, limit)).fetchall()
            conn.close()
            return [r[0] for r in rows]

    def get_user_by_id(self, user_id: int) -> Optional[Dict[str, Any]]:
        """Повертає базову інфу про юзера або None якщо не знайдено."""
        with self.lock:
            conn = self._conn()
            c = conn.cursor()
            c.execute(
                "SELECT user_id, username, is_premium, premium_until, is_admin, "
                "total_scans, referrals, attempts, lang FROM users WHERE user_id=?",
                (user_id,))
            row = c.fetchone()
            conn.close()
            if not row:
                return None
            uid, uname, prem, puntil, adm, scans, refs, att, lang = row
            return {
                "user_id": uid,
                "username": uname or "—",
                "is_premium": bool(prem),
                "premium_until": puntil or 0.0,
                "is_admin": bool(adm),
                "total_scans": scans or 0,
                "referrals": refs or 0,
                "attempts": att or 0,
                "lang": lang if lang in LANG_PACKS else "ua",
            }

    # --- Nick stats ---
    def get_nicks_stats(self) -> Dict[str, int]:
        with self.lock:
            conn = self._conn()
            c = conn.cursor()
            now = datetime.now()
            today_str = now.strftime("%Y-%m-%d")
            week_ago  = (now - timedelta(days=7)).strftime("%Y-%m-%d %H:%M:%S")
            today = c.execute(
                "SELECT COUNT(*) FROM found_nicks WHERE found_at LIKE ?",
                (today_str + "%",)).fetchone()[0]
            week = c.execute(
                "SELECT COUNT(*) FROM found_nicks WHERE found_at>=?",
                (week_ago,)).fetchone()[0]
            total = c.execute("SELECT COUNT(*) FROM found_nicks").fetchone()[0]
            conn.close()
            return {"today": today, "week": week, "total": total}

    # --- Ad clicks ---
    def try_claim_ad(self, user_id: int) -> bool:
        """Атомарно перевіряє cooldown і реєструє клік. Повертає True якщо нагороду видати можна."""
        with self.lock:
            conn = self._conn()
            c = conn.cursor()
            cutoff = time.time() - AD_COOLDOWN_HOURS * 3600
            r = c.execute(
                "SELECT 1 FROM ad_clicks WHERE user_id=? AND clicked_at>?",
                (user_id, cutoff)).fetchone()
            if r:
                conn.close()
                return False
            c.execute(
                "INSERT INTO ad_clicks (user_id, clicked_at) VALUES (?,?)",
                (user_id, time.time()))
            conn.commit(); conn.close()
            return True

    def can_claim_ad(self, user_id: int) -> bool:
        """True якщо юзер може отримати нагороду (без side-effects, тільки перевірка)."""
        with self.lock:
            conn = self._conn()
            cutoff = time.time() - AD_COOLDOWN_HOURS * 3600
            r = conn.cursor().execute(
                "SELECT 1 FROM ad_clicks WHERE user_id=? AND clicked_at>?",
                (user_id, cutoff)).fetchone()
            conn.close()
            return r is None

    # --- Partners ---
    def add_partner(self, user_id: int, percent: int):
        with self.lock:
            conn = self._conn()
            c = conn.cursor()
            now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            # Upsert: якщо вже є — лише оновлюємо percent, зберігаємо ref_count/total_ton
            c.execute(
                "INSERT INTO partners (user_id, percent, created_at) VALUES (?,?,?) "
                "ON CONFLICT(user_id) DO UPDATE SET percent=excluded.percent",
                (user_id, percent, now_str))
            c.execute(
                "UPDATE users SET partner_percent=? WHERE user_id=?", (percent, user_id))
            conn.commit(); conn.close()

    def get_partner(self, user_id: int) -> Optional[Dict]:
        with self.lock:
            conn = self._conn()
            r = conn.cursor().execute(
                "SELECT percent, ref_count, total_ton FROM partners WHERE user_id=?",
                (user_id,)).fetchone()
            conn.close()
            if not r: return None
            return {"percent": r[0], "ref_count": r[1], "total_ton": r[2]}

    def get_all_partners(self) -> List[tuple]:
        with self.lock:
            conn = self._conn()
            rows = conn.cursor().execute(
                "SELECT p.user_id, u.username, p.percent, p.ref_count, p.total_ton "
                "FROM partners p LEFT JOIN users u ON p.user_id=u.user_id "
                "ORDER BY p.total_ton DESC").fetchall()
            conn.close(); return rows

    def record_partner_commission(self, partner_id: int, ton: float):
        with self.lock:
            conn = self._conn()
            conn.cursor().execute(
                "UPDATE partners SET ref_count=ref_count+1, total_ton=total_ton+? WHERE user_id=?",
                (ton, partner_id))
            conn.commit(); conn.close()

db_manager = PotokoSafeDatabaseManager()

# ==============================================================================
# БЛОК 6: МОНІТОР TON-ТРАНЗАКЦІЙ
# ==============================================================================
def _get_plan_for_amount(ton: float) -> Optional[str]:
    matched, matched_ton = None, 0.0
    for key, plan in PREMIUM_PLANS.items():
        if ton >= plan["ton"] and plan["ton"] >= matched_ton:
            matched, matched_ton = key, plan["ton"]
    return matched

def _fetch_ton_transactions() -> List[Dict]:
    try:
        r = requests.get(
            "https://toncenter.com/api/v2/getTransactions",
            params={"address": TON_WALLET, "limit": 30, "archival": "false"},
            timeout=10)
        if r.status_code == 200:
            data = r.json()
            if data.get("ok"): return data.get("result", [])
    except Exception as e:
        logger.warning(f"[TON] Помилка запиту: {e}")
    return []

def _parse_ton_amount(tx: Dict) -> float:
    try:
        return int(tx.get("in_msg",{}).get("value", 0)) / 1_000_000_000
    except Exception: return 0.0

def _parse_comment(tx: Dict) -> str:
    try:
        md = tx.get("in_msg", {}).get("msg_data", {})
        if md.get("@type") == "msg.dataText":
            text = md.get("text", "")
            if text:
                try:
                    decoded = base64.b64decode(text).decode("utf-8", errors="ignore").strip()
                    if decoded:
                        return decoded
                except Exception:
                    pass
                return text
        return tx.get("in_msg", {}).get("message", "")
    except Exception:
        return ""

def ton_transaction_monitor():
    logger.info("[TON_MONITOR] Запущено.")
    while True:
        try:
            for tx in _fetch_ton_transactions():
                tx_hash = tx.get("transaction_id",{}).get("hash","")
                if not tx_hash or db_manager.is_tx_processed(tx_hash): continue
                ton_amount = _parse_ton_amount(tx)
                if ton_amount < MIN_PLAN_TON: continue
                comment = _parse_comment(tx).strip()
                match = re.search(r"tgid[_\-:]?(\d+)", comment, re.IGNORECASE)
                if not match: continue
                user_id = int(match.group(1))
                plan_key = _get_plan_for_amount(ton_amount)
                if not plan_key: continue
                plan = PREMIUM_PLANS[plan_key]
                new_until = db_manager.activate_premium(user_id, plan_key)
                db_manager.save_processed_tx(tx_hash, user_id, plan_key, ton_amount)
                logger.info(f"[TON] ✅ Premium: user={user_id} plan={plan_key} ton={ton_amount}")
                try:
                    profile = db_manager.get_user_profile(user_id)
                    lang = profile.get("lang","ua")
                    p = LANG_PACKS[lang]
                    label_key = f"label_{lang}"
                    plan_label = plan.get(label_key, plan["label_en"])
                    if plan["days"] == 0:
                        until_str = {"ua":"∞ Назавжди","ru":"∞ Навсегда","en":"∞ Lifetime"}.get(lang,"∞")
                    else:
                        until_str = datetime.fromtimestamp(new_until).strftime("%d.%m.%Y")
                    bot.send_message(user_id,
                        p["premium_activated"].format(plan=plan_label, until=until_str),
                        parse_mode="Markdown")
                    bot.send_message(user_id, "👇",
                        reply_markup=BOOHXKeyboardFactory.main_reply_menu(lang))
                    bot.send_message(OWNER_ID,
                        f"💰 *Новий платіж!*\n"
                        f"User ID: `{user_id}`\n"
                        f"Сума: {ton_amount:.3f} TON\n"
                        f"План: {plan_label}\n"
                        f"TX: `{tx_hash}`",
                        parse_mode="Markdown")
                except Exception as e:
                    logger.warning(f"[TON] Помилка сповіщення {user_id}: {e}")
        except Exception as e:
            logger.error(f"[TON_MONITOR] Критична помилка: {e}")
        time.sleep(45)

# ==============================================================================
# БЛОК 6b: WATCHLIST МОНІТОР (перевірка кожні 20 хв)
# ==============================================================================
WATCHLIST_CHECK_INTERVAL = 20 * 60  # 20 хвилин

def watchlist_monitor():
    logger.info("[WATCHLIST_MONITOR] Запущено.")
    while True:
        try:
            entries = db_manager.watchlist_get_all()
            logger.info(f"[WATCHLIST_MONITOR] Перевіряємо {len(entries)} записів...")
            for user_id, nick, entry_id in entries:
                try:
                    status, _frag = HighSpeedNetworkChecker.check_availability(nick, fast=False)
                    is_free = status in ("free", "unconfirmed")   # error/taken/... → НЕ вільний
                    if status != "error":
                        db_manager.watchlist_update_check(entry_id)
                    if is_free:
                        # Звільнився! Сповіщаємо та видаляємо з watchlist
                        profile = db_manager.get_user_profile(user_id)
                        lang = profile.get("lang", "ua")
                        msg = LANG_PACKS[lang]["watch_notify"].format(nick=nick)
                        if status == "unconfirmed":
                            msg += "\n" + UNCONFIRMED_NOTE.get(lang, UNCONFIRMED_NOTE["en"])
                        try:
                            markup = types.InlineKeyboardMarkup()
                            markup.add(
                                types.InlineKeyboardButton("🔗 Fragment", url=f"https://fragment.com/@{nick}"),
                                types.InlineKeyboardButton("📱 Telegram", url=f"https://t.me/{nick}"),
                            )
                            bot.send_message(user_id, msg, parse_mode="Markdown", reply_markup=markup)
                            logger.info(f"[WATCHLIST_MONITOR] 🔔 @{nick} вільний → сповіщено {user_id}")
                        except Exception as e:
                            logger.warning(f"[WATCHLIST_MONITOR] Помилка сповіщення {user_id}: {e}")
                        db_manager.watchlist_remove_by_id(entry_id)
                    time.sleep(1.5)  # пауза між перевірками щоб не флудити
                except Exception as e:
                    logger.warning(f"[WATCHLIST_MONITOR] Помилка запису {entry_id}: {e}")
        except Exception as e:
            logger.error(f"[WATCHLIST_MONITOR] Критична помилка: {e}")
        time.sleep(WATCHLIST_CHECK_INTERVAL)


# ==============================================================================
# БЛОК 7: ГЕНЕРАЦІЯ НІКІВ
# ==============================================================================
class BOOHXAnalyticMatrix:
    # Стратегії генерації з вагами (сума = 100)
    _VOWELS     = "aeiou"
    _CONSONANTS = "bcdfghjklmnpqrstvwxyz"
    _ALL        = "abcdefghijklmnopqrstuvwxyz"

    # Шаблони CV для 5 і 6 літер
    # Для 6 літер: пріоритет CVCVCV (приголосний-голосний×3) — легко вимовляються,
    # схожі на справжні слова і коштують більше на Fragment.
    _CV_PATTERNS: Dict[int, List[str]] = {
        5: [
            "CVCVC",   # ★ основний — toshu, belki, mirzo
            "CVCVC",   # подвоюємо для вищої ваги
            "CVCCV",   # tarka, bolva
            "VCVCV",   # azoro, ikane
            "CVCVV",   # tobia, revia
            "CVVCV",   # kaico, zoida
            "CCVCV",   # flori, graze
        ],
        6: [
            "CVCVCV",  # ★★★ ПРІОРИТЕТ — "tomika", "bolora", "masebo" — красиво і ліквідно
            "CVCVCV",  # ×4 для домінування
            "CVCVCV",
            "CVCVCV",
            "VCVCVC",  # azomik, ikalob
            "CVCVVC",  # tobias, reniok
            "CVCCVC",  # tarmok, belroc
            "CVCVCV",  # ще раз для надійності
        ],
    }

    # Склади (2 літери: CV) для складання смислових слів
    _SYLLABLES_CV = [
        "ba","be","bi","bo","bu",
        "ca","ce","ci","co","cu",
        "da","de","di","do","du",
        "fa","fe","fi","fo","fu",
        "ga","ge","gi","go","gu",
        "ka","ke","ki","ko","ku",
        "la","le","li","lo","lu",
        "ma","me","mi","mo","mu",
        "na","ne","ni","no","nu",
        "pa","pe","pi","po","pu",
        "ra","re","ri","ro","ru",
        "sa","se","si","so","su",
        "ta","te","ti","to","tu",
        "va","ve","vi","vo","vu",
        "wa","we","wi","wo",
        "xa","xe","xi","xo",
        "za","ze","zi","zo","zu",
    ]

    @classmethod
    def generate_word(cls, length: int, seen: Optional[set] = None) -> str:
        """Генерує нік заданої довжини — покращена v2.

        Для 6 літер: домінує CVCVCV + складові слова (60%).
        Для 5 літер: CVCVC + краща мікс-стратегія без потворних кластерів.
        Стратегії з вагами (сума = 100).
        """
        V, C, A = cls._VOWELS, cls._CONSONANTS, cls._ALL

        def _pure_alpha() -> str:
            return ''.join(secrets.choice(A) for _ in range(length))

        def _pronounceable() -> str:
            """Строге чергування C-V або V-C."""
            chars, use_v = [], bool(secrets.randbelow(2))
            for _ in range(length):
                chars.append(secrets.choice(V if use_v else C))
                use_v = not use_v
            return ''.join(chars)

        def _cv_pattern() -> str:
            pats = cls._CV_PATTERNS.get(length)
            if not pats:
                pats = [("CV" * (length // 2 + 1))[:length]]
            pat = secrets.choice(pats)
            return ''.join(secrets.choice(V if ch == 'V' else C) for ch in pat)

        def _cvcvcv_strict() -> str:
            """Тільки CVCVCV — для 6 літер. Гарантовано вимовляється."""
            pat = ("CVCVCV" if length == 6 else "CVCVC")
            return ''.join(secrets.choice(V if ch == 'V' else C) for ch in pat[:length])

        def _syllable_word() -> str:
            """Складаємо слово зі складів CV+CV+... → remifo, kasoli, tobera."""
            sylls = cls._SYLLABLES_CV
            if length == 6:
                # 3 склади по 2 літери = 6
                return ''.join(secrets.choice(sylls) for _ in range(3))
            elif length == 5:
                # 2 склади + 1 приголосний або 1 склад + 3 символи
                s1 = secrets.choice(sylls)
                s2 = secrets.choice(sylls)
                tail = secrets.choice(C)
                return (s1 + s2 + tail)[:length]
            else:
                n = length // 2
                return ''.join(secrets.choice(sylls) for _ in range(n + 1))[:length]

        def _mixed_random() -> str:
            """Рандом без потворних кластерів (макс 2 приголосних підряд)."""
            result_chars, cons_run = [], 0
            for _ in range(length):
                if cons_run >= 2:
                    ch = secrets.choice(V)
                    cons_run = 0
                else:
                    ch = secrets.choice(A)
                    cons_run = cons_run + 1 if ch not in V else 0
                result_chars.append(ch)
            return ''.join(result_chars)

        def _prefix_suffix() -> str:
            pre = secrets.choice(BRAND_PREFIXES)
            suf = secrets.choice(BRAND_SUFFIXES)
            mid_len = length - len(pre) - len(suf)
            if mid_len > 0:
                mid = ''.join(secrets.choice(A) for _ in range(mid_len))
            else:
                mid = ""
            return (pre + mid + suf)[:length]

        # Ваги залежать від довжини
        if length == 6:
            # Для 6 літер: CVCVCV домінує (60% — ←ось головна зміна)
            weighted: List[tuple] = [
                (_cvcvcv_strict, 35),   # чистий CVCVCV
                (_syllable_word, 60),   # склади → схожі на справжні слова
                (_cv_pattern,    75),   # розширені CV-шаблони
                (_pronounceable, 85),   # звичайне чергування
                (_mixed_random,  93),
                (_prefix_suffix, 100),
            ]
        elif length == 5:
            weighted = [
                (_cvcvcv_strict, 25),   # CVCVC — часто виходять гарні ніки
                (_syllable_word, 45),   # складові
                (_pronounceable, 62),
                (_cv_pattern,    75),
                (_mixed_random,  87),
                (_prefix_suffix, 100),
            ]
        else:
            weighted = [
                (_pure_alpha,    30),
                (_pronounceable, 50),
                (_cv_pattern,    65),
                (_syllable_word, 78),
                (_mixed_random,  90),
                (_prefix_suffix, 100),
            ]

        for _ in range(50):
            r = secrets.randbelow(100)
            for fn, threshold in weighted:
                if r < threshold:
                    candidate = fn()
                    break
            else:
                candidate = _pure_alpha()

            if len(candidate) == length and (seen is None or candidate not in seen):
                return candidate

        # Fallback
        fb = _cvcvcv_strict() if length in (5, 6) else _pure_alpha()
        return fb

    @classmethod
    def generate_fragment_report(cls, nickname: str, lang: str,
                                  frag_data: Optional[Dict] = None) -> str:
        q = NickQualityAnalyzer.analyze(nickname)
        ln = q["length"]
        grade     = q["grade"]
        stars     = q["stars"]
        bar       = NickQualityAnalyzer.grade_bar(q["score"])
        value_ton = q["value_ton"]
        value_usd = q["value_usd"]
        score     = q["score"]

        # Деталі якості
        quality_lines = "\n".join(f"  {icon} {desc}" for icon, desc in q["details"])

        # Аукціон/Fragment рядок
        frag_status = "✅"
        frag_line   = ""
        _unconf = bool(frag_data) and frag_data.get("confirmed") is False
        tg_state = {
            "ua": ("⚠️ Не підтверджено через Telegram" if _unconf else "✅ Вільний"),
            "ru": ("⚠️ Не подтверждено через Telegram" if _unconf else "✅ Свободен"),
            "en": ("⚠️ Not confirmed via Telegram"     if _unconf else "✅ Free"),
        }
        if frag_data:
            st = frag_data.get("status","unknown")
            if st == "auction":
                frag_status = "⚡"
                price = frag_data.get("auction_price","?")
                bids  = frag_data.get("auction_bids")
                bids_str = f" · {bids} ставок" if bids else ""
                frag_line = f"\n   💸 Аукціон: {price}{bids_str}"
            elif st == "free":
                frag_status = "✅"

        txt = {
            "ua": (
                f"🎯 *ВІЛЬНИЙ НІК ЗНАЙДЕНО!*\n\n"
                f"🏷 `@{nickname}`\n\n"
                f"📊 *Перевірка:*\n"
                f"├ Telegram: {tg_state['ua']}\n"
                f"└ Fragment: {frag_status} Вільний{frag_line}\n\n"
                f"🏆 *Рейтинг якості: {grade}* {stars}\n"
                f"`{bar}` {score}/100\n\n"
                f"*Чому такий рейтинг:*\n{quality_lines}\n\n"
                f"💰 *Ринкова вартість:* ~{value_ton} TON (~${value_usd})\n"
                f"🔗 [Fragment](https://fragment.com/@{nickname}) · "
                f"[Telegram](https://t.me/{nickname})"
            ),
            "ru": (
                f"🎯 *СВОБОДНЫЙ НИК НАЙДЕН!*\n\n"
                f"🏷 `@{nickname}`\n\n"
                f"📊 *Проверка:*\n"
                f"├ Telegram: {tg_state['ru']}\n"
                f"└ Fragment: {frag_status} Свободен{frag_line}\n\n"
                f"🏆 *Рейтинг качества: {grade}* {stars}\n"
                f"`{bar}` {score}/100\n\n"
                f"*Почему такой рейтинг:*\n{quality_lines}\n\n"
                f"💰 *Рыночная стоимость:* ~{value_ton} TON (~${value_usd})\n"
                f"🔗 [Fragment](https://fragment.com/@{nickname}) · "
                f"[Telegram](https://t.me/{nickname})"
            ),
            "en": (
                f"🎯 *FREE USERNAME FOUND!*\n\n"
                f"🏷 `@{nickname}`\n\n"
                f"📊 *Check:*\n"
                f"├ Telegram: {tg_state['en']}\n"
                f"└ Fragment: {frag_status} Free{frag_line}\n\n"
                f"🏆 *Quality Rating: {grade}* {stars}\n"
                f"`{bar}` {score}/100\n\n"
                f"*Why this rating:*\n{quality_lines}\n\n"
                f"💰 *Market Value:* ~{value_ton} TON (~${value_usd})\n"
                f"🔗 [Fragment](https://fragment.com/@{nickname}) · "
                f"[Telegram](https://t.me/{nickname})"
            ),
        }
        return txt.get(lang, txt["en"])

    @staticmethod
    def generate_deep_check_report(data: Dict, lang: str) -> str:
        """Детальний звіт для @username перевірки (не скан)."""
        nick    = data["username"]
        tg_free = data["tg_free"]
        frag    = data["frag"]
        q       = data["quality"]

        grade = q["grade"]; stars = q["stars"]
        bar   = NickQualityAnalyzer.grade_bar(q["score"])
        score = q["score"]
        quality_lines = "\n".join(f"  {icon} {desc}" for icon, desc in q["details"])

        # TG статус
        tg_icon = "✅" if tg_free else "🔒"
        tg_txt  = {"ua": ("Вільний","Зайнятий"),
                   "ru": ("Свободен","Занят"),
                   "en": ("Free","Taken")}.get(lang, ("Free","Taken"))
        tg_str  = f"{tg_icon} {tg_txt[0] if tg_free else tg_txt[1]}"

        # Вердикт MTProto (якщо є) точніший за «вільний/зайнятий»
        verify    = data.get("verify", "")
        confirmed = data.get("confirmed", True)
        _vtxt = {
            "invalid":  {"ua": "⛔ Недійсний / заборонений", "ru": "⛔ Недопустимый / запрещён",
                         "en": "⛔ Invalid / not allowed"},
            "fragment": {"ua": "⚡ Продається на Fragment (не вільний)",
                         "ru": "⚡ Продаётся на Fragment (не свободен)",
                         "en": "⚡ For sale on Fragment (not free)"},
            "error":    {"ua": "❓ Не вдалося перевірити — спробуйте пізніше",
                         "ru": "❓ Не удалось проверить — попробуйте позже",
                         "en": "❓ Could not verify — try again later"},
        }
        if verify in _vtxt:
            tg_str = _vtxt[verify].get(lang, _vtxt[verify]["en"])
        elif tg_free and not confirmed:
            tg_str = UNCONFIRMED_NOTE.get(lang, UNCONFIRMED_NOTE["en"])

        # Fragment статус
        st = frag.get("status","unknown")
        frag_parts = {"free":"✅","taken":"🔒","auction":"⚡","sale":"⚡",
                      "invalid":"⛔","unknown":"❓"}.get(st,"❓")
        frag_label = {"free":   {"ua":"Вільний","ru":"Свободен","en":"Free"},
                      "taken":  {"ua":"Зайнятий","ru":"Занят","en":"Taken"},
                      "auction":{"ua":"На аукціоні","ru":"На аукционе","en":"On Auction"},
                      "sale":   {"ua":"Продається","ru":"Продаётся","en":"For sale"},
                      "invalid":{"ua":"Недійсний","ru":"Недопустимый","en":"Invalid"},
                      "unknown":{"ua":"Невідомо","ru":"Неизвестно","en":"Unknown"}
                     }.get(st,{}).get(lang,"Unknown")

        frag_str = f"{frag_parts} {frag_label}"

        # Аукціонна інфо
        auction_block = ""
        if st == "auction":
            price = frag.get("auction_price")
            bids  = frag.get("auction_bids")
            ends  = frag.get("auction_ends")
            lines = []
            if price: lines.append(f"   💸 Ціна: *{price}*" if lang=="ua"
                                    else f"   💸 Цена: *{price}*" if lang=="ru"
                                    else f"   💸 Price: *{price}*")
            if bids:  lines.append(f"   🔢 Ставок: {bids}" if lang in ("ua","ru")
                                    else f"   🔢 Bids: {bids}")
            if ends:  lines.append(f"   ⏰ Кінець: {ends}" if lang=="ua"
                                    else f"   ⏰ Конец: {ends}" if lang=="ru"
                                    else f"   ⏰ Ends: {ends}")
            if lines: auction_block = "\n" + "\n".join(lines)

        # Загальний статус
        # tg_free уже враховує MTProto-вердикт і префільтр (див. check_single)
        overall_free = bool(tg_free) and verify not in ("invalid", "fragment", "error")

        header = {
            True:  {"ua":"✅ НІК ВІЛЬНИЙ!","ru":"✅ НИК СВОБОДЕН!","en":"✅ USERNAME FREE!"},
            False: {"ua":"🔍 Результат перевірки","ru":"🔍 Результат проверки","en":"🔍 Check Result"},
        }[overall_free].get(lang,"🔍 Check Result")
        if overall_free and not confirmed:
            header = {"ua":"⚠️ НІК, ЙМОВІРНО, ВІЛЬНИЙ","ru":"⚠️ НИК, ВОЗМОЖНО, СВОБОДЕН",
                      "en":"⚠️ USERNAME PROBABLY FREE"}.get(lang, "⚠️ USERNAME PROBABLY FREE")

        return (
            f"{header}\n\n"
            f"🏷 `@{nick}`\n\n"
            f"📊 *{'Перевірка' if lang=='ua' else 'Проверка' if lang=='ru' else 'Status'}:*\n"
            f"├ Telegram: {tg_str}\n"
            f"└ Fragment: {frag_str}{auction_block}\n\n"
            f"🏆 *{'Рейтинг' if lang in ('ua','ru') else 'Rating'}: {grade}* {stars}\n"
            f"`{bar}` {score}/100\n"
            f"{quality_lines}\n\n"
            f"💰 ~{q['value_ton']} TON (~${q['value_usd']})\n"
            f"🔗 [Fragment](https://fragment.com/@{nick}) · [Telegram](https://t.me/{nick})"
        )

# ==============================================================================
# БЛОК 8: КЛАВІАТУРИ
# ==============================================================================
class BOOHXKeyboardFactory:
    @staticmethod
    def language_selection_inline() -> types.InlineKeyboardMarkup:
        m = types.InlineKeyboardMarkup(row_width=1)
        m.add(
            types.InlineKeyboardButton("🇺🇦 Українська", callback_data="set_lang_ua"),
            types.InlineKeyboardButton("🇷🇺 Русский",    callback_data="set_lang_ru"),
            types.InlineKeyboardButton("🇬🇧 English",    callback_data="set_lang_en"),
        )
        return m

    @staticmethod
    def main_reply_menu(lang: str) -> types.ReplyKeyboardMarkup:
        p = LANG_PACKS[lang]
        m = types.ReplyKeyboardMarkup(resize_keyboard=True)
        m.add(types.KeyboardButton(p["btn_search"]),   types.KeyboardButton(p["btn_profile"]))
        m.add(types.KeyboardButton(p["btn_giveaway"]))
        m.add(types.KeyboardButton(p["btn_donate"]),   types.KeyboardButton(p["btn_watch"]))
        m.add(types.KeyboardButton(p["btn_help"]))
        return m

    @staticmethod
    def watchlist_inline(nick: str) -> types.InlineKeyboardMarkup:
        m = types.InlineKeyboardMarkup(row_width=2)
        m.add(
            types.InlineKeyboardButton("🔗 Fragment", url=f"https://fragment.com/@{nick}"),
            types.InlineKeyboardButton("📱 Telegram", url=f"https://t.me/{nick}"),
            types.InlineKeyboardButton("👁 Watch This Nick", callback_data=f"watch_add_{nick}"),
        )
        return m

    @staticmethod
    def select_length_inline(lang: str) -> types.InlineKeyboardMarkup:
        p = LANG_PACKS[lang]
        m = types.InlineKeyboardMarkup(row_width=2)
        m.add(
            types.InlineKeyboardButton(p["len_5"], callback_data="set_len_5"),
            types.InlineKeyboardButton(p["len_6"], callback_data="set_len_6"),
        )
        return m

    @staticmethod
    def donate_menu_inline(lang: str) -> types.InlineKeyboardMarkup:
        m = types.InlineKeyboardMarkup(row_width=1)
        lbl = {
            "ua": {"1m":"🥉 1 місяць — 1 TON","3m":"🥈 3 місяці — 2.5 TON",
                   "lf":"🏆 Назавжди — 5 TON","cp":"📋 Скопіювати адресу"},
            "ru": {"1m":"🥉 1 месяц — 1 TON","3m":"🥈 3 месяца — 2.5 TON",
                   "lf":"🏆 Навсегда — 5 TON","cp":"📋 Скопировать адрес"},
            "en": {"1m":"🥉 1 Month — 1 TON","3m":"🥈 3 Months — 2.5 TON",
                   "lf":"🏆 Lifetime — 5 TON","cp":"📋 Copy Wallet Address"},
        }.get(lang, {
            "1m":"🥉 1 Month","3m":"🥈 3 Months","lf":"🏆 Lifetime","cp":"📋 Copy Address"})
        m.add(types.InlineKeyboardButton(lbl["1m"], callback_data="buy_1m"))
        m.add(types.InlineKeyboardButton(lbl["3m"], callback_data="buy_3m"))
        m.add(types.InlineKeyboardButton(lbl["lf"], callback_data="buy_lf"))
        m.add(types.InlineKeyboardButton(lbl["cp"], callback_data="donate_copy"))
        return m

    @staticmethod
    def payment_check_inline(lang: str) -> types.InlineKeyboardMarkup:
        m = types.InlineKeyboardMarkup(row_width=1)
        lbl = {"ua":"✅ Я оплатив — перевірити",
               "ru":"✅ Я оплатил — проверить",
               "en":"✅ I paid — check now"}.get(lang,"✅ Check")
        m.add(types.InlineKeyboardButton(lbl, callback_data="check_payment"))
        return m

    @staticmethod
    def admin_main_panel() -> types.InlineKeyboardMarkup:
        m = types.InlineKeyboardMarkup(row_width=1)
        m.add(
            types.InlineKeyboardButton("📊 Статистика",         callback_data="adm_stats"),
            types.InlineKeyboardButton("🏆 Топ юзерів",         callback_data="adm_top"),
            types.InlineKeyboardButton("📣 Розсилка",           callback_data="adm_broadcast"),
            types.InlineKeyboardButton("🎉 Запустити Розіграш", callback_data="adm_giveaway"),
            types.InlineKeyboardButton("🏁 Обрати переможця",   callback_data="adm_pick_winner"),
        )
        return m




class BOOHXGiveawayManager:
    def __init__(self):
        self.active = False
        self.prize  = 50
        self.participants: set = set()
        self.lock = threading.Lock()

    def start(self):
        with self.lock:
            self.active = True; self.participants.clear()

    def join(self, uid: int) -> bool:
        with self.lock:
            if not self.active or uid in self.participants: return False
            self.participants.add(uid); return True

    def pick_winner(self) -> Optional[int]:
        with self.lock:
            if not self.participants: return None
            winner = random.choice(list(self.participants))
            self.active = False; return winner

giveaway_server = BOOHXGiveawayManager()
logger.info("[INTERFACE] Модулі ініціалізовано.")

# ==============================================================================
# БЛОК 9: АНТИСПАМ — COOLDOWN
# ==============================================================================
_scan_lock: Dict[int, float] = {}
_scan_lock_mutex = threading.Lock()

def peek_cooldown(user_id: int, is_premium: bool) -> int:
    """Секунди до кінця cooldown (0 = можна сканувати). Не змінює таймер."""
    cd = SCAN_COOLDOWN_PREMIUM_SEC if is_premium else SCAN_COOLDOWN_SEC
    with _scan_lock_mutex:
        last = _scan_lock.get(user_id, 0.0)
        diff = time.time() - last
        if diff < cd:
            return int(cd - diff)
        return 0


def apply_cooldown(user_id: int, is_premium: bool):
    """Фіксує час останнього сканування."""
    with _scan_lock_mutex:
        _scan_lock[user_id] = time.time()

# ==============================================================================
# БЛОК 10: ОБРОБНИКИ
# ==============================================================================
ALL_SEARCH_BTNS = [LANG_PACKS[l]["btn_search"]   for l in LANG_PACKS]
ALL_GIVE_BTNS   = [LANG_PACKS[l]["btn_giveaway"] for l in LANG_PACKS]
ALL_PROF_BTNS   = [LANG_PACKS[l]["btn_profile"]  for l in LANG_PACKS]
ALL_DON_BTNS    = [LANG_PACKS[l]["btn_donate"]   for l in LANG_PACKS]
ALL_HELP_BTNS   = [LANG_PACKS[l]["btn_help"]     for l in LANG_PACKS]
ALL_WATCH_BTNS  = [LANG_PACKS[l]["btn_watch"]    for l in LANG_PACKS]


@bot.message_handler(commands=["start"])
def handle_start(message: types.Message):
    uid = message.from_user.id
    uname = message.from_user.username or f"User_{uid}"
    parts = message.text.split()
    if len(parts) > 1:
        try:
            db_manager.register_referral_link(uid, uname, int(parts[1]))
        except Exception:
            pass
    profile = db_manager.get_user_profile(uid, uname)
    if db_manager.is_banned(uid):
        lang = profile.get("lang", "ua")
        bot.send_message(message.chat.id,
            LANG_PACKS[lang]["banned_msg"].format(support=SUPPORT_USER))
        return
    if profile.get("lang_chosen"):
        lang = profile["lang"]
        if not is_subscribed_to_channel(uid):
            send_subscribe_prompt(message.chat.id, lang)
            return
        bot.send_message(
            message.chat.id,
            LANG_PACKS[lang]["welcome"],
            reply_markup=BOOHXKeyboardFactory.main_reply_menu(lang),
            parse_mode="Markdown",
        )
        return
    bot.send_message(
        message.chat.id,
        "🌐 *BOOHX* — оберіть мову / выберите язык / select language:",
        reply_markup=BOOHXKeyboardFactory.language_selection_inline(),
        parse_mode="Markdown",
    )


@bot.message_handler(commands=["help"])
def handle_help_cmd(message: types.Message):
    profile = db_manager.get_user_profile(message.from_user.id)
    text = LANG_PACKS[profile["lang"]]["help_text"].format(ad_r=AD_REWARD_ATTEMPTS)
    bot.send_message(message.chat.id, text, parse_mode="Markdown")


@bot.message_handler(commands=["mystats"])
def handle_mystats(message: types.Message):
    profile = db_manager.get_user_profile(message.from_user.id,
                                          message.from_user.username or "")
    lang = profile["lang"]
    p = LANG_PACKS[lang]
    st = (p["status_owner"] if profile["is_admin"]
          else p["status_premium"] if profile["is_premium"]
          else p["status_free"])
    puntil = profile["premium_until"]
    if puntil == 0.0 and profile["is_premium"]:
        puntil_str = "∞"
    elif profile["is_premium"] and puntil > 0:
        puntil_str = datetime.fromtimestamp(puntil).strftime("%d.%m.%Y")
    else:
        puntil_str = "—"
    try:
        binfo = bot.get_me()
        ref_link = f"https://t.me/{binfo.username}?start={message.from_user.id}"
    except Exception:
        ref_link = "—"
    text = p["profile_card"].format(
        user_id=message.from_user.id, status=st,
        premium_until=puntil_str, attempts=profile["attempts"],
        scans=profile["total_scans"], referrals=profile["referrals"],
        ref_link=ref_link
    )
    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(types.InlineKeyboardButton(p["btn_change_lang"], callback_data="change_lang_profile"))
    bot.send_message(message.chat.id, text, parse_mode="Markdown", reply_markup=markup)


@bot.message_handler(commands=["profile"])
def handle_profile_search(message: types.Message):
    """
    /profile          — свій профіль (розширений, з знайденими ніками)
    /profile <id>     — чужий профіль (тільки для адміна)
    """
    uid  = message.from_user.id
    own_profile = db_manager.get_user_profile(uid, message.from_user.username or f"User_{uid}")
    lang = own_profile["lang"]
    p    = LANG_PACKS[lang]

    parts = message.text.strip().split()
    target_id: int = uid          # за замовчуванням — свій профіль

    if len(parts) >= 2:
        arg = parts[1].lstrip("@").replace("id", "").strip()
        if not arg.isdigit():  # ID must be positive integer (no negatives, no letters)
            bot.send_message(message.chat.id, p["cmd_profile_usage"], parse_mode="Markdown")
            return
        target_id = int(arg)
        if target_id <= 0:
            bot.send_message(message.chat.id, p["cmd_profile_usage"], parse_mode="Markdown")
            return
        if target_id != uid and not own_profile["is_admin"]:
            bot.send_message(message.chat.id, p["profile_admin_only"])
            return

    # Отримуємо дані по потрібному юзеру
    tdata = db_manager.get_user_by_id(target_id)
    if tdata is None:
        bot.send_message(message.chat.id,
            p["profile_not_found"].format(user_id=target_id), parse_mode="Markdown")
        return

    # Статус
    t_lang = tdata["lang"]
    tp = LANG_PACKS[t_lang]
    if tdata["is_admin"]:
        status_str = LANG_PACKS[lang].get("status_owner", tp["status_owner"])
    elif tdata["is_premium"]:
        status_str = LANG_PACKS[lang].get("status_premium", tp["status_premium"])
    else:
        status_str = LANG_PACKS[lang].get("status_free", tp["status_free"])

    puntil = tdata["premium_until"]
    if puntil == 0.0 and tdata["is_premium"]:
        puntil_str = "∞"
    elif tdata["is_premium"] and puntil > 0:
        puntil_str = datetime.fromtimestamp(puntil).strftime("%d.%m.%Y")
    else:
        puntil_str = "—"

    text = p["profile_search_title"].format(user_id=target_id)
    text += (
        f"├ Username: @{tdata['username']}\n"
        f"├ Статус: *{status_str}*\n"
        f"├ Premium до: *{puntil_str}*\n"
        f"├ Спроби: *{tdata['attempts']}*\n"
        f"├ Сканувань: *{tdata['total_scans']}*\n"
        f"└ Рефералів: *{tdata['referrals']}*\n\n"
    )

    # Знайдені ніки
    found_nicks = db_manager.get_found_nicks_by_user(target_id, limit=20)
    if found_nicks:
        text += p["profile_found_nicks"].format(count=len(found_nicks))
        for nick in found_nicks:
            text += f"  • [`@{nick}`](https://fragment.com/@{nick})\n"
        text += "\n"
    else:
        text += p["profile_no_nicks"] + "\n\n"

    # Watchlist (тільки для адміна або власника)
    if target_id == uid or own_profile["is_admin"]:
        wlist = db_manager.watchlist_get(target_id)
        if wlist:
            text += p["profile_watchlist"].format(count=len(wlist))
            for nick in wlist:
                text += f"  • `@{nick}`\n"
            text += "\n"
        else:
            text += p["profile_no_watchlist"] + "\n\n"

    # Канали — показуємо всім для свого профілю, адміну — для будь-якого
    channels = db_manager.get_channel_usernames(target_id)
    if channels:
        text += p["profile_channels"].format(count=len(channels))
        for ch in channels:
            uname = ch["username"] or "—"
            title = ch["title"] or uname
            text += f"  • 📢 [`@{uname}`](https://t.me/{uname}) — {title}\n"
    elif target_id == uid or own_profile["is_admin"]:
        text += p["profile_no_channels"] + "\n"

    # Клавіатура — кнопка "Додати юз" тільки для власного профілю
    markup = types.InlineKeyboardMarkup(row_width=1)
    if target_id == uid:
        markup.add(types.InlineKeyboardButton(
            p["profile_add_channel_btn"],
            callback_data="profile_add_channel"))

    bot.send_message(message.chat.id, text, parse_mode="Markdown",
                     reply_markup=markup, disable_web_page_preview=True)


@bot.message_handler(commands=["admin"])
def trigger_admin_panel(message: types.Message):
    if not db_manager.get_user_profile(message.from_user.id)["is_admin"]: return
    bot.send_message(message.chat.id, "🛡 *BOOHX Admin Panel:*",
                     reply_markup=BOOHXKeyboardFactory.admin_main_panel(), parse_mode="Markdown")


@bot.message_handler(func=lambda m: m.text in ALL_SEARCH_BTNS)
def trigger_length_selection(message: types.Message):
    profile = db_manager.get_user_profile(message.from_user.id)
    lang = profile["lang"]
    sec = peek_cooldown(message.from_user.id, profile["is_premium"])
    if sec > 0:
        bot.send_message(message.chat.id, LANG_PACKS[lang]["cooldown"].format(sec=sec))
        return
    bot.send_message(message.chat.id, LANG_PACKS[lang]["select_len"],
                     reply_markup=BOOHXKeyboardFactory.select_length_inline(lang),
                     parse_mode="Markdown")



@bot.message_handler(func=lambda m: m.text in ALL_GIVE_BTNS)
def trigger_giveaway_view(message: types.Message):
    profile = db_manager.get_user_profile(message.from_user.id)
    lang = profile["lang"]
    p = LANG_PACKS[lang]
    if not giveaway_server.active:
        bot.send_message(message.chat.id, p["giveaway_no_active"])
        return
    markup = types.InlineKeyboardMarkup()
    markup.add(types.InlineKeyboardButton(p["giveaway_btn_join"], callback_data="giveaway_enter"))
    bot.send_message(message.chat.id,
                     p["giveaway_active"].format(prize=giveaway_server.prize),
                     reply_markup=markup, parse_mode="Markdown")


@bot.message_handler(func=lambda m: m.text in ALL_PROF_BTNS)
def display_user_profile(message: types.Message):
    handle_mystats(message)


@bot.message_handler(func=lambda m: m.text in ALL_DON_BTNS)
def trigger_donate_menu(message: types.Message):
    profile = db_manager.get_user_profile(message.from_user.id)
    lang = profile["lang"]
    text = LANG_PACKS[lang]["donate_menu"].format(
        usd_1m=int(1.0*TON_RATE), usd_3m=int(2.5*TON_RATE), usd_lf=int(5.0*TON_RATE)
    )
    bot.send_message(message.chat.id, text,
                     reply_markup=BOOHXKeyboardFactory.donate_menu_inline(lang),
                     parse_mode="Markdown")


@bot.message_handler(func=lambda m: m.text in ALL_HELP_BTNS)
def trigger_help(message: types.Message):
    profile = db_manager.get_user_profile(message.from_user.id)
    text = LANG_PACKS[profile["lang"]]["help_text"].format(ad_r=AD_REWARD_ATTEMPTS)
    bot.send_message(message.chat.id, text, parse_mode="Markdown")


@bot.message_handler(func=lambda m: m.text in ALL_WATCH_BTNS)
def trigger_watchlist_menu(message: types.Message):
    profile = db_manager.get_user_profile(message.from_user.id)
    lang = profile["lang"]
    p = LANG_PACKS[lang]
    nicks = db_manager.watchlist_get(message.from_user.id)
    if not nicks:
        bot.send_message(message.chat.id, p["watch_empty"], parse_mode="Markdown")
        return
    lines = p["watch_list_header"].format(count=len(nicks))
    for i, nick in enumerate(nicks, 1):
        lines += f"{i}. `@{nick}`\n"
    lines += p["watch_footer"]
    bot.send_message(message.chat.id, lines, parse_mode="Markdown")


@bot.message_handler(commands=["watch"])
def handle_watch_cmd(message: types.Message):
    uid = message.from_user.id
    profile = db_manager.get_user_profile(uid)
    lang = profile["lang"]
    p = LANG_PACKS[lang]
    parts = message.text.split()
    if len(parts) < 2:
        bot.send_message(message.chat.id, p["watch_usage"], parse_mode="Markdown")
        return
    nick = parts[1].lstrip("@").lower()
    if len(nick) < 4:
        bot.send_message(message.chat.id, "⚠️ Нік занадто короткий (мін. 4 символи).")
        return
    # Premium — без ліміту, free — ліміт 3
    if profile["is_premium"] or profile["is_admin"]:
        result = db_manager.watchlist_add_premium(uid, nick)
    else:
        result = db_manager.watchlist_add(uid, nick)
    if result == "added":
        bot.send_message(message.chat.id, p["watch_added"].format(nick=nick), parse_mode="Markdown")
    elif result == "exists":
        bot.send_message(message.chat.id, p["watch_exists"].format(nick=nick), parse_mode="Markdown")
    elif result == "limit":
        bot.send_message(message.chat.id, p["watch_limit"], parse_mode="Markdown")


@bot.message_handler(commands=["unwatch"])
def handle_unwatch_cmd(message: types.Message):
    uid = message.from_user.id
    profile = db_manager.get_user_profile(uid)
    lang = profile["lang"]
    p = LANG_PACKS[lang]
    parts = message.text.split()
    if len(parts) < 2:
        bot.send_message(message.chat.id, "/unwatch @username", parse_mode="Markdown")
        return
    nick = parts[1].lstrip("@").lower()
    removed = db_manager.watchlist_remove(uid, nick)
    if removed:
        bot.send_message(message.chat.id, p["watch_removed"].format(nick=nick), parse_mode="Markdown")
    else:
        bot.send_message(message.chat.id, p["watch_not_found"].format(nick=nick), parse_mode="Markdown")


@bot.message_handler(commands=["watchlist"])
def handle_watchlist_cmd(message: types.Message):
    trigger_watchlist_menu(message)


# ==============================================================================
# БЛОК 10b: /scan, /myref, /ad, /stats, /revenue
# ==============================================================================
@bot.message_handler(commands=["scan"])
def handle_scan_cmd(message: types.Message):
    uid = message.from_user.id
    if db_manager.is_banned(uid):
        return
    profile = db_manager.get_user_profile(uid)
    lang = profile["lang"]
    p = LANG_PACKS[lang]
    is_vip = profile["is_premium"] or profile["is_admin"]
    limit = MULTI_SCAN_LIMIT_PREMIUM if is_vip else MULTI_SCAN_LIMIT_FREE

    parts = message.text.split()[1:]
    nicks = [n.lstrip("@").lower() for n in parts if n.startswith("@") or len(n) >= 4][:limit]
    if not nicks:
        bot.send_message(message.chat.id,
            p["scan_usage"].format(limit=limit), parse_mode="Markdown")
        return

    def _run():
        status = bot.send_message(message.chat.id,
            p["scan_running"].format(count=len(nicks)), parse_mode="Markdown")

        checked = parallel_check_list(nicks, workers=min(len(nicks), 8),
                                      cache=_ENGINE_CACHE)
        rows = []
        for r in checked:
            n    = r["nick"]
            frag = r.get("frag", "unknown")
            if r.get("is_free"):
                row = p["scan_row_free"].format(nick=n)
                if not r.get("confirmed"):
                    row += " " + UNCONFIRMED_NOTE.get(lang, UNCONFIRMED_NOTE["en"])
            elif frag in ("auction", "sale"):
                row = p["scan_row_auction"].format(nick=n, price="—")
            elif frag == "invalid" or r.get("verify") in ("invalid", "error"):
                row = p["scan_row_unknown"].format(nick=n)
            else:
                row = p["scan_row_taken"].format(nick=n)
            rows.append(row)

        try: bot.delete_message(message.chat.id, status.message_id)
        except Exception: pass
        text = p["scan_header"].format(count=len(rows)) + "\n".join(rows)
        bot.send_message(message.chat.id, text, parse_mode="Markdown")

    threading.Thread(target=_run, daemon=True).start()


@bot.message_handler(commands=["myref"])
def handle_myref_cmd(message: types.Message):
    uid = message.from_user.id
    if db_manager.is_banned(uid):
        return
    profile = db_manager.get_user_profile(uid)
    lang = profile["lang"]
    p = LANG_PACKS[lang]
    bot_username = bot.get_me().username
    ref_link = f"https://t.me/{bot_username}?start={uid}"
    refs = db_manager.get_referred_users(uid)
    if not refs:
        bot.send_message(message.chat.id,
            p["myref_empty"].format(ref_link=ref_link), parse_mode="Markdown")
        return
    lines = p["myref_header"].format(count=len(refs))
    for i, (rid, rname) in enumerate(refs, 1):
        lines += f"{i}. @{rname} (`{rid}`)\n"
    bot.send_message(message.chat.id, lines, parse_mode="Markdown")


@bot.message_handler(commands=["ad"])
def handle_ad_cmd(message: types.Message):
    uid = message.from_user.id
    if db_manager.is_banned(uid):
        return
    profile = db_manager.get_user_profile(uid)
    lang = profile["lang"]
    p = LANG_PACKS[lang]
    if not db_manager.can_claim_ad(uid):
        bot.send_message(message.chat.id,
            p["ad_cooldown"].format(hours=AD_COOLDOWN_HOURS), parse_mode="Markdown")
        return
    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(types.InlineKeyboardButton(p["ad_btn_view"], url=AD_LINK))
    markup.add(types.InlineKeyboardButton(p["ad_btn_claim"], callback_data="ad_claim"))
    bot.send_message(message.chat.id,
        p["ad_text"].format(reward=AD_REWARD_ATTEMPTS, hours=AD_COOLDOWN_HOURS),
        reply_markup=markup, parse_mode="Markdown")


@bot.message_handler(commands=["stats"])
def handle_stats_cmd(message: types.Message):
    uid = message.from_user.id
    if db_manager.is_banned(uid):
        return
    profile = db_manager.get_user_profile(uid)
    lang = profile["lang"]
    p = LANG_PACKS[lang]
    if not profile["is_premium"] and not profile["is_admin"]:
        bot.send_message(message.chat.id, p["stats_premium_only"], parse_mode="Markdown")
        return
    nick_stats = db_manager.get_nicks_stats()
    total_u  = db_manager.count_users()
    premium_u = db_manager.count_premium()
    bot.send_message(message.chat.id,
        p["stats_text"].format(
            today=nick_stats["today"], week=nick_stats["week"],
            total=nick_stats["total"], users=total_u, premium=premium_u),
        parse_mode="Markdown")


@bot.message_handler(commands=["revenue"])
def handle_revenue_cmd(message: types.Message):
    uid = message.from_user.id
    if not db_manager.get_user_profile(uid)["is_admin"]:
        return
    rev = db_manager.get_revenue_stats()
    partners = db_manager.get_all_partners()
    plines = ""
    for pid, pname, pct, rcount, pTON in partners:
        plines += f"\n  @{pname or pid} {pct}% · {rcount} ref · {pTON:.3f} TON"
    bot.send_message(message.chat.id,
        f"💰 *BOOHX Revenue Dashboard:*\n\n"
        f"├ Сьогодні: `{rev['day']} TON`\n"
        f"├ Тиждень: `{rev['week']} TON`\n"
        f"├ Місяць: `{rev['month']} TON`\n"
        f"└ Всього: `{rev['total']} TON`\n"
        f"\n👥 *Партнери:*{plines or ' —'}",
        parse_mode="Markdown")


def _instant_check_thread(chat_id: int, user_id: int, nick: str, lang: str):
    """Детальна перевірка конкретного ніку з повним звітом."""
    p = LANG_PACKS[lang]
    status_msg = bot.send_message(chat_id, p["watch_check_now"].format(nick=nick), parse_mode="Markdown")
    try:
        r = check_single(nick, cache=_ENGINE_CACHE)
        try: bot.delete_message(chat_id, status_msg.message_id)
        except Exception: pass

        # Будуємо data-об'єкт сумісний з BOOHXAnalyticMatrix
        q = r.get("quality")
        data = {
            "username": nick,
            "tg_free":  r.get("is_free", False),
            "verify":   r.get("verify", ""),
            "confirmed": r.get("confirmed", False),
            "tg_error": r.get("tg") is None,
            "frag": {
                "status":        r.get("frag", "unknown"),
                "auction_price": None, "auction_bids": None,
                "auction_ends":  None, "buy_now":      None,
            },
            "quality": {
                "score":     q.score            if q else 0,
                "grade":     q.grade            if q else "—",
                "stars":     q.stars            if q else "",
                "value_ton": q.estimated_ton_lo if q else 0,
                "value_usd": 0,
                "length":    q.length           if q else len(nick),
                "details":   [],
            },
        }

        try:
            report = BOOHXAnalyticMatrix.generate_deep_check_report(data, lang)
        except Exception:
            if r.get("is_free"):
                report = "✅ *@" + nick + "* — ВІЛЬНИЙ!"
                if not r.get("confirmed"):
                    report += "\n" + UNCONFIRMED_NOTE.get(lang, UNCONFIRMED_NOTE["en"])
            elif r.get("verify") == "error":
                report = "❓ *@" + nick + "* — не вдалося перевірити, спробуйте пізніше."
            else:
                report = "🔒 *@" + nick + "* — недоступний."

        markup = types.InlineKeyboardMarkup(row_width=2)
        markup.add(
            types.InlineKeyboardButton("🔗 Fragment", url=f"https://fragment.com/@{nick}"),
            types.InlineKeyboardButton("📱 Telegram", url=f"https://t.me/{nick}"),
        )
        markup.add(types.InlineKeyboardButton(
            "👁 Watch This Nick", callback_data=f"watch_add_{nick}"))

        bot.send_message(chat_id, report, parse_mode="Markdown", reply_markup=markup)
    except Exception as e:
        logger.warning(f"[INSTANT_CHECK] Помилка: {e}")
        try: bot.delete_message(chat_id, status_msg.message_id)
        except Exception: pass


@bot.message_handler(func=lambda m: m.text and m.text.strip().startswith("@")
                     and len(m.text.strip()) >= 5
                     and " " not in m.text.strip()
                     and m.text.strip() not in ALL_SEARCH_BTNS + ALL_GIVE_BTNS
                       + ALL_PROF_BTNS + ALL_DON_BTNS + ALL_HELP_BTNS + ALL_WATCH_BTNS)
def handle_at_username_check(message: types.Message):
    """Користувач надсилає @username — миттєва перевірка."""
    uid = message.from_user.id
    nick = message.text.strip().lstrip("@").lower()
    if len(nick) < 4:
        return
    if db_manager.is_banned(uid):
        return
    # Антіспам для @username перевірок
    with _at_check_lock:
        last = _at_check_times.get(uid, 0.0)
        wait = AT_CHECK_COOLDOWN_SEC - (time.time() - last)
        if wait > 0:
            profile = db_manager.get_user_profile(uid)
            lang = profile["lang"]
            if not profile["is_premium"] and not profile["is_admin"]:
                bot.send_message(message.chat.id,
                    LANG_PACKS[lang]["at_cooldown"].format(sec=int(wait)+1))
                return
        _at_check_times[uid] = time.time()
    profile = db_manager.get_user_profile(uid)
    lang = profile["lang"]
    threading.Thread(
        target=_instant_check_thread,
        args=(message.chat.id, uid, nick, lang),
        daemon=True
    ).start()


# ==============================================================================
# БЛОК 11: ЛОГІКА СКАНУВАННЯ (В ПОТОЦІ)
# ==============================================================================
def run_actual_nickname_scan(chat_id: int, user_id: int, length: int, lang: str):
    profile = db_manager.get_user_profile(user_id)
    p = LANG_PACKS[lang]
    is_vip = profile["is_admin"] or profile["is_premium"]

    if profile["attempts"] <= 0 and not is_vip:
        bot.send_message(chat_id, p["no_attempts"])
        return

    sec = peek_cooldown(user_id, profile["is_premium"])
    if sec > 0:
        bot.send_message(chat_id, p["cooldown"].format(sec=sec))
        return
    apply_cooldown(user_id, profile["is_premium"])

    # Пріоритет: Premium/Admin скани не чекають у черзі
    acquired = False
    if not is_vip:
        acquired = _FREE_SCAN_SEMAPHORE.acquire(timeout=60)
        if not acquired:
            bot.send_message(chat_id, "⏳ Сервер зайнятий, спробуйте ще раз через хвилину.")
            return
    try:
      _run_scan_inner(chat_id, user_id, length, lang, profile, p, is_vip)
    finally:
      if acquired:
          try: _FREE_SCAN_SEMAPHORE.release()
          except Exception: pass


def _run_scan_inner(chat_id, user_id, length, lang, profile, p, is_vip):
    status_msg = bot.send_message(chat_id, p["scanning"])

    def _edit(text, cid, mid, **kwargs):
        try: bot.edit_message_text(text, cid, mid, **kwargs)
        except Exception: pass

    result = find_free_username_fast(
        chat_id=chat_id,
        msg_id=status_msg.message_id,
        bot_send_fn=lambda txt: None,
        bot_edit_fn=_edit,
        length=length,
        max_workers=20,
        lang=lang,
        db_dir=_BASE_DIR,
    )

    if not profile["is_admin"] and not profile["is_premium"]:
        db_manager.update_user_field(user_id, "attempts", max(0, profile["attempts"]-1))
    db_manager.increment_scans(user_id)

    try: bot.delete_message(chat_id, status_msg.message_id)
    except Exception: pass

    if result:
        found_nick = result.nick
        db_manager.save_found_nick(found_nick, length, user_id)
        with open(OUTPUT_FILE, "a", encoding="utf-8") as f:
            f.write(f"{found_nick}\n")
        frag_data = {
            "status": result.frag_status,
            "auction_price": None, "auction_bids": None,
            "auction_ends":  None, "buy_now":      None,
            "confirmed": result.confirmed,
        }
        report = BOOHXAnalyticMatrix.generate_fragment_report(found_nick, lang, frag_data)
        markup = types.InlineKeyboardMarkup(row_width=2)
        markup.add(
            types.InlineKeyboardButton("🔗 Fragment", url=f"https://fragment.com/@{found_nick}"),
            types.InlineKeyboardButton("📱 Telegram", url=f"https://t.me/{found_nick}"),
        )
        markup.add(types.InlineKeyboardButton(
            p["btn_nick_details"], callback_data=f"nick_details_{found_nick}"))
        markup.add(types.InlineKeyboardButton(
            "👁 Watch This Nick", callback_data=f"watch_add_{found_nick}"))
        markup.add(types.InlineKeyboardButton(
            p["sell_nick_btn"], callback_data=f"sell_nick_{found_nick}"))
        bot.send_message(chat_id, report, reply_markup=markup, parse_mode="Markdown")
    else:
        bot.send_message(chat_id, p["not_found"])


# ==============================================================================
# БЛОК 11b: ПОШУК ПО КЛЮЧОВОМУ СЛОВУ (/find)
# ==============================================================================
class KeywordVariantEngine:
    """Генерує смислові варіації імен з ключового слова — покращена v2.

    Нові стратегії:
    - CVCVCV-padding: обгортаємо keyword у вокально-консонантні склади
    - Складові (syllable) суфікси/префікси: -bo, -ki, -ra, та-, ко- тощо
    - Ліквідне ранжування кандидатів
    """
    AFFIXES_PRE  = ["x","go","my","on","ai","io","up","be","we","do","ok","ur","iv",
                     "neo","pro","max","big","key","hot","top","vi","ze","bo","ka","ro"]
    AFFIXES_SUF  = ["x","ly","fy","io","co","me","ai","hub","lab","bit","bot","net",
                     "pro","app","dev","xyz","hq","ok","on","up","ro","ka","bo","zi","vu"]
    VOWELS       = "aeiou"
    CONSONANTS   = "bcdfghjklmnpqrstvwxyz"

    # Склади для красивого обгортання: це CV-пари, що добре звучать
    _SYLLS = [
        "ba","bo","be","bi","bu",
        "ca","co","ce","ci","cu",
        "ka","ko","ke","ki","ku",
        "ra","ro","re","ri","ru",
        "za","zo","ze","zi","zu",
        "ta","to","te","ti","tu",
        "la","lo","le","li","lu",
        "ma","mo","me","mi","mu",
        "sa","so","se","si","su",
        "fa","fo","fe","fi","fu",
        "va","vo","ve","vi","vu",
        "na","no","ne","ni","nu",
        "ga","go","ge","gi","gu",
        "pa","po","pe","pi","pu",
        "wa","wo","we","wi",
    ]

    @classmethod
    def generate_variants(cls, word: str, target_len: int = 5, count: int = 30) -> List[str]:
        """
        Генерує варіанти ТОЧНО target_len довжиною з НЕЗМІНЕНИМ keyword всередині.

        Нові стратегії v2:
        - CVCVCV-syllable padding: tonbo (ton+bo), rabtok (ra+bt+ok)
        - Keyword у середині зі складовими обгортками

        Keyword ніколи не обрізається і не змінюється.
        """
        word = word.lower().strip()
        wlen = len(word)
        need = target_len - wlen

        variants: set = set()
        alpha = "abcdefghijklmnopqrstuvwxyz"
        V, C = cls.VOWELS, cls.CONSONANTS
        SYLLS = cls._SYLLS

        if need < 0:
            return []
        if need == 0:
            v = word
            if re.fullmatch(r"[a-z][a-z0-9]{3,31}", v):
                return [v]
            return []

        def _add(v: str):
            v = v.lower()
            if (len(v) == target_len
                    and re.fullmatch(r"[a-z][a-z0-9]{3,31}", v)):
                variants.add(v)

        # ── CVCVCV-syllable padding (нова стратегія) ─────────────────────────
        # Обгортаємо слово у склади так, щоб вийшло target_len
        if need == 1:
            # 1 символ зліва або справа — вибираємо голосний/приголосний
            # щоб краще звучало залежно від першого/останнього символу слова
            first, last = word[0], word[-1]
            for ch in alpha:
                # зліва: якщо слово починається на приголосний — ставимо голосний
                _add(ch + word)
                _add(word + ch)
            # Пріоритет: CV-склад одним символом (голосний + початок слова)
            for syl in SYLLS:
                _add(syl[0] + word)   # тільки перший символ складу
                _add(word + syl[0])

        elif need == 2:
            # ★ CVCVCV: цілий склад зліва або справа
            for syl in SYLLS:
                _add(syl + word)    # склад зліва: "bo" + "ton" = "boton"
                _add(word + syl)    # склад справа: "ton" + "bo" = "tonbo"
            # Симетрично: ch+word+ch
            for ch in alpha:
                _add(ch + word + ch)
            # 2 зліва / 2 справа
            for c1 in alpha:
                for c2 in alpha:
                    _add(c1 + c2 + word)
                    _add(word + c1 + c2)
                if len(variants) > count * 12:
                    break
            # Змістовні 2-char prefix/suffix
            for pre in cls.AFFIXES_PRE:
                if len(pre) == 2:
                    _add(pre + word)
            for suf in cls.AFFIXES_SUF:
                if len(suf) == 2:
                    _add(word + suf)

        elif need == 3:
            # ★ 3 символи = 1 склад (2) + 1 символ  або  1 + 1 склад
            for syl in SYLLS:
                for ch in alpha:
                    _add(syl + word + ch)     # "bo" + "ton" + "x" = "botonx"
                    _add(ch + word + syl)     # "x" + "ton" + "bo" = "xtonbo"
                    _add(syl + ch + word)     # "bo" + "x" + "ton" = "boxton"
                    _add(word + syl + ch)     # "ton" + "bo" + "x" = "tonbox"
                    _add(word + ch + syl)     # "ton" + "x" + "bo" = "tonxbo"
                if len(variants) > count * 8:
                    break
            # 2 склади? ні — збільшуємо від prefix/suffix
            for pre in cls.AFFIXES_PRE:
                if len(pre) == 3:
                    _add(pre + word)
            for suf in cls.AFFIXES_SUF:
                if len(suf) == 3:
                    _add(word + suf)
            # 1+2: c + syl перед/після
            for ch in alpha:
                for syl in SYLLS:
                    _add(ch + syl + word)
                    _add(word + ch + syl)
                    _add(syl + word + ch)
                if len(variants) > count * 20:
                    break
            # 3 зліва / 3 справа
            for c1 in alpha:
                for c2 in alpha:
                    for c3 in alpha:
                        _add(c1 + c2 + c3 + word)
                        _add(word + c1 + c2 + c3)
                    if len(variants) > count * 30:
                        break
                if len(variants) > count * 30:
                    break

        else:
            # need >= 4: keyword дуже короткий
            # 2 склади навколо
            for s1 in SYLLS:
                for s2 in SYLLS:
                    _add(s1 + word + s2)      # "bo" + "kw" + "zi" = "bokwzi" (6)
                    _add(s1 + s2 + word)
                    _add(word + s1 + s2)
                if len(variants) > count * 10:
                    break
            for pre in cls.AFFIXES_PRE:
                _add(pre + word)
                for ch in alpha:
                    _add(ch + pre + word)
                    _add(pre + word + ch)
            for suf in cls.AFFIXES_SUF:
                _add(word + suf)
                for ch in alpha:
                    _add(word + suf + ch)
                    _add(ch + word + suf)
            # Без голосних + обгортка (bitcoin → btc + padding)
            no_vowels = "".join(c for c in word if c not in V)
            if 3 <= len(no_vowels) < wlen:
                nv_need = target_len - len(no_vowels)
                if nv_need == 1:
                    for ch in alpha:
                        _add(no_vowels + ch)
                        _add(ch + no_vowels)
                elif nv_need == 2:
                    for syl in SYLLS:
                        _add(no_vowels + syl)
                        _add(syl + no_vowels)
                    for ch in alpha:
                        _add(ch + no_vowels + ch)
                elif nv_need >= 3:
                    for s1 in SYLLS:
                        _add(s1 + no_vowels)
                        _add(no_vowels + s1)

        # Фільтр + ранжування за ліквідністю
        valid = [v for v in variants
                 if len(v) == target_len and re.fullmatch(r"[a-z][a-z0-9]{3,31}", v)]
        # Сортуємо: спочатку ті, що містять голосні (більш вимовні), потім решта
        def _pronounce_score(n: str) -> int:
            vowels_in = sum(1 for c in n if c in V)
            ratio = vowels_in / len(n) if n else 0
            return 100 if 0.3 <= ratio <= 0.6 else (50 if ratio > 0 else 0)
        valid.sort(key=_pronounce_score, reverse=True)
        return valid[:count]


# ==============================================================================
# БЛОК 11c: AI РАНКЕР ЛІКВІДНОСТІ
# ==============================================================================
class NickLiquidityRanker:
    """
    Оцінює кандидатів за ліквідністю — шанс швидко продати на Fragment.
    Враховує: довжину, вимовність, наявність крипто-слів, структуру.
    Повертає список відсортованих (score, nick).
    """
    CRYPTO_WORDS = {
        "ton", "btc", "eth", "sol", "nft", "defi", "dao", "web3",
        "gem", "moon", "bull", "bear", "ape", "dex", "bot", "lab",
        "pro", "max", "neo", "hub", "key", "top", "hot", "big",
        "ton", "tron", "link", "uni", "avax", "dot", "ada", "xrp",
        "meta", "pixel", "chain", "vault", "swap", "mint", "drop",
    }
    VOWELS = set("aeiou")

    @classmethod
    def score(cls, nick: str) -> int:
        """Повертає score 0–100 для ніку. Вищий = ліквідніший."""
        s = 0
        n = nick.lower()
        ln = len(n)

        # Довжина: коротший = ліквідніший
        if ln == 4:   s += 40
        elif ln == 5: s += 30
        elif ln == 6: s += 20
        elif ln == 7: s += 10
        else:         s += 3

        # Тільки літери (без цифр/підкреслень) — великий плюс
        if n.isalpha():
            s += 15

        # Наявність крипто-слова всередині
        for word in cls.CRYPTO_WORDS:
            if word in n:
                s += 20
                break

        # Вимовність: чергування голосних-приголосних
        vowels_in = sum(1 for c in n if c in cls.VOWELS)
        if 0 < vowels_in < ln:
            ratio = vowels_in / ln
            if 0.3 <= ratio <= 0.6:
                s += 12
            elif 0.2 <= ratio < 0.3 or 0.6 < ratio <= 0.7:
                s += 6

        # Відсутність довгих приголосних блоків (max 2 підряд)
        cons_run = 0
        max_run = 0
        for c in n:
            if c not in cls.VOWELS and c.isalpha():
                cons_run += 1
                max_run = max(max_run, cons_run)
            else:
                cons_run = 0
        if max_run <= 2:
            s += 10

        # Бонус за брендові початки (ton, pro, max, neo, key...)
        brand_starts = ["ton","pro","max","neo","key","hot","big","top","hub","lab","gem","btc","eth","sol"]
        for bp in brand_starts:
            if n.startswith(bp):
                s += 8
                break

        # Бонус за брендові кінці
        brand_ends = ["ton","bot","hub","lab","pro","max","key","io","ai","ly","fx"]
        for be in brand_ends:
            if n.endswith(be):
                s += 5
                break

        # Унікальність символів (без повторів підряд)
        has_double = any(n[i] == n[i+1] for i in range(len(n)-1))
        if not has_double:
            s += 5

        return min(s, 100)

    @classmethod
    def rank(cls, nicks: List[str]) -> List[str]:
        """Повертає відсортований список ніків (найліквідніші — перші)."""
        scored = [(cls.score(n), n) for n in nicks]
        scored.sort(key=lambda x: x[0], reverse=True)
        return [n for _, n in scored]

    @classmethod
    def liquidity_label(cls, nick: str, lang: str) -> str:
        s = cls.score(nick)
        if s >= 70:
            return {"ua": "🔥 Дуже висока", "ru": "🔥 Очень высокая", "en": "🔥 Very High"}.get(lang, "🔥 Very High")
        if s >= 50:
            return {"ua": "🔶 Висока", "ru": "🔶 Высокая", "en": "🔶 High"}.get(lang, "🔶 High")
        if s >= 35:
            return {"ua": "🟡 Середня", "ru": "🟡 Средняя", "en": "🟡 Medium"}.get(lang, "🟡 Medium")
        return {"ua": "🔵 Низька", "ru": "🔵 Низкая", "en": "🔵 Low"}.get(lang, "🔵 Low")


# ==============================================================================
# БЛОК 11d: AI КРИПТО-СЕМАНТИчНИЙ ГЕНЕРАТОР НІКІВ (Premium)
# ==============================================================================
class CryptoSemanticNickEngine:
    """
    Генерує осмислені крипто-ніки у стилі: legalTon, TonJoker, GemVault, MoonBull…
    Використовує комбінації: [прикметник/роль] + [крипто-слово] або навпаки.
    """

    # Крипто-валюти / екосистеми
    CRYPTO_TOKENS = [
        "ton", "btc", "eth", "sol", "bnb", "avax", "dot", "ada",
        "link", "uni", "near", "ftm", "xrp", "trx", "matic",
    ]

    # Семантичні префікси (роль / якість)
    PREFIX_WORDS = [
        "legal", "royal", "black", "dark", "gold", "ultra", "mega",
        "super", "alpha", "sigma", "elite", "hyper", "turbo", "cyber",
        "defi", "degen", "quick", "vault", "smart", "swift", "sonic",
        "power", "prime", "storm", "ghost", "pixel", "block", "chain",
        "flash", "stark", "noble", "lunar", "solar", "night", "neon",
        "brave", "sharp", "steel", "titan", "omega", "virus", "laser",
    ]

    # Семантичні суфікси (роль / жарт / дія)
    SUFFIX_WORDS = [
        "joker", "maker", "rider", "hater", "bro", "king", "pro",
        "boss", "wolf", "bull", "bear", "gem", "lab", "hub", "dao",
        "dex", "bot", "vault", "drop", "swap", "mint", "nerd", "lord",
        "guru", "monk", "hero", "mage", "sage", "ape", "dev", "hq",
        "club", "gang", "zone", "core", "plus", "node", "fund", "max",
    ]

    # Крипто-теми для більш тематичних комбінацій
    CRYPTO_THEMES = {
        "ton": ["ton", "gram", "toncoin", "tonvault", "tonhub"],
        "eth": ["eth", "ether", "defi", "wei", "gwei"],
        "btc": ["btc", "bitcoin", "sats", "block", "chain"],
        "nft": ["nft", "mint", "drop", "pixel", "trait"],
        "defi": ["swap", "vault", "yield", "pool", "farm"],
        "meme": ["ape", "doge", "pepe", "frog", "moon", "gem"],
    }

    @classmethod
    def generate_semantic_candidates(cls, theme: str = "ton", count: int = 200) -> List[str]:
        """
        Генерує семантично осмислені крипто-ніки.
        Довжина: 5–8 символів. Тільки a-z.
        """
        candidates: set = set()
        theme_tokens = cls.CRYPTO_THEMES.get(theme, cls.CRYPTO_TOKENS[:5])

        def _add(v: str):
            v = v.lower()
            if 5 <= len(v) <= 8 and re.fullmatch(r"[a-z][a-z]{4,7}", v):
                candidates.add(v)

        for token in theme_tokens:
            for prefix in cls.PREFIX_WORDS:
                combo = prefix + token
                _add(combo)
                combo2 = token + prefix[:3]
                _add(combo2)

            for suffix in cls.SUFFIX_WORDS:
                combo = token + suffix
                _add(combo)
                combo2 = suffix[:3] + token
                _add(combo2)

        # Прямі комбінації prefix+suffix без токена (але пов'язані з крипто)
        crypto_short = ["ton", "eth", "btc", "sol", "nft", "gem", "dao", "dex"]
        for cs in crypto_short:
            for prefix in cls.PREFIX_WORDS:
                for suffix in cls.SUFFIX_WORDS:
                    combo = prefix[:3] + cs + suffix[:2]
                    _add(combo)
                    combo2 = prefix[:2] + cs + suffix[:3]
                    _add(combo2)
                    if len(candidates) > count * 5:
                        break
                if len(candidates) > count * 5:
                    break

        all_cands = list(candidates)
        # Сортуємо за ліквідністю — найкращі першими
        ranked = NickLiquidityRanker.rank(all_cands)
        return ranked[:count]

    @classmethod
    def generate_from_keyword(cls, keyword: str, count: int = 200) -> List[str]:
        """
        Генерує ніки пов'язані з keyword.
        Тільки a-z (без цифр!), довжина 5–12 символів.
        Ранжує за ліквідністю.
        """
        keyword = keyword.lower().strip()
        candidates: set = set()

        def _add(v: str):
            v = v.lower()
            if 5 <= len(v) <= 12 and re.fullmatch(r"[a-z]+", v):
                candidates.add(v)

        # keyword + суфікс / префікс + keyword
        for suf in cls.SUFFIX_WORDS:
            _add(keyword + suf)
            _add(suf + keyword)
            _add(keyword + suf[:2])
            _add(keyword + suf[:3])
            _add(suf[:2] + keyword)
            _add(suf[:3] + keyword)

        for pre in cls.PREFIX_WORDS:
            _add(pre + keyword)
            _add(keyword + pre)
            _add(pre[:2] + keyword)
            _add(pre[:3] + keyword)
            _add(keyword + pre[:2])
            _add(keyword + pre[:3])

        # keyword + крипто-токен
        for token in cls.CRYPTO_TOKENS[:10]:
            _add(keyword + token)
            _add(token + keyword)
            for suf in cls.SUFFIX_WORDS[:12]:
                _add(keyword + token[:2] + suf[:2])
                _add(token[:3] + keyword + suf[:2])
                if len(candidates) > count * 4:
                    break

        # 3-way: prefix + keyword + suffix
        for pre in cls.PREFIX_WORDS[:20]:
            for suf in cls.SUFFIX_WORDS[:20]:
                _add(pre[:2] + keyword + suf[:2])
                _add(pre[:3] + keyword + suf[:1])
                _add(pre[:1] + keyword + suf[:3])
                if len(candidates) > count * 6:
                    break
            if len(candidates) > count * 6:
                break

        all_cands = list(candidates)
        ranked = NickLiquidityRanker.rank(all_cands)
        return ranked[:count]

    @classmethod
    def get_theme_label(cls, theme: str, lang: str) -> str:
        labels = {
            "ton": {"ua": "TON екосистема", "ru": "TON экосистема", "en": "TON ecosystem"},
            "eth": {"ua": "Ethereum / DeFi", "ru": "Ethereum / DeFi", "en": "Ethereum / DeFi"},
            "btc": {"ua": "Bitcoin / Crypto", "ru": "Bitcoin / Crypto", "en": "Bitcoin / Crypto"},
            "nft": {"ua": "NFT / Mint", "ru": "NFT / Mint", "en": "NFT / Mint"},
            "defi": {"ua": "DeFi / Yield", "ru": "DeFi / Yield", "en": "DeFi / Yield"},
            "meme": {"ua": "Meme / Ape", "ru": "Meme / Ape", "en": "Meme / Ape"},
        }
        return labels.get(theme, {}).get(lang, theme.upper())


def run_nickai_find(chat_id: int, user_id: int, keyword: str, lang: str):
    """Premium: AI пошук осмислених крипто-ніків за ключовим словом.
    Тільки літери (a-z), довжина 5-12. Подвійна перевірка TG+Fragment.
    """
    p = LANG_PACKS[lang]
    profile = db_manager.get_user_profile(user_id)

    sec = peek_cooldown(user_id, True)
    if sec > 0:
        bot.send_message(chat_id, p["cooldown"].format(sec=sec))
        return
    apply_cooldown(user_id, profile["is_premium"])

    start_texts = {
        "ua": (
            f"🤖 *AI крипто-сканер* запущено!\n"
            f"🔑 Ключове слово: *{keyword}*\n\n"
            f"⏳ Генерую ніки тільки з літер та перевіряю наявність..."
        ),
        "ru": (
            f"🤖 *AI крипто-сканер* запущен!\n"
            f"🔑 Ключевое слово: *{keyword}*\n\n"
            f"⏳ Генерирую буквенные ники и проверяю доступность..."
        ),
        "en": (
            f"🤖 *AI crypto scanner* started!\n"
            f"🔑 Keyword: *{keyword}*\n\n"
            f"⏳ Generating letters-only nicks and checking availability..."
        ),
    }
    status_msg = bot.send_message(
        chat_id, start_texts.get(lang, start_texts["en"]), parse_mode="Markdown"
    )

    candidates = CryptoSemanticNickEngine.generate_from_keyword(keyword, count=300)
    # Великий рандомний пул — 700 різних ніків як запасний варіант
    _v = "aeiou"; _c = "bcdfghjklmnpqrstvwxyz"
    _extra: set = set()
    while len(_extra) < 700:
        _ln = random.choice([5, 5, 6, 6, 6, 7])
        _pat = []
        for _i in range(_ln):
            _pat.append(random.choice(_c if _i % 2 == 0 else _v))
        _nick = "".join(_pat)
        if re.fullmatch(r"[a-z][a-z]{3,}", _nick):
            _extra.add(_nick)
    candidates = list(dict.fromkeys(candidates + list(_extra)))[:1000]

    # Паралельна перевірка — 16 потоків
    result = HighSpeedNetworkChecker.parallel_find_free(
        candidates,
        chat_id=chat_id,
        msg_id=status_msg.message_id,
        label=keyword,
        lang=lang,
        workers=16,
    )
    found_nick = result[0] if result else None
    frag_data  = result[1] if result else {"status": "unknown", "auction_price": None,
                                            "auction_bids": None, "auction_ends": None,
                                            "buy_now": None}

    db_manager.increment_scans(user_id)

    try:
        bot.delete_message(chat_id, status_msg.message_id)
    except Exception:
        pass

    if found_nick:
        db_manager.save_found_nick(found_nick, len(found_nick), user_id)
        with open(OUTPUT_FILE, "a", encoding="utf-8") as f:
            f.write(f"{found_nick}\n")

        liq_score = NickLiquidityRanker.score(found_nick)
        liq_label = NickLiquidityRanker.liquidity_label(found_nick, lang)
        base_report = BOOHXAnalyticMatrix.generate_fragment_report(found_nick, lang, frag_data)

        ai_block = {
            "ua": (
                f"\n\n🤖 *AI Аналіз:*\n"
                f"💧 Ліквідність: {liq_label} ({liq_score}/100)\n"
                f"🔑 Ключове слово: `{keyword}`\n"
                f"🔤 Тільки літери: ✅"
            ),
            "ru": (
                f"\n\n🤖 *AI Анализ:*\n"
                f"💧 Ликвидность: {liq_label} ({liq_score}/100)\n"
                f"🔑 Ключевое слово: `{keyword}`\n"
                f"🔤 Только буквы: ✅"
            ),
            "en": (
                f"\n\n🤖 *AI Analysis:*\n"
                f"💧 Liquidity: {liq_label} ({liq_score}/100)\n"
                f"🔑 Keyword: `{keyword}`\n"
                f"🔤 Letters only: ✅"
            ),
        }
        full_report = base_report + ai_block.get(lang, ai_block["en"])

        again_lbl = {
            "ua": f"🔄 Ще раз ({keyword})",
            "ru": f"🔄 Ещё раз ({keyword})",
            "en": f"🔄 Again ({keyword})",
        }.get(lang, f"🔄 Again ({keyword})")

        markup = types.InlineKeyboardMarkup(row_width=2)
        markup.add(
            types.InlineKeyboardButton("🔗 Fragment", url=f"https://fragment.com/@{found_nick}"),
            types.InlineKeyboardButton("📱 Telegram", url=f"https://t.me/{found_nick}"),
        )
        markup.add(types.InlineKeyboardButton(
            "👁 Watch This Nick", callback_data=f"watch_add_{found_nick}"))
        markup.add(types.InlineKeyboardButton(
            p["sell_nick_btn"], callback_data=f"sell_nick_{found_nick}"))
        markup.add(types.InlineKeyboardButton(
            again_lbl, callback_data=f"nickai_again_{keyword}"))
        bot.send_message(chat_id, full_report, reply_markup=markup, parse_mode="Markdown")
    else:
        no_txt = {
            "ua": (
                f"😔 AI не знайшов вільних ніків для *{keyword}*.\n"
                f"Спробуй інше слово або скорочений варіант.\n"
                f"Запусти: `/nickai {keyword[:4]}`"
            ),
            "ru": (
                f"😔 AI не нашёл свободных ников для *{keyword}*.\n"
                f"Попробуй другое слово или более короткое.\n"
                f"Запусти: `/nickai {keyword[:4]}`"
            ),
            "en": (
                f"😔 AI found no free nicks for *{keyword}*.\n"
                f"Try a shorter or different keyword.\n"
                f"Run: `/nickai {keyword[:4]}`"
            ),
        }
        bot.send_message(chat_id, no_txt.get(lang, no_txt["en"]), parse_mode="Markdown")


def run_keyword_find(chat_id: int, user_id: int, keyword: str, lang: str):
    """Шукає вільний нік на основі ключового слова — покращена v2.

    Зміни:
    • Більший пул (1500 кандидатів замість 1000)
    • CVCVCV-збагачений рандомний пул для 6-літерних варіантів
    • Складові (syllable) варіанти для 6 та 7 літер
    • Вищий пріоритет ліквідних ніків через NickLiquidityRanker
    """
    p = LANG_PACKS[lang]
    profile = db_manager.get_user_profile(user_id)

    if profile["attempts"] <= 0 and not profile["is_admin"] and not profile["is_premium"]:
        bot.send_message(chat_id, p["no_attempts"])
        return

    sec = peek_cooldown(user_id, profile["is_premium"])
    if sec > 0:
        bot.send_message(chat_id, p["cooldown"].format(sec=sec))
        return
    apply_cooldown(user_id, profile["is_premium"])

    find_texts = {
        "ua": (
            f"🔎 Шукаю варіанти для *{keyword}*...\n"
            f"⚡ Пул: CVCVCV + складові + змістові комбінації"
        ),
        "ru": (
            f"🔎 Ищу варианты для *{keyword}*...\n"
            f"⚡ Пул: CVCVCV + слоговые + осмысленные комбо"
        ),
        "en": (
            f"🔎 Searching variants for *{keyword}*...\n"
            f"⚡ Pool: CVCVCV + syllable + meaningful combos"
        ),
    }
    status_msg = bot.send_message(chat_id, find_texts.get(lang, find_texts["en"]),
                                  parse_mode="Markdown")

    # ── 1. Keyword-based variants (точне слово всередині) ─────────────────────
    variants5 = KeywordVariantEngine.generate_variants(keyword, target_len=5, count=150)
    variants6 = KeywordVariantEngine.generate_variants(keyword, target_len=6, count=200)
    variants7 = KeywordVariantEngine.generate_variants(keyword, target_len=7, count=150)
    all_variants_raw = variants5 + variants6 + variants7

    # ── 2. CVCVCV-збагачений пул для 6 літер ─────────────────────────────────
    _V = "aeiou"
    _C = "bcdfghjklmnpqrstvwxyz"
    _SYLLS = BOOHXAnalyticMatrix._SYLLABLES_CV

    _cvcvcv_pool: set = set()
    # а) Чистий CVCVCV рандом — 300 штук
    while len(_cvcvcv_pool) < 300:
        nick = "".join(
            random.choice(_C if i % 2 == 0 else _V) for i in range(6)
        )
        _cvcvcv_pool.add(nick)
    # б) Складові (3 склади CV+CV+CV) — 200 штук
    while len(_cvcvcv_pool) < 500:
        nick = random.choice(_SYLLS) + random.choice(_SYLLS) + random.choice(_SYLLS)
        _cvcvcv_pool.add(nick)
    # в) Keyword + CVCVCV-padding: якщо keyword короткий — обгортаємо складами
    kw = keyword.lower()
    if len(kw) <= 4:
        for syl in _SYLLS:
            for syl2 in _SYLLS:
                cand = (syl + kw + syl2[:1])[:6]
                if len(cand) == 6:
                    _cvcvcv_pool.add(cand)
                cand2 = (syl[:1] + kw + syl2)[:6]
                if len(cand2) == 6:
                    _cvcvcv_pool.add(cand2)
                if len(_cvcvcv_pool) > 700:
                    break
            if len(_cvcvcv_pool) > 700:
                break

    # ── 3. Для 5 літер — покращений рандомний пул ─────────────────────────────
    _five_pool: set = set()
    while len(_five_pool) < 300:
        # 60% CVCVC, 40% складові
        if random.random() < 0.6:
            nick = "".join(
                random.choice(_C if i % 2 == 0 else _V) for i in range(5)
            )
        else:
            s1 = random.choice(_SYLLS)
            s2 = random.choice(_SYLLS)
            nick = (s1 + s2 + random.choice(_C))[:5]
        if len(nick) == 5 and re.fullmatch(r"[a-z]{5}", nick):
            _five_pool.add(nick)

    # ── 4. Об'єднуємо і ранжуємо ─────────────────────────────────────────────
    all_raw = all_variants_raw + list(_cvcvcv_pool) + list(_five_pool)
    all_ranked = NickLiquidityRanker.rank(all_raw)
    all_candidates = list(dict.fromkeys(all_ranked))[:1500]

    # ── 5. Паралельна перевірка — 16 потоків ─────────────────────────────────
    result = HighSpeedNetworkChecker.parallel_find_free(
        all_candidates,
        chat_id=chat_id,
        msg_id=status_msg.message_id,
        label=keyword,
        lang=lang,
        workers=16,
    )
    found_nick = result[0] if result else None
    frag_data  = result[1] if result else {"status": "unknown", "auction_price": None,
                                            "auction_bids": None, "auction_ends": None,
                                            "buy_now": None}

    if not profile["is_admin"] and not profile["is_premium"]:
        db_manager.update_user_field(user_id, "attempts", max(0, profile["attempts"]-1))
    db_manager.increment_scans(user_id)

    try: bot.delete_message(chat_id, status_msg.message_id)
    except Exception: pass

    if found_nick:
        db_manager.save_found_nick(found_nick, len(found_nick), user_id)
        with open(OUTPUT_FILE, "a", encoding="utf-8") as f:
            f.write(f"{found_nick}\n")

        # Показуємо чи CVCVCV-pattern це виявився
        is_cvcvcv = all(
            (found_nick[i] in _C if i % 2 == 0 else found_nick[i] in _V)
            for i in range(len(found_nick))
        ) if len(found_nick) == 6 else False
        cvcvcv_badge = " `[CVCVCV]`" if is_cvcvcv else ""

        report = BOOHXAnalyticMatrix.generate_fragment_report(found_nick, lang, frag_data)
        if cvcvcv_badge:
            report = report.rstrip() + f"\n🔠 Шаблон:{cvcvcv_badge} — легко вимовляється\n"

        markup = types.InlineKeyboardMarkup(row_width=2)
        markup.add(
            types.InlineKeyboardButton("🔗 Fragment", url=f"https://fragment.com/@{found_nick}"),
            types.InlineKeyboardButton("📱 Telegram", url=f"https://t.me/{found_nick}"),
        )
        markup.add(types.InlineKeyboardButton(
            "👁 Watch This Nick", callback_data=f"watch_add_{found_nick}"))
        markup.add(types.InlineKeyboardButton(
            "🔄 Search Again", callback_data=f"find_again_{keyword}"))
        bot.send_message(chat_id, report, reply_markup=markup, parse_mode="Markdown")
    else:
        no_find_txt = {
            "ua": f"😔 Жодного вільного варіанту для *{keyword}* не знайдено.\nСпробуй інше слово або звичайний скан.",
            "ru": f"😔 Свободных вариантов для *{keyword}* не найдено.\nПопробуй другое слово или обычный скан.",
            "en": f"😔 No free variants found for *{keyword}*.\nTry another word or regular scan.",
        }
        bot.send_message(chat_id, no_find_txt.get(lang, no_find_txt["en"]), parse_mode="Markdown")


@bot.message_handler(commands=["find"])
def handle_find_command(message: types.Message):
    uid  = message.from_user.id
    profile = db_manager.get_user_profile(uid)
    lang = profile.get("lang", "ua")

    # /find — тільки для Premium
    if not profile["is_premium"] and not profile["is_admin"]:
        premium_only = {
            "ua": (
                "🛑 *Команда /find — тільки для Premium!*\n\n"
                "💎 Premium відкриває:\n"
                "• `/find слово` — пошук вільних ніків за ключовим словом\n"
                "• `/nickai` — AI-генератор крипто-ніків (legalTon, TonJoker...)\n"
                "• 5-літерні ніки, без cooldown і безліміт спроб\n\n"
                "Придбати Premium: натисни *«💎 Premium / Донат»*"
            ),
            "ru": (
                "🛑 *Команда /find — только для Premium!*\n\n"
                "💎 Premium открывает:\n"
                "• `/find слово` — поиск свободных ников по ключевому слову\n"
                "• `/nickai` — AI-генератор крипто-ников (legalTon, TonJoker...)\n"
                "• 5-буквенные ники, без cooldown и безлимитные попытки\n\n"
                "Купить Premium: нажми *«💎 Premium / Донат»*"
            ),
            "en": (
                "🛑 *The /find command is Premium only!*\n\n"
                "💎 Premium unlocks:\n"
                "• `/find word` — search free usernames by keyword\n"
                "• `/nickai` — AI crypto nick generator (legalTon, TonJoker...)\n"
                "• 5-letter usernames, no cooldown, unlimited attempts\n\n"
                "Get Premium: tap *«💎 Premium / Donate»*"
            ),
        }.get(lang, "🛑 /find is Premium only. Buy Premium via the menu.")
        bot.reply_to(message, premium_only, parse_mode="Markdown")
        return

    parts = message.text.strip().split(None, 1)

    if len(parts) < 2 or not parts[1].strip():
        hint = {
            "ua": (
                "📝 Введи: `/find слово`\n"
                "Приклад: `/find ton` або `/find cool`\n\n"
                "Бот знайде вільні ніки, що *містять* це слово.\n"
                "Слово зберігається у ніку незмінним!\n\n"
                "💡 Також спробуй `/nickai` — AI крипто-ніки"
            ),
            "ru": (
                "📝 Введи: `/find слово`\n"
                "Пример: `/find ton` или `/find cool`\n\n"
                "Бот найдёт свободные ники, *содержащие* это слово.\n"
                "Слово сохраняется в нике без изменений!\n\n"
                "💡 Также попробуй `/nickai` — AI крипто-ники"
            ),
            "en": (
                "📝 Usage: `/find word`\n"
                "Example: `/find ton` or `/find cool`\n\n"
                "Bot finds free usernames that *contain* your word unchanged.\n\n"
                "💡 Also try `/nickai` — AI crypto nick generator"
            ),
        }.get(lang, "📝 Usage: `/find word`")
        bot.reply_to(message, hint, parse_mode="Markdown")
        return

    keyword = parts[1].strip().lower()[:12]
    if not re.fullmatch(r"[a-z]+", keyword):
        err = {
            "ua": "⚠️ Ключове слово має містити тільки латинські літери (a-z).",
            "ru": "⚠️ Ключевое слово должно содержать только латинские буквы (a-z).",
            "en": "⚠️ Keyword must contain only Latin letters (a-z).",
        }.get(lang, "⚠️ Letters only (a-z).")
        bot.reply_to(message, err)
        return

    t = threading.Thread(target=run_keyword_find,
                         args=(message.chat.id, uid, keyword, lang), daemon=True)
    t.start()


@bot.message_handler(commands=["nickai"])
def handle_nickai_command(message: types.Message):
    """Premium AI крипто-нік генератор за ключовим словом."""
    uid = message.from_user.id
    profile = db_manager.get_user_profile(uid)
    lang = profile.get("lang", "ua")

    if not profile["is_premium"] and not profile["is_admin"]:
        txt = {
            "ua": (
                "🤖 *BOOHX AI Nick Generator — тільки Premium!*\n\n"
                "Генерує осмислені ніки *тільки з літер* на основі твого слова:\n"
                "`/nickai ton` → tonvault, darkton, elitetons, protonhub...\n"
                "`/nickai gem` → gemvault, darkgem, gemhub, progembot...\n\n"
                "💎 AI ранжує кандидатів за ліквідністю та перевіряє обидва джерела (TG + Fragment).\n\n"
                "Придбати Premium: натисни *«💎 Premium / Донат»*"
            ),
            "ru": (
                "🤖 *BOOHX AI Nick Generator — только Premium!*\n\n"
                "Генерирует осмысленные ники *только из букв* по твоему слову:\n"
                "`/nickai ton` → tonvault, darkton, elitetons, protonhub...\n"
                "`/nickai gem` → gemvault, darkgem, gemhub, progembot...\n\n"
                "💎 AI ранжирует кандидатов по ликвидности и проверяет оба источника (TG + Fragment).\n\n"
                "Купить Premium: нажми *«💎 Premium / Донат»*"
            ),
            "en": (
                "🤖 *BOOHX AI Nick Generator — Premium only!*\n\n"
                "Generates meaningful nicks *using only letters* based on your word:\n"
                "`/nickai ton` → tonvault, darkton, elitetons, protonhub...\n"
                "`/nickai gem` → gemvault, darkgem, gemhub, progembot...\n\n"
                "💎 AI ranks candidates by liquidity and double-checks both TG + Fragment.\n\n"
                "Get Premium: tap *«💎 Premium / Donate»*"
            ),
        }.get(lang, "🤖 /nickai is Premium only.")
        bot.reply_to(message, txt, parse_mode="Markdown")
        return

    parts = message.text.strip().split(None, 1)

    if len(parts) < 2 or not parts[1].strip():
        hint = {
            "ua": (
                "📝 Введи: `/nickai слово`\n"
                "Приклад: `/nickai ton` або `/nickai gem`\n\n"
                "🤖 AI згенерує ніки *тільки з літер*, пов'язані з твоїм словом.\n"
                "Підтримуються довгі ніки (до 12 символів).\n"
                "Перевірка: TG + Fragment (тільки дійсно вільні!)"
            ),
            "ru": (
                "📝 Введи: `/nickai слово`\n"
                "Пример: `/nickai ton` или `/nickai gem`\n\n"
                "🤖 AI сгенерирует ники *только из букв*, связанные с твоим словом.\n"
                "Поддерживаются длинные ники (до 12 символов).\n"
                "Проверка: TG + Fragment (только реально свободные!)"
            ),
            "en": (
                "📝 Usage: `/nickai word`\n"
                "Example: `/nickai ton` or `/nickai gem`\n\n"
                "🤖 AI generates nicks *using letters only*, related to your word.\n"
                "Long nicks supported (up to 12 characters).\n"
                "Double-checked: TG + Fragment (only truly free ones!)"
            ),
        }.get(lang, "📝 Usage: `/nickai word`")
        bot.reply_to(message, hint, parse_mode="Markdown")
        return

    keyword = parts[1].strip().lower()[:15]
    if not re.fullmatch(r"[a-z]+", keyword):
        err = {
            "ua": "⚠️ Ключове слово — тільки латинські літери (a-z), без цифр та пробілів.",
            "ru": "⚠️ Ключевое слово — только латинские буквы (a-z), без цифр и пробелов.",
            "en": "⚠️ Keyword must contain only Latin letters (a-z), no digits or spaces.",
        }.get(lang, "⚠️ Letters only (a-z).")
        bot.reply_to(message, err)
        return

    t = threading.Thread(
        target=run_nickai_find,
        args=(message.chat.id, uid, keyword, lang),
        daemon=True,
    )
    t.start()


# ==============================================================================
# БЛОК 12: CALLBACKS
# ==============================================================================
ADMIN_BROADCAST_STATE: Dict[int, bool] = {}

@bot.callback_query_handler(func=lambda call: True)
def global_callback_dispatcher(call: types.CallbackQuery):
    uid     = call.from_user.id
    chat_id = call.message.chat.id
    msg_id  = call.message.message_id
    profile = db_manager.get_user_profile(uid, call.from_user.username or f"User_{uid}")
    lang    = profile["lang"]
    data    = call.data
    answered = False

    def _answer(text: str = "", alert: bool = False):
        nonlocal answered
        if answered:
            return
        try:
            bot.answer_callback_query(call.id, text, show_alert=alert)
        except Exception:
            pass
        answered = True

    # Центральний ban-guard: заблоковані не проходять далі (крім set_lang)
    if db_manager.is_banned(uid) and not data.startswith("set_lang_"):
        _answer("🚫 Ваш акаунт заблоковано.", alert=True)
        return

    try:
        # --- Мова ---
        if data.startswith("set_lang_"):
            chosen = data.split("_")[-1]
            if chosen not in LANG_PACKS:
                _answer("⚠️ Unknown language", alert=True)
                return
            db_manager.update_user_field(uid, "lang", chosen)
            db_manager.update_user_field(uid, "lang_chosen", 1)
            _answer("✅ Saved!")
            if not is_subscribed_to_channel(uid):
                try:
                    bot.delete_message(chat_id, msg_id)
                except Exception:
                    pass
                send_subscribe_prompt(chat_id, chosen)
            else:
                bot.edit_message_text(
                    LANG_PACKS[chosen]["welcome"],
                    chat_id=chat_id,
                    message_id=msg_id,
                    parse_mode="Markdown",
                )
                bot.send_message(chat_id, "👇", reply_markup=BOOHXKeyboardFactory.main_reply_menu(chosen))

        elif data.startswith("sub_check_"):
            # Делегуємо повністю у channel_guard — там кеш, retry, вайтліст
            def _open_main(c_id: int, lng: str) -> None:
                bot.send_message(
                    c_id,
                    LANG_PACKS[lng]["welcome"],
                    reply_markup=BOOHXKeyboardFactory.main_reply_menu(lng),
                    parse_mode="Markdown",
                )
            _cg.handle_check_callback(bot, call, _open_main)
            return  # handle_check_callback сам відповідає на callback

        # --- Довжина ---
        elif data.startswith("set_len_"):
            chosen_len = int(data.split("_")[-1])
            if chosen_len == 5 and not profile["is_premium"] and not profile["is_admin"]:
                _answer(LANG_PACKS[lang]["premium_alert"], alert=True)
                return
            sec = peek_cooldown(uid, profile["is_premium"])
            if sec > 0:
                _answer(LANG_PACKS[lang]["cooldown"].format(sec=sec), alert=True)
                return
            _answer()
            threading.Thread(
                target=run_actual_nickname_scan,
                args=(chat_id, uid, chosen_len, lang),
                daemon=True,
            ).start()

        # --- Find Again (keyword search repeat) ---
        elif data.startswith("find_again_"):
            keyword = data[len("find_again_"):]
            _answer()
            threading.Thread(
                target=run_keyword_find,
                args=(chat_id, uid, keyword, lang),
                daemon=True,
            ).start()

        # --- Купівля Premium ---
        elif data.startswith("buy_"):
            plan_key = data[4:]
            if plan_key not in PREMIUM_PLANS:
                _answer("⚠️ Невідомий план.", alert=True)
                return
            plan = PREMIUM_PLANS[plan_key]
            memo = f"tgid_{uid}"
            lbl_k = f"label_{lang}"
            label = plan.get(lbl_k, plan["label_en"])
            text = LANG_PACKS[lang]["premium_invoice"].format(
                plan_label=label, ton=plan["ton"], wallet=TON_WALLET, memo=memo
            )
            _answer()
            bot.send_message(
                chat_id,
                text,
                reply_markup=BOOHXKeyboardFactory.payment_check_inline(lang),
                parse_mode="Markdown",
            )

        # --- Перевірка оплати ---
        elif data == "check_payment":
            fresh = db_manager.get_user_profile(uid)
            if fresh["is_premium"]:
                puntil = fresh["premium_until"]
                until_str = (
                    "∞" if puntil == 0.0 else datetime.fromtimestamp(puntil).strftime("%d.%m.%Y")
                )
                _answer(LANG_PACKS[lang]["already_premium"].format(until=until_str), alert=True)
            else:
                wait = {
                    "ua": "⏳ Оплату не виявлено. Перевірте коментар і зачекайте 1–2 хв.",
                    "ru": "⏳ Оплата не обнаружена. Проверьте комментарий и подождите 1–2 мин.",
                    "en": "⏳ Payment not detected yet. Check the memo and wait 1–2 min.",
                }.get(lang, "⏳")
                _answer(wait, alert=True)

        # --- Копія адреси ---
        elif data == "donate_copy":
            _answer(f"💰 {TON_WALLET}", alert=True)

        # --- Розіграш ---
        elif data == "giveaway_enter":
            p_local = LANG_PACKS[lang]
            if giveaway_server.join(uid):
                _answer(p_local["giveaway_joined"], alert=True)
            else:
                _answer(p_local["giveaway_already"], alert=True)

        # --- Зміна мови з профілю ---
        elif data == "change_lang_profile":
            _answer()
            bot.send_message(chat_id, LANG_PACKS[lang]["lang_change_prompt"],
                             reply_markup=BOOHXKeyboardFactory.language_selection_inline())

        # --- Профіль: додати юз каналу ---
        elif data == "profile_add_channel":
            _answer()
            p_local = LANG_PACKS[lang]
            try:
                binfo = bot.get_me()
                bot_username = binfo.username or "boohx_bot"
            except Exception:
                bot_username = "boohx_bot"
            bot.send_message(
                chat_id,
                p_local["channel_add_instructions"].format(bot_username=bot_username),
                parse_mode="Markdown",
            )

        # --- Адмін: статистика ---
        elif data == "adm_stats":
            if not profile["is_admin"]:
                _answer("⛔", alert=True)
                return
            _answer()
            total = db_manager.count_users()
            premium = db_manager.count_premium()
            nicks = db_manager.count_found_nicks()
            bot.edit_message_text(
                f"📊 *BOOHX Статистика:*\n"
                f"├ Користувачів: `{total}`\n"
                f"├ Premium: `{premium}`\n"
                f"└ Знайдено ніків: `{nicks}`",
                chat_id=chat_id,
                message_id=msg_id,
                parse_mode="Markdown",
            )

        # --- Адмін: топ ---
        elif data == "adm_top":
            if not profile["is_admin"]:
                _answer("⛔", alert=True)
                return
            _answer()
            top = db_manager.get_top_users(10)
            lines = ["🏆 *Топ юзерів за скануваннями:*"]
            for i, (uid_, uname_, scans_) in enumerate(top, 1):
                lines.append(f"{i}. `{uid_}` {uname_ or '—'} — {scans_} сканів")
            bot.edit_message_text(
                "\n".join(lines), chat_id=chat_id, message_id=msg_id, parse_mode="Markdown"
            )

        # --- Адмін: розсилка ---
        elif data == "adm_broadcast":
            if not profile["is_admin"]:
                _answer("⛔", alert=True)
                return
            _answer()
            ADMIN_BROADCAST_STATE[uid] = True
            bot.edit_message_text(
                "📣 Введіть текст для розсилки:", chat_id=chat_id, message_id=msg_id
            )

        # --- Адмін: розіграш ---
        elif data == "adm_giveaway":
            if not profile["is_admin"]:
                _answer("⛔", alert=True)
                return
            _answer()
            giveaway_server.start()
            bot.edit_message_text(
                f"🎉 Giveaway started! Prize: {giveaway_server.prize} attempts.\n"
                f"Розіграш запущено! Приз: {giveaway_server.prize} спроб.",
                chat_id=chat_id,
                message_id=msg_id,
            )

        # --- Детальна інформація по ніку ---
        elif data.startswith("nick_details_"):
            nick = data[len("nick_details_"):]
            _answer()
            p_d = LANG_PACKS[lang]
            q = NickQualityAnalyzer.analyze(nick)
            ln = q["length"]

            # Ліквідність та попит залежно від довжини + рейтингу
            if ln <= 4:
                liq_map   = {"ua":"🔥 Дуже висока",   "ru":"🔥 Очень высокая",  "en":"🔥 Very High"}
                time_map  = {"ua":"1–7 днів",          "ru":"1–7 дней",          "en":"1–7 days"}
                demand_map= {"ua":"🚀 Ажіотаж",        "ru":"🚀 Ажиотаж",        "en":"🚀 Extreme"}
            elif ln == 5:
                liq_map   = {"ua":"🔶 Висока",         "ru":"🔶 Высокая",        "en":"🔶 High"}
                time_map  = {"ua":"3–21 день",         "ru":"3–21 день",         "en":"3–21 days"}
                demand_map= {"ua":"📈 Активний",       "ru":"📈 Активный",       "en":"📈 Active"}
            elif ln == 6:
                liq_map   = {"ua":"🟡 Середня",        "ru":"🟡 Средняя",        "en":"🟡 Medium"}
                time_map  = {"ua":"2–6 тижнів",        "ru":"2–6 недель",        "en":"2–6 weeks"}
                demand_map= {"ua":"📊 Помірний",       "ru":"📊 Умеренный",      "en":"📊 Moderate"}
            else:
                liq_map   = {"ua":"🔵 Низька",         "ru":"🔵 Низкая",         "en":"🔵 Low"}
                time_map  = {"ua":"1–3 місяці",        "ru":"1–3 месяца",        "en":"1–3 months"}
                demand_map= {"ua":"📉 Слабкий",        "ru":"📉 Слабый",         "en":"📉 Weak"}

            liq_level = liq_map.get(lang, liq_map["en"])
            sell_days  = time_map.get(lang, time_map["en"])
            demand_str = demand_map.get(lang, demand_map["en"])

            # Схожі ніки — варіації на основі самого ніку
            def _similar_nicks(base: str) -> List[str]:
                variants = []
                letters = list("aeiou") + list("bcdfghjklmnpqrstvwxyz")
                for i in range(len(base)):
                    for ch in ("a","e","i","o","u","x","z","k","m","n"):
                        if ch != base[i]:
                            v = base[:i] + ch + base[i+1:]
                            if v != base:
                                variants.append(v)
                                if len(variants) >= 8:
                                    return variants
                return variants[:8]

            similars = _similar_nicks(nick)
            sim_lines = ""
            for s in similars:
                sim_lines += f"• [`@{s}`](https://fragment.com/@{s})\n"

            text = p_d["nick_details_title"].format(nick=nick)
            text += p_d["nick_liquidity"].format(level=liq_level)
            text += p_d["nick_sell_time"].format(days=sell_days)
            text += p_d["nick_demand"].format(demand=demand_str)
            text += f"💰 ~{q['value_ton']} TON (~${q['value_usd']})\n\n"
            text += p_d["nick_similar_header"]
            text += sim_lines if sim_lines else "—\n"

            sim_markup = types.InlineKeyboardMarkup(row_width=1)
            sim_markup.add(
                types.InlineKeyboardButton("🔗 Fragment", url=f"https://fragment.com/@{nick}"),
                types.InlineKeyboardButton("📱 Telegram", url=f"https://t.me/{nick}"),
            )
            bot.send_message(chat_id, text, parse_mode="Markdown",
                             reply_markup=sim_markup, disable_web_page_preview=True)

        # --- Watchlist: додати через кнопку ---
        elif data.startswith("watch_add_"):
            nick = data[len("watch_add_"):]
            p = LANG_PACKS[lang]
            if profile["is_premium"] or profile["is_admin"]:
                result = db_manager.watchlist_add_premium(uid, nick)
            else:
                result = db_manager.watchlist_add(uid, nick)
            if result == "added":
                _answer(p["watch_added"].format(nick=nick)[:200], alert=True)
            elif result == "exists":
                _answer(p["watch_exists"].format(nick=nick)[:200], alert=True)
            elif result == "limit":
                _answer(p["watch_limit"][:200], alert=True)
            else:
                _answer()

        # --- Адмін: вибрати переможця ---
        elif data == "adm_pick_winner":
            if not profile["is_admin"]:
                _answer("⛔", alert=True)
                return
            _answer()
            prize_val = giveaway_server.prize
            winner = giveaway_server.pick_winner()
            if winner:
                db_manager.update_user_field(
                    winner,
                    "attempts",
                    db_manager.get_user_profile(winner)["attempts"] + prize_val,
                )
                bot.edit_message_text(
                    f"🎉 Winner / Переможець: `{winner}`! Prize: {prize_val} attempts.",
                    chat_id=chat_id,
                    message_id=msg_id,
                    parse_mode="Markdown",
                )
                try:
                    w_profile = db_manager.get_user_profile(winner)
                    w_lang = w_profile.get("lang", "ua")
                    bot.send_message(winner,
                        LANG_PACKS[w_lang]["winner_msg"].format(prize=prize_val),
                        parse_mode="Markdown")
                except Exception:
                    pass
            else:
                bot.edit_message_text(
                    "😔 No participants / Учасників немає.", chat_id=chat_id, message_id=msg_id
                )

        # --- AI крипто-нік: кнопка «Ще раз» ---
        elif data.startswith("nickai_again_") or data.startswith("nickai_scan_"):
            if not profile["is_premium"] and not profile["is_admin"]:
                _answer(LANG_PACKS[lang]["premium_alert"][:200], alert=True)
                return
            prefix = "nickai_again_" if data.startswith("nickai_again_") else "nickai_scan_"
            keyword = data[len(prefix):][:15]
            if not keyword or not re.fullmatch(r"[a-z]+", keyword):
                _answer("⚠️ Некоректне ключове слово", alert=True)
                return
            _answer({"ua": "🤖 AI сканер запущено...",
                     "ru": "🤖 AI сканер запущен...",
                     "en": "🤖 AI scanner started..."}.get(lang, "🤖 Starting..."))
            threading.Thread(
                target=run_nickai_find,
                args=(chat_id, uid, keyword, lang),
                daemon=True,
            ).start()

        # --- Продаж ніку ---
        elif data.startswith("sell_nick_"):
            nick = data[len("sell_nick_"):]
            p = LANG_PACKS[lang]
            try:
                bot.send_message(
                    OWNER_ID,
                    f"💰 *Запит на продаж ніку*\n"
                    f"├ Нік: `@{nick}`\n"
                    f"├ Від: `{uid}` @{profile.get('username','?')}\n"
                    f"└ Fragment: https://fragment.com/@{nick}",
                    parse_mode="Markdown",
                )
            except Exception:
                pass
            _answer(p["sell_nick_sent"].format(nick=nick)[:200], alert=True)

        # --- Реклама: claim ---
        elif data == "ad_claim":
            p = LANG_PACKS[lang]
            if not db_manager.try_claim_ad(uid):
                _answer(p["ad_cooldown"].format(hours=AD_COOLDOWN_HOURS)[:200], alert=True)
                return
            new_attempts = profile["attempts"] + AD_REWARD_ATTEMPTS
            db_manager.update_user_field(uid, "attempts", new_attempts)
            _answer(p["ad_claimed"].format(reward=AD_REWARD_ATTEMPTS, total=new_attempts)[:200],
                    alert=True)

        else:
            _answer()

    except Exception as e:
        logger.warning(f"[CALLBACK] {data} uid={uid}: {e}")
        _answer("⚠️ Помилка обробки", alert=True)
    finally:
        if not answered:
            _answer()


# ==============================================================================
# БЛОК 13: АДМІН-РОЗСИЛКА ТА STEALTH-КОМАНДИ
# ==============================================================================
@bot.message_handler(func=lambda m: ADMIN_BROADCAST_STATE.get(m.from_user.id) is True)
def process_admin_broadcast(message: types.Message):
    if not db_manager.get_user_profile(message.from_user.id)["is_admin"]: return
    ADMIN_BROADCAST_STATE[message.from_user.id] = False
    uids  = db_manager.get_all_user_ids()
    sent  = 0
    for uid in uids:
        try:
            bot.send_message(uid, f"📣 *BOOHX:*\n\n{message.text}", parse_mode="Markdown")
            sent += 1; time.sleep(0.05)
        except Exception: pass
    bot.send_message(message.chat.id, f"✅ Доставлено: {sent}/{len(uids)}")


@bot.message_handler(func=lambda m: m.text and m.text.startswith("+"))
def handle_stealth_commands(message: types.Message):
    if not db_manager.get_user_profile(message.from_user.id)["is_admin"]: return
    parts = message.text.split()
    try:
        cmd = parts[0]
        if cmd == "+add_attempts" and len(parts) == 3:
            db_manager.update_user_field(int(parts[1]), "attempts", int(parts[2]))
            bot.send_message(message.chat.id, f"✅ Спроби {parts[1]} → {parts[2]}")
        elif cmd == "+set_premium" and len(parts) >= 2:
            plan_key = parts[2] if len(parts) > 2 and parts[2] in PREMIUM_PLANS else "lf"
            db_manager.activate_premium(int(parts[1]), plan_key)
            bot.send_message(message.chat.id, f"💎 Premium ({plan_key}) → {parts[1]}")
        elif cmd == "+remove_premium" and len(parts) >= 2:
            db_manager.update_user_field(int(parts[1]), "is_premium", 0)
            db_manager.update_user_field(int(parts[1]), "premium_until", 0.0)
            db_manager.update_user_field(int(parts[1]), "attempts", 10)
            bot.send_message(message.chat.id, f"🔓 Premium знято з {parts[1]}")
        elif cmd == "+giveaway_winner":
            prize_val = giveaway_server.prize
            winner = giveaway_server.pick_winner()
            if winner:
                db_manager.update_user_field(winner, "attempts",
                    db_manager.get_user_profile(winner)["attempts"] + prize_val)
                bot.send_message(message.chat.id, f"🎉 Winner / Переможець: `{winner}`! Prize: {prize_val}", parse_mode="Markdown")
                try:
                    w_profile = db_manager.get_user_profile(winner)
                    w_lang = w_profile.get("lang", "ua")
                    bot.send_message(winner,
                        LANG_PACKS[w_lang]["winner_msg"].format(prize=prize_val),
                        parse_mode="Markdown")
                except Exception: pass

        elif cmd == "+ban" and len(parts) >= 2:
            target = int(parts[1])
            db_manager.ban_user(target, True)
            bot.send_message(message.chat.id, f"🚫 Юзера `{target}` заблоковано.", parse_mode="Markdown")

        elif cmd == "+unban" and len(parts) >= 2:
            target = int(parts[1])
            db_manager.ban_user(target, False)
            bot.send_message(message.chat.id, f"✅ Юзера `{target}` розблоковано.", parse_mode="Markdown")

        elif cmd == "+partner" and len(parts) >= 3:
            target  = int(parts[1])
            percent = int(parts[2])
            db_manager.add_partner(target, percent)
            bot.send_message(message.chat.id,
                f"🤝 Партнер `{target}` — {percent}% комісія.", parse_mode="Markdown")

        elif cmd == "+verify_tx" and len(parts) >= 3:
            # +verify_tx <user_id> <plan_key>
            target   = int(parts[1])
            plan_key = parts[2] if len(parts) > 2 and parts[2] in PREMIUM_PLANS else "lf"
            db_manager.activate_premium(target, plan_key)
            plan = PREMIUM_PLANS[plan_key]
            try:
                bot.send_message(target,
                    f"🎉 *Premium активовано вручну!*\n✅ План: {plan_key} ({plan['ton']} TON)",
                    parse_mode="Markdown")
            except Exception: pass
            bot.send_message(message.chat.id,
                f"💎 Premium `{plan_key}` активовано для `{target}`.", parse_mode="Markdown")

        else:
            bot.send_message(
                message.chat.id,
                "📋 *Адмін-команди:*\n"
                "`+add_attempts <id> <кількість>`\n"
                "`+set_premium <id> <1m|3m|lf>`\n"
                "`+remove_premium <id>`\n"
                "`+giveaway_winner`\n"
                "`+ban <id>`\n"
                "`+unban <id>`\n"
                "`+partner <id> <percent>`\n"
                "`+verify_tx <id> <1m|3m|lf>`",
                parse_mode="Markdown")
    except Exception as e:
        bot.send_message(message.chat.id, f"⚠️ Помилка: {e}")


# ==============================================================================
# БЛОК: ВІДСТЕЖЕННЯ ДОДАВАННЯ БОТА В КАНАЛИ
# ==============================================================================
@bot.my_chat_member_handler()
def handle_bot_membership(update: types.ChatMemberUpdated):
    """
    Спрацьовує коли статус бота у чаті змінюється.
    Бот ВПЕРШЕ стає адміном → зберігаємо юз каналу в профіль того, хто додав.
    Бот видалений / kicked → прибираємо запис.
    """
    old_status = update.old_chat_member.status
    new_status = update.new_chat_member.status
    chat       = update.chat
    added_by   = update.from_user

    # Цікавлять тільки публічні канали / супергрупи з username
    if chat.type not in ("channel", "supergroup"):
        return
    if not chat.username:
        return  # приватний канал — публічного юза немає

    # Бот ВПЕРШЕ отримує права адміна (не просто зміна прав серед адмінів)
    if new_status == "administrator" and old_status != "administrator":
        db_manager.add_channel_username(
            user_id=added_by.id,
            channel_id=chat.id,
            username=chat.username,
            title=chat.title or chat.username,
        )
        try:
            profile = db_manager.get_user_profile(added_by.id)
            p = LANG_PACKS[profile.get("lang", "ua")]
            bot.send_message(
                added_by.id,
                p["channel_added_notify"].format(
                    username=chat.username,
                    title=chat.title or chat.username,
                ),
                parse_mode="Markdown",
            )
        except Exception:
            pass

    # Бот видалений або покинув чат
    elif new_status in ("kicked", "left") and old_status not in ("kicked", "left"):
        db_manager.remove_channel_by_id(chat.id)


# ==============================================================================
# СТАРТ
# ==============================================================================
if __name__ == "__main__":
    logger.info("=" * 60)
    logger.info("🚀 BOOHX MULTILINGUAL SERVER ONLINE!")
    logger.info(f"   TON Wallet : {TON_WALLET}")
    logger.info(f"   Plans      : {list(PREMIUM_PLANS.keys())}")
    logger.info(f"   Cooldown   : {SCAN_COOLDOWN_SEC}s (free users)")
    if tg_verify.is_configured():
        _vs = tg_verify.settings()
        logger.info(f"   MTProto    : ✅ checkUsername, сесій у конфігу: {len(_vs['sessions'])}, "
                    f"інтервал {_vs['interval']}с")
    else:
        logger.warning("   MTProto    : ⚠️ НЕ налаштовано (API_ID/API_HASH/SESSION_STRING). "
                       "Ніки показуватимуться як «не підтверджено через Telegram».")
    logger.info("=" * 60)

    threading.Thread(target=ton_transaction_monitor, daemon=True).start()
    logger.info("[TON_MONITOR] Фоновий потік запущено.")

    threading.Thread(target=watchlist_monitor, daemon=True).start()
    logger.info("[WATCHLIST_MONITOR] Фоновий потік запущено.")

    # Крок 1: видаляємо webhook (якщо хтось встановив)
    try:
        bot.delete_webhook(drop_pending_updates=True)
        logger.info("[INIT] Webhook видалено.")
    except Exception as e:
        logger.warning(f"[INIT] delete_webhook: {e}")

    # Крок 2: стабільний polling без конфліктів getUpdates
    while True:
        try:
            logger.info("[POLLING] Старт infinity_polling...")
            bot.infinity_polling(
                timeout=30,
                long_polling_timeout=20,
                skip_pending=True,
                none_stop=True,
                interval=1,
                allowed_updates=["message", "callback_query", "my_chat_member"],
                logger_level=logging.ERROR,
            )
        except Exception as e:
            err_str = str(e)
            if "409" in err_str:
                logger.warning("[POLLING] 409 — інший процес перехопив сесію. Чекаємо 10 сек...")
                time.sleep(10)
                try:
                    bot.delete_webhook(drop_pending_updates=False)
                except Exception:
                    pass
            else:
                logger.error(f"[POLLING] Помилка: {e}. Рестарт через 5 сек.")
                time.sleep(5)
