#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Безпечна міграція БАЗИ КОРИСТУВАЧІВ зі старого Boohx_bot-22 у новий бот.

Переносить ТІЛЬКИ дані людей (users, attempts_history, processed_tx, found_nicks,
watchlist, ad_clicks, partners, channel_usernames). НЕ переносить: логи, кеші
перевірки username (checked_cache.db, known_taken_nicks), proxy, сесії, токени.

Використання:
    python migrate_old_db.py <старий_boohx_uqoza_max_v24.db> [<новий_boohx_uqoza_max_v24.db>]

Гарантії:
  • старий файл відкривається лише на читання;
  • перед змінами робиться резервна копія нового файлу (*.bak-<час>);
  • міграція ідемпотентна (повторний запуск нічого не дублює);
  • усе виконується в одній транзакції — при помилці нова база не змінюється.
Конфлікт по user_id: запис зі СТАРОЇ бази перемагає (там повна історія
спроб/сканів/реферaлів), а унікальні дані нової бази зберігаються.
"""
import os
import shutil
import sqlite3
import sys
import time

# Нова схема (та сама, що створює main.py → PotokoSafeDatabaseManager._create_tables)
USERS_DDL = """CREATE TABLE IF NOT EXISTS users (
    user_id          INTEGER PRIMARY KEY,
    username         TEXT,
    attempts         INTEGER DEFAULT 10,
    is_premium       INTEGER DEFAULT 0,
    premium_until    REAL    DEFAULT 0.0,
    referrals        INTEGER DEFAULT 0,
    is_admin         INTEGER DEFAULT 0,
    referrer_id      INTEGER DEFAULT NULL,
    registration_date TEXT,
    lang             TEXT    DEFAULT 'ua',
    total_scans      INTEGER DEFAULT 0,
    last_scan_ts     REAL    DEFAULT 0.0
)"""
DDL = [
    USERS_DDL,
    """CREATE TABLE IF NOT EXISTS attempts_history (
        log_id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER,
        action_type TEXT, amount INTEGER, timestamp TEXT)""",
    """CREATE TABLE IF NOT EXISTS processed_tx (
        tx_hash TEXT PRIMARY KEY, user_id INTEGER, plan TEXT,
        ton_amount REAL, activated_at TEXT)""",
    """CREATE TABLE IF NOT EXISTS found_nicks (
        id INTEGER PRIMARY KEY AUTOINCREMENT, nick TEXT, length INTEGER,
        found_by INTEGER, found_at TEXT)""",
    """CREATE TABLE IF NOT EXISTS watchlist (
        id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, nick TEXT,
        added_at TEXT, last_check TEXT, UNIQUE(user_id, nick))""",
    """CREATE TABLE IF NOT EXISTS ad_clicks (
        id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, clicked_at REAL)""",
    """CREATE TABLE IF NOT EXISTS partners (
        user_id INTEGER PRIMARY KEY, percent INTEGER DEFAULT 10,
        ref_count INTEGER DEFAULT 0, total_ton REAL DEFAULT 0.0, created_at TEXT)""",
    """CREATE TABLE IF NOT EXISTS channel_usernames (
        id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL,
        channel_id INTEGER NOT NULL UNIQUE, channel_username TEXT,
        channel_title TEXT, added_at TEXT)""",
]
# Стовпці users, які main.py додає міграціями при старті — додаємо тут теж,
# щоб скопіювати значення зі старої бази (lang_chosen, banned, ...).
USER_EXTRA_COLS = [
    ("lang_chosen", "INTEGER DEFAULT 0"),
    ("banned", "INTEGER DEFAULT 0"),
    ("partner_percent", "INTEGER DEFAULT 0"),
    ("nick_sell_price", "REAL DEFAULT 0.0"),
    # Застарілі стовпці зі старого бота: код їх не читає, але це дані користувачів —
    # зберігаємо, щоб нічого не втратити (додаткові стовпці з DEFAULT безпечні).
    ("quiz_date", "TEXT DEFAULT ''"),
    ("quiz_count", "INTEGER DEFAULT 0"),
    ("nick_style", "TEXT DEFAULT 'readable'"),
    ("nick_digits", "INTEGER DEFAULT 0"),
]
# Таблиці з AUTOINCREMENT-id: id НЕ копіюємо (щоб не конфліктувати), дублі відсікаємо
# за природним ключем.
AUTOINC = {
    "attempts_history": ("user_id", "action_type", "amount", "timestamp"),
    "found_nicks": ("nick", "length", "found_by", "found_at"),
    "ad_clicks": ("user_id", "clicked_at"),
}
# Таблиці з природним PK/UNIQUE: INSERT OR REPLACE з боку старої бази.
KEYED = ("processed_tx", "watchlist", "partners", "channel_usernames")


def _uri(path: str, mode: str) -> str:
    from urllib.request import pathname2url
    return "file:" + pathname2url(os.path.abspath(path)) + "?mode=" + mode


def _cols(conn, table, schema="main"):
    return [r[1] for r in conn.execute(f"PRAGMA {schema}.table_info({table})")]


def _has_table(conn, table, schema):
    return conn.execute(
        f"SELECT 1 FROM {schema}.sqlite_master WHERE type='table' AND name=?", (table,)
    ).fetchone() is not None


def migrate(old_path: str, new_path: str) -> dict:
    if not os.path.isfile(old_path):
        raise FileNotFoundError(f"Старої бази немає: {old_path}")
    report = {}
    if os.path.isfile(new_path):
        bak = f"{new_path}.bak-{time.strftime('%Y%m%d-%H%M%S')}"
        shutil.copy2(new_path, bak)
        report["backup"] = bak

    # uri=True потрібен, щоб ATTACH приймав file:...?mode=ro (стара база — лише читання)
    conn = sqlite3.connect(_uri(new_path, "rwc"), uri=True, timeout=30)
    try:
        conn.execute("PRAGMA foreign_keys=OFF")
        for ddl in DDL:
            conn.execute(ddl)
        have = _cols(conn, "users")
        for col, spec in USER_EXTRA_COLS:
            if col not in have:
                conn.execute(f"ALTER TABLE users ADD COLUMN {col} {spec}")
        conn.commit()
        conn.execute("ATTACH DATABASE ? AS old", (_uri(old_path, "ro"),))
    except Exception:
        conn.close()
        raise

    try:
        conn.execute("BEGIN")
        # users
        if _has_table(conn, "users", "old"):
            new_cols = set(_cols(conn, "users"))
            common = [c for c in _cols(conn, "users", "old") if c in new_cols]
            cl = ",".join(common)
            before = conn.execute("SELECT COUNT(*) FROM main.users").fetchone()[0]
            conn.execute(f"INSERT OR REPLACE INTO main.users ({cl}) SELECT {cl} FROM old.users")
            after = conn.execute("SELECT COUNT(*) FROM main.users").fetchone()[0]
            report["users"] = {"before": before, "after": after,
                               "in_old": conn.execute("SELECT COUNT(*) FROM old.users").fetchone()[0]}
        # AUTOINCREMENT-таблиці
        for t, keys in AUTOINC.items():
            if not _has_table(conn, t, "old"):
                continue
            cl = ",".join(keys)
            cond = " AND ".join(f"main.{t}.{k} IS o.{k}" for k in keys)
            before = conn.execute(f"SELECT COUNT(*) FROM main.{t}").fetchone()[0]
            conn.execute(
                f"INSERT INTO main.{t} ({cl}) SELECT {','.join('o.'+k for k in keys)} "
                f"FROM old.{t} o WHERE NOT EXISTS (SELECT 1 FROM main.{t} WHERE {cond})")
            report[t] = {"before": before,
                         "after": conn.execute(f"SELECT COUNT(*) FROM main.{t}").fetchone()[0]}
        # keyed-таблиці
        for t in KEYED:
            if not _has_table(conn, t, "old"):
                continue
            new_cols = set(_cols(conn, t))
            common = [c for c in _cols(conn, t, "old") if c in new_cols and c != "id"]
            cl = ",".join(common)
            before = conn.execute(f"SELECT COUNT(*) FROM main.{t}").fetchone()[0]
            conn.execute(f"INSERT OR REPLACE INTO main.{t} ({cl}) SELECT {cl} FROM old.{t}")
            report[t] = {"before": before,
                         "after": conn.execute(f"SELECT COUNT(*) FROM main.{t}").fetchone()[0]}
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        try:
            conn.execute("DETACH DATABASE old")
        except sqlite3.Error:
            pass
        conn.close()
    return report


def main(argv):
    if len(argv) < 2:
        print(__doc__)
        return 2
    old_path = argv[1]
    new_path = argv[2] if len(argv) > 2 else os.path.join(
        os.path.dirname(os.path.abspath(__file__)), "boohx_uqoza_max_v24.db")
    rep = migrate(old_path, new_path)
    print("Міграцію завершено →", new_path)
    for k, v in rep.items():
        print(f"  {k}: {v}")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
