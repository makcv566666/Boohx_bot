"""
username_engine.py — Розумна система пошуку вільних Telegram-юзернеймів.

Архітектура:
  Producer (генератор)     → PriorityQueue → Consumer-пул (перевірка)
  Адаптивний оптимізатор   → навчається після кожної перевірки
  SQLite-кеш               → жодної повторної перевірки

Модуль підключається до main.py замість поточного наївного генератора.
"""

from __future__ import annotations

import itertools
import math
import os
import queue
import random
import re
import sqlite3
import threading
import time
import heapq
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Callable, Dict, Iterable, Iterator, List, Optional, Set, Tuple

import requests
from bs4 import BeautifulSoup

import five_letter as _f5
import tg_verify


# ═══════════════════════════════════════════════════════════════════════════════
# РОЗДІЛ 1 – ФОНЕТИЧНІ ШАБЛОНИ ТА БІБЛІОТЕКА СКЛАДІВ
# ═══════════════════════════════════════════════════════════════════════════════

_VOWELS     = tuple("aeiou")
_CONSONANTS = tuple("bcdfghjklmnprstvwxz")

# Приголосні, що звучать «чисто» на початку англійського складу
_ONSET_GOOD: Tuple[str, ...] = (
    "b","d","f","g","h","j","k","l","m","n","p","r","s","t","v","w","z",
    "bl","br","cl","cr","dr","fl","fr","gl","gr","pl","pr","sk","sl","sm",
    "sn","sp","st","sw","tr","ch","sh","th",
)
_ONSET_SOLO: Tuple[str, ...] = tuple(
    o for o in _ONSET_GOOD if len(o) == 1
)

# Пари «голосна – приголосна» що утворюють гарні рими
_NUCLEUS_CODA_PAIRS: Tuple[Tuple[str, str], ...] = (
    ("a","k"),("a","n"),("a","r"),("a","t"),("a","x"),("a","z"),
    ("e","l"),("e","n"),("e","r"),("e","t"),("e","x"),
    ("i","k"),("i","n"),("i","s"),("i","t"),("i","x"),
    ("o","n"),("o","r"),("o","t"),("o","x"),("o","z"),
    ("u","b"),("u","k"),("u","l"),("u","n"),("u","r"),("u","x"),
)

# Двоскладові «брендові» ядра (CV + C або VC + V)
_SYLLABLE_CV:  Tuple[str, ...] = tuple(
    f"{c}{v}" for c in _ONSET_SOLO for v in _VOWELS
)
_SYLLABLE_CVC: Tuple[str, ...] = tuple(
    f"{c}{v}{c2}"
    for c  in _ONSET_SOLO
    for v  in _VOWELS
    for c2 in ("k","l","m","n","r","s","t","x","z")
    if c != c2
)

# Популярні короткі префікси (перші 2 літери брендів)
_BRAND_PREFIXES: Tuple[str, ...] = (
    "go","my","up","on","ai","io","ex","in","be","we","do",
    "bo","lo","zo","ko","mo","no","ro","to","vo","po",
    "de","re","le","ve","ne","fe","ge","te","ze","se",
)
# Популярні суфікси (останні 2–3 літери)
_BRAND_SUFFIXES: Tuple[str, ...] = (
    "ly","fy","io","co","ai","me","fi","ki","xi","ni",
    "ox","ex","ix","ax","ux","on","an","en","in","un",
    "zy","ty","sy","ry","ny","py","ky","by","dy","gy",
    "ro","bo","lo","to","no","zo","ko","mo","vo","po",
)

# Шаблони за кількістю символів (ШАБЛОН → кількість знаків що треба вставити)
# V = голосна, C = приголосна
_PATTERNS_BY_LEN: Dict[int, List[str]] = {
    5: ["CVCVC", "CVCCV", "VCCVC", "VCVCV", "CVVCV", "CVCVV"],
    6: ["CVCVCV", "CVCCVC", "VCVCVC", "CVCVCC", "CVVCVC", "CVVCCV"],
    7: ["CVCVCVC", "CVCCVCV", "CVCVCVV", "VCVCVCV", "CVVCVCV"],
    8: ["CVCVCVCV", "CVCCVCVC", "CVCVCVCC"],
}


def _expand_pattern(pattern: str, rng: random.Random) -> str:
    """Генерує рядок за шаблоном типу 'CVCVCV'."""
    result = []
    for ch in pattern:
        if ch == "V":
            result.append(rng.choice(_VOWELS))
        else:
            result.append(rng.choice(_ONSET_SOLO))
    return "".join(result)


def _is_pronounceable(name: str) -> bool:
    """True якщо слово легко вимовляється (немає 3+ приголосних підряд)."""
    run = 0
    for ch in name.lower():
        if ch not in _VOWELS:
            run += 1
            if run >= 3:
                return False
        else:
            run = 0
    return True


# ═══════════════════════════════════════════════════════════════════════════════
# РОЗДІЛ 2 – ОЦІНКА ЯКОСТІ (ДЕТАЛЬНА)
# ═══════════════════════════════════════════════════════════════════════════════

@dataclass
class QualityReport:
    score: float          # 0–100
    grade: str            # A+, A, B, C, D
    stars: str            # ⭐⭐⭐⭐⭐
    pronounceable: bool
    letters_only: bool
    has_brand_pattern: bool
    length: int
    estimated_ton_lo: int
    estimated_ton_hi: int


def score_username(nick: str) -> QualityReport:
    """Повна оцінка якості юзернейма."""
    nick = nick.lower().lstrip("@")
    ln   = len(nick)

    sc = 0.0

    # ── Довжина (рідкість на Fragment) ───────────────────────────────────────
    len_bonus = {4: 45, 5: 35, 6: 20, 7: 10}.get(ln, 5)
    sc += len_bonus

    # ── Тільки літери ─────────────────────────────────────────────────────────
    letters_only = nick.isalpha()
    if letters_only:
        sc += 15

    # ── Вимовність ────────────────────────────────────────────────────────────
    pron = _is_pronounceable(nick)
    if pron:
        sc += 20
    else:
        sc += 3

    # ── Чергування V/C (ідеальний ритм підвищує читабельність) ───────────────
    vowels_in = sum(1 for c in nick if c in _VOWELS)
    ratio = vowels_in / ln if ln else 0
    if 0.3 <= ratio <= 0.7:
        sc += 10

    # ── Брендові шаблони ──────────────────────────────────────────────────────
    has_brand = (
        any(nick.startswith(p) for p in _BRAND_PREFIXES) or
        any(nick.endswith(s)   for s in _BRAND_SUFFIXES)
    )
    if has_brand:
        sc += 12

    # ── Різноманітність символів ──────────────────────────────────────────────
    if len(set(nick)) >= ln * 0.65:
        sc += 8

    # ── 5 літер: слово / палідром / ABABA / вимовне — або штраф ───────────────
    if ln == 5:
        s5 = _f5.score5(nick)
        sc = 0.4 * sc + 0.6 * s5 if s5 else sc * 0.5

    # ── Обмеження максимуму ────────────────────────────────────────────────────
    sc = min(sc, 100.0)

    # ── Орієнтовна ціна на Fragment ───────────────────────────────────────────
    base = {4: (400, 1200), 5: (60, 300), 6: (8, 60), 7: (2, 15)}.get(ln, (1, 8))
    q = sc / 100.0
    ton_lo = int(base[0] + (base[1] - base[0]) * max(0, q - 0.15))
    ton_hi = int(base[0] + (base[1] - base[0]) * q)

    grade_map = ((80, "A+", "⭐⭐⭐⭐⭐"), (65, "A", "⭐⭐⭐⭐"),
                 (45, "B", "⭐⭐⭐"), (25, "C", "⭐⭐"), (0, "D", "⭐"))
    for thresh, grade, stars in grade_map:
        if sc >= thresh:
            break

    return QualityReport(
        score=round(sc, 1),
        grade=grade,
        stars=stars,
        pronounceable=pron,
        letters_only=letters_only,
        has_brand_pattern=has_brand,
        length=ln,
        estimated_ton_lo=ton_lo,
        estimated_ton_hi=ton_hi,
    )


# ═══════════════════════════════════════════════════════════════════════════════
# РОЗДІЛ 3 – КЕШ ПЕРЕВІРЕНИХ ЮЗЕРНЕЙМІВ (SQLite)
# ═══════════════════════════════════════════════════════════════════════════════

class CheckedCache:
    """
    Постійний SQLite-кеш раніше перевіреного (з TTL).

    Словник результатів:
      'free'        — ПІДТВЕРДЖЕНО через Telegram (MTProto). TTL короткий: нік могли зайняти.
      'unconfirmed' — пройшов префільтр, але Telegram-перевірки немає. TTL короткий.
      'taken' | 'invalid' | 'fragment' | 'auction' — остаточні. TTL довгий.
      'error'       — НЕ кешується (це не результат).
      'legacy_free' — старі «free» з евристики t.me. Ніколи не довіряємо (TTL = 0).

    Потокобезпека:
      - `_mem` захищено `_mem_lock`.
      - SQLite-з'єднання per-thread (threading.local), WAL-режим.
    """

    DEFAULT_TTL_FREE  = 600.0          # 10 хв
    DEFAULT_TTL_FINAL = 7 * 86400.0    # 7 днів

    def __init__(self, path: str = "checked_cache.db",
                 ttl_free: float = DEFAULT_TTL_FREE,
                 ttl_final: float = DEFAULT_TTL_FINAL):
        self._path     = path
        self._ttl_free = ttl_free
        self._ttl_final = ttl_final
        self._db_lock  = threading.Lock()        # для записів у SQLite
        self._mem_lock = threading.Lock()        # для _mem
        self._local    = threading.local()
        self._mem: Dict[str, Tuple[str, float]] = {}   # nick → (result, ts)
        self._init_db()
        self._load_into_mem()

    # ── TTL ────────────────────────────────────────────────────────────────────
    def _ttl_for(self, result: str) -> float:
        if result == "legacy_free":
            return 0.0
        if result in ("free", "unconfirmed"):
            return self._ttl_free
        return self._ttl_final

    def _alive(self, result: str, ts: float, now: Optional[float] = None) -> bool:
        return ((now or time.time()) - ts) < self._ttl_for(result)

    # ── Ініціалізація ──────────────────────────────────────────────────────────
    def _conn(self) -> sqlite3.Connection:
        """Per-thread SQLite connection (не змішуємо з'єднання між потоками)."""
        if not hasattr(self._local, "conn") or self._local.conn is None:
            conn = sqlite3.connect(self._path, check_same_thread=False, timeout=10)
            conn.execute("PRAGMA journal_mode=WAL")
            conn.execute("PRAGMA synchronous=NORMAL")
            conn.execute("PRAGMA busy_timeout=5000")
            self._local.conn = conn
        return self._local.conn

    def _init_db(self):
        conn = sqlite3.connect(self._path, timeout=10)
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("""
            CREATE TABLE IF NOT EXISTS checked (
                nick    TEXT PRIMARY KEY,
                result  TEXT NOT NULL,
                ts      REAL NOT NULL
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_ts ON checked(ts)")
        # Міграція v1: старі 'free' були евристикою t.me/Fragment, а не перевіркою
        # Telegram. Саме вони давали «вільні» ніки, які насправді зайняті.
        ver = conn.execute("PRAGMA user_version").fetchone()[0]
        if ver < 1:
            conn.execute("UPDATE checked SET result='legacy_free' WHERE result='free'")
            conn.execute("PRAGMA user_version=1")
        conn.commit()
        conn.close()

    def _load_into_mem(self):
        """Завантажуємо живі записи в пам'ять при старті для O(1) перевірок."""
        conn = sqlite3.connect(self._path, timeout=10)
        rows = conn.execute("SELECT nick, result, ts FROM checked").fetchall()
        conn.close()
        now = time.time()
        with self._mem_lock:
            for nick, result, ts in rows:
                if self._alive(result, ts, now):
                    self._mem[nick] = (result, ts)

    # ── Публічний API ──────────────────────────────────────────────────────────
    def contains(self, nick: str) -> bool:
        return self.get_result(nick) is not None

    def get_result(self, nick: str) -> Optional[str]:
        """Збережений результат, або None якщо немає / TTL минув."""
        with self._mem_lock:
            item = self._mem.get(nick)
            if item is None:
                return None
            if not self._alive(item[0], item[1]):
                del self._mem[nick]
                return None
            return item[0]

    def add(self, nick: str, result: str):
        """result: 'free'|'unconfirmed'|'taken'|'invalid'|'fragment'|'auction'. 'error' ігнорується."""
        if result == "error":
            return
        ts = time.time()
        with self._mem_lock:
            self._mem[nick] = (result, ts)      # перезаписуємо: статус міг змінитись

        with self._db_lock:
            try:
                c = self._conn()
                c.execute(
                    "INSERT OR REPLACE INTO checked (nick, result, ts) VALUES (?,?,?)",
                    (nick, result, ts))
                c.commit()
            except sqlite3.Error:
                pass

    def bulk_contains(self, nicks: Iterable[str]) -> Set[str]:
        """Повертає множину ніків, що вже є в кеші (і не протухли)."""
        return {n for n in nicks if self.get_result(n) is not None}

    def size(self) -> int:
        with self._mem_lock:
            return len(self._mem)

    def clear_old(self, days: int = 30):
        """Видаляє протухлі записи (за TTL їхнього типу) і всі legacy_free."""
        now = time.time()
        with self._db_lock:
            try:
                c = self._conn()
                c.execute("DELETE FROM checked WHERE result='legacy_free'")
                c.execute("DELETE FROM checked WHERE result IN ('free','unconfirmed') AND ts<?",
                          (now - self._ttl_free,))
                c.execute("DELETE FROM checked WHERE result NOT IN ('free','unconfirmed') AND ts<?",
                          (now - max(self._ttl_final, days * 86400),))
                c.commit()
            except sqlite3.Error:
                pass


# ═══════════════════════════════════════════════════════════════════════════════
# РОЗДІЛ 4 – АДАПТИВНИЙ ОПТИМІЗАТОР ШАБЛОНІВ
# ═══════════════════════════════════════════════════════════════════════════════

@dataclass
class _PatternStat:
    tries:   int = 0
    hits:    int = 0   # знайдені вільні ніки
    weight:  float = 1.0

    @property
    def hit_rate(self) -> float:
        return self.hits / self.tries if self.tries else 0.5

    def update_weight(self):
        """EMA-оновлення ваги (більше tries → стабільніша оцінка)."""
        if self.tries < 5:
            self.weight = 1.0
            return
        # m-оцінка Лапласа для рідкісних подій (m=5, prior=0.5)
        smooth = (self.hits + 2.5) / (self.tries + 5)
        self.weight = max(0.1, smooth * 3.0)


class PatternOptimizer:
    """
    Відстежує успіх кожного шаблону і коригує ймовірність його вибору.
    Шаблон = «ім'я сімейства» (наприклад, 'CVCVCV_5', 'prefix_go_6', …).

    Потокобезпека:
      - Один `_lock` захищає _stats і лічильник `_updates_since_save`.
      - `_save()` знімає snapshot під локом, потім пише в DB поза локом.
      - Запис у DB серіалізований через `_db_lock`.
    """

    _PERSIST_INTERVAL = 50   # зберігаємо в БД кожні N оновлень

    def __init__(self, db_path: str = "pattern_stats.db"):
        self._path    = db_path
        self._lock    = threading.Lock()    # захист _stats + лічильника
        self._db_lock = threading.Lock()    # серіалізує DB-записи
        self._stats: Dict[str, _PatternStat] = defaultdict(_PatternStat)
        self._updates_since_save = 0
        self._save_in_flight = False        # не дозволяємо два одночасних збереження
        self._init_db()
        self._load()

    def _init_db(self):
        conn = sqlite3.connect(self._path, timeout=10)
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA busy_timeout=5000")
        conn.execute("""
            CREATE TABLE IF NOT EXISTS pattern_stats (
                family  TEXT PRIMARY KEY,
                tries   INTEGER DEFAULT 0,
                hits    INTEGER DEFAULT 0,
                weight  REAL    DEFAULT 1.0
            )
        """)
        conn.commit()
        conn.close()

    def _load(self):
        conn = sqlite3.connect(self._path, timeout=10)
        try:
            for row in conn.execute("SELECT family, tries, hits, weight FROM pattern_stats"):
                ps = _PatternStat(tries=row[1], hits=row[2], weight=row[3])
                self._stats[row[0]] = ps
        finally:
            conn.close()

    def _save(self, snapshot: List[Tuple]):
        """Записує заздалегідь знятий snapshot у SQLite (викликається у фоні)."""
        with self._db_lock:
            try:
                conn = sqlite3.connect(self._path, timeout=10)
                conn.execute("PRAGMA journal_mode=WAL")
                conn.execute("PRAGMA busy_timeout=5000")
                conn.executemany(
                    "INSERT OR REPLACE INTO pattern_stats (family,tries,hits,weight) "
                    "VALUES (?,?,?,?)",
                    snapshot,
                )
                conn.commit()
                conn.close()
            except sqlite3.Error:
                pass
            finally:
                with self._lock:
                    self._save_in_flight = False

    def _maybe_persist(self):
        """Запускає фонове збереження якщо потрібно і жодного поточного немає."""
        with self._lock:
            if (self._updates_since_save < self._PERSIST_INTERVAL
                    or self._save_in_flight):
                return
            self._updates_since_save = 0
            self._save_in_flight = True
            snapshot = [
                (f, ps.tries, ps.hits, ps.weight)
                for f, ps in self._stats.items()
            ]
        # Запускаємо поза локом, щоб не блокувати воркерів
        threading.Thread(target=self._save, args=(snapshot,), daemon=True).start()

    # ── Публічний API ──────────────────────────────────────────────────────────
    def record(self, family: str, hit: bool):
        """Фіксуємо результат перевірки для конкретного шаблону."""
        with self._lock:
            ps = self._stats[family]
            ps.tries += 1
            if hit:
                ps.hits += 1
            ps.update_weight()
            self._updates_since_save += 1

        self._maybe_persist()

    def weight(self, family: str) -> float:
        with self._lock:
            return self._stats[family].weight

    def top_families(self, n: int = 10) -> List[Tuple[str, float]]:
        with self._lock:
            return sorted(
                ((f, ps.weight) for f, ps in self._stats.items()),
                key=lambda x: -x[1]
            )[:n]

    def weighted_choice(self, families: List[str], rng: random.Random) -> str:
        """Вибираємо шаблон зважено за накопиченою статистикою."""
        weights = [max(0.05, self.weight(f)) for f in families]
        total   = sum(weights)
        r       = rng.uniform(0, total)
        cum     = 0.0
        for f, w in zip(families, weights):
            cum += w
            if r <= cum:
                return f
        return families[-1]


# ═══════════════════════════════════════════════════════════════════════════════
# РОЗДІЛ 5 – РОЗУМНИЙ ГЕНЕРАТОР КАНДИДАТІВ
# ═══════════════════════════════════════════════════════════════════════════════

@dataclass(order=True)
class _Candidate:
    priority: float      # менше = кращий (для heapq)
    nick:     str = field(compare=False)
    family:   str = field(compare=False)


class SmartCandidateGenerator:
    """
    Генерує кандидатів на основі:
      1. Фонетичних шаблонів з адаптивними вагами
      2. Брендових префіксів / суфіксів
      3. Складового підходу (CV, CVC, CVCV, …)
      4. Оцінки якості — кращі перевіряються першими
    """

    _MIN_SCORE_THRESHOLD = 30.0   # відкидаємо явно погані варіанти
    _MIN_SCORE_5 = 50.0           # 5 літер: тільки слово / шаблон / вимовне (див. five_letter.py)

    def __init__(
        self,
        optimizer: PatternOptimizer,
        cache: CheckedCache,
        lengths: Tuple[int, ...] = (5, 6, 7),
        seed: Optional[int] = None,
    ):
        self._opt    = optimizer
        self._cache  = cache
        self._lens   = lengths
        self._rng    = random.Random(seed)
        self._lock   = threading.Lock()

        # Поточний буфер нові кандидатів
        self._buf: List[_Candidate] = []

        # Множина виданих в сесії (щоб не повторювати в рамках одного запуску)
        self._session_seen: Set[str] = set()

    # ── Родини шаблонів ────────────────────────────────────────────────────────
    def _families_for_length(self, ln: int) -> List[str]:
        if ln == 5:
            return list(_f5.FAMILIES5)
        base = [f"pat_{p}_{ln}" for p in _PATTERNS_BY_LEN.get(ln, [])]
        pfx  = [f"pfx_{p}_{ln}" for p in _BRAND_PREFIXES]
        sfx  = [f"sfx_{s}_{ln}" for s in _BRAND_SUFFIXES]
        syl  = [f"syl_{ln}"]
        return base + pfx + sfx + syl

    # ── Генерація за конкретним шаблоном-сімейством ────────────────────────────
    def _gen_from_family(self, family: str, ln: int) -> Optional[str]:
        rng = self._rng
        try:
            if family.startswith("w5_"):
                return _f5.gen5(family, rng)

            if family.startswith("pat_"):
                pat = family.split("_")[1]
                return _expand_pattern(pat, rng)

            elif family.startswith("pfx_"):
                prefix = family.split("_")[1]
                remain = ln - len(prefix)
                if remain < 2:
                    return None
                # Заповнюємо решту CV-складами
                suffix = "".join(
                    rng.choice(_VOWELS) if i % 2 else rng.choice(_ONSET_SOLO)
                    for i in range(remain)
                )
                return prefix + suffix

            elif family.startswith("sfx_"):
                suffix = family.split("_")[1]
                remain = ln - len(suffix)
                if remain < 2:
                    return None
                prefix = "".join(
                    rng.choice(_VOWELS) if i % 2 else rng.choice(_ONSET_SOLO)
                    for i in range(remain)
                )
                return prefix + suffix

            elif family.startswith("syl_"):
                # Скласти зі складів CV або CVC
                parts = []
                total = 0
                while total < ln:
                    needed = ln - total
                    if needed >= 3 and rng.random() < 0.4:
                        # CVC склад
                        c1 = rng.choice(_ONSET_SOLO)
                        v  = rng.choice(_VOWELS)
                        c2 = rng.choice(("k","l","m","n","r","s","t","x","z"))
                        syl = c1 + v + c2
                    else:
                        # CV склад
                        syl = rng.choice(_ONSET_SOLO) + rng.choice(_VOWELS)
                    if total + len(syl) > ln:
                        # Обрізаємо або додаємо одну V/C
                        diff = ln - total
                        if diff == 1:
                            syl = rng.choice(_VOWELS) if parts else rng.choice(_ONSET_SOLO)
                        else:
                            syl = syl[:diff]
                    parts.append(syl)
                    total += len(syl)
                return "".join(parts)

        except Exception:
            pass
        return None

    # ── Поповнення буфера ──────────────────────────────────────────────────────
    def _refill(self, batch: int = 500):
        ln = self._rng.choice(self._lens)
        fams = self._families_for_length(ln)

        new_cands: List[_Candidate] = []
        attempts  = 0

        while len(new_cands) < batch and attempts < batch * 6:
            attempts += 1
            family = self._opt.weighted_choice(fams, self._rng)
            nick   = self._gen_from_family(family, ln)
            if nick is None or len(nick) != ln:
                continue
            nick = nick.lower()
            if not re.fullmatch(r"[a-z][a-z0-9]{3,}", nick):
                continue
            if nick in self._session_seen or self._cache.contains(nick):
                continue
            # Мінімальна фільтрація: відкидаємо невимовні і занадто погані
            if ln == 5:
                if _f5.FILTER5:                # FILTER_5=1: тільки шаблони/вимовні
                    sc = _f5.score5(nick)
                    if sc < self._MIN_SCORE_5 or _f5.likely_taken(nick):
                        continue
                else:                          # без фільтрів: перевіряємо будь-яку комбінацію
                    sc = 50.0
            else:
                if not _is_pronounceable(nick):
                    continue
                sc = score_username(nick).score
                if sc < self._MIN_SCORE_THRESHOLD:
                    continue

            self._session_seen.add(nick)
            # Менший priority = кращий (heapq min-heap)
            # 5 літер: статистика влучань впливає сильніше (слова майже завжди зайняті)
            priority = -(sc + self._opt.weight(family) * (20 if ln == 5 else 5))
            new_cands.append(_Candidate(priority=priority, nick=nick, family=family))

        with self._lock:
            for c in new_cands:
                heapq.heappush(self._buf, c)

    # ── Головний метод ─────────────────────────────────────────────────────────
    def next_batch(self, n: int = 200) -> List[_Candidate]:
        """Повертає N найкращих кандидатів, поповнюючи буфер за потреби."""
        with self._lock:
            if len(self._buf) < n:
                # Запускаємо поповнення у поточному потоці синхронно
                pass  # буде нижче

        if len(self._buf) < n:
            self._refill(max(500, n * 3))

        with self._lock:
            batch = []
            while self._buf and len(batch) < n:
                batch.append(heapq.heappop(self._buf))
            return batch


# ═══════════════════════════════════════════════════════════════════════════════
# РОЗДІЛ 6 – ПЕРЕВІРКА TELEGRAM + FRAGMENT (перенесено з main.py)
# ═══════════════════════════════════════════════════════════════════════════════

_USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 Chrome/123.0.0.0 Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/122.0.0.0 Safari/537.36",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 Mobile/15E148 Safari/604.1",
]


def _rand_ua() -> str:
    return random.choice(_USER_AGENTS)


def _check_telegram_fast(username: str, session: requests.Session) -> Optional[bool]:
    """
    ПРЕФІЛЬТР (евристика по t.me/<нік>), НЕ остаточний вердикт.
    True  = t.me порожній (нік МОЖЕ бути вільним — підтверджує тільки tg_verify)
    False = на t.me є профіль → точно зайнятий
    None  = мережева помилка / rate-limit
    """
    try:
        r = session.get(
            f"https://t.me/{username}",
            headers={"User-Agent": _rand_ua()},
            timeout=3.0,
            allow_redirects=True,
        )
        if r.status_code == 429:
            return None
        if r.status_code == 404:
            return True
        if r.status_code != 200:
            return None
        html = r.text
        # Швидкі текстові сигнали «зайнятий» (без BS4 — max швидкість)
        TAKEN_SIGNALS = (
            "tgme_page_photo", "tgme_page_action_button",
            "tgme_page_extra", "tgme_widget",
        )
        if any(sig in html for sig in TAKEN_SIGNALS):
            return False
        # Перевірка og:description через простий regex
        m = re.search(r'<meta\s+property="og:description"\s+content="([^"]{5,})"', html)
        if m:
            return False
        return True
    except Exception:
        return None


def _check_fragment_quick(username: str, session: requests.Session) -> str:
    """
    ПРЕФІЛЬТР Fragment. Повертає: 'free' | 'taken' | 'auction' | 'unknown'
    Два методи: JSON API (швидше), потім legacy endpoint.

    УВАГА: 'free' тут означає лише «Fragment не заперечує» (нік не виставлений),
    а 'unknown' — «Fragment не відповів». Жодне з них НЕ доводить, що нік
    вільний у Telegram: це робить tg_verify.verify_username_telegram().
    """
    headers_json = {
        "User-Agent": _rand_ua(),
        "Accept": "application/json, */*; q=0.01",
        "X-Requested-With": "XMLHttpRequest",
        "Referer": f"https://fragment.com/@{username}",
    }
    # Метод 0: JSON API
    try:
        r = session.post(
            "https://fragment.com/api",
            data={"method": "searchAuctions", "query": username, "filter": "username"},
            headers=headers_json,
            timeout=4.0,
        )
        if r.status_code == 200:
            data = r.json()
            for item in (data.get("auctions") or []):
                if (item.get("username") or "").lower().lstrip("@") == username:
                    state = str(item.get("state", "")).lower()
                    if state in ("active", "auction"):
                        return "auction"
                    if state in ("sold", "taken", "unavailable"):
                        return "taken"
                    if state in ("available", "sale"):
                        return "free"
    except Exception:
        pass

    # Метод 1: legacy /username/{nick}
    try:
        r = session.get(
            f"https://fragment.com/username/{username}",
            headers={"User-Agent": _rand_ua()},
            timeout=3.0,
            allow_redirects=False,
        )
        if r.status_code in (302, 404):
            return "free"
        if r.status_code == 200:
            low = r.text.lower()
            if any(s in low for s in ("auction", "place a bid")):
                return "auction"
            if any(s in low for s in ("username taken", "already claimed", "unavailable")):
                return "taken"
            if any(s in low for s in ("available for", "buy for", "buy now")):
                return "free"
    except Exception:
        pass

    return "unknown"


# ═══════════════════════════════════════════════════════════════════════════════
# РОЗДІЛ 7 – ПАЙПЛАЙН-СКАНЕР (producer-consumer)
# ═══════════════════════════════════════════════════════════════════════════════

@dataclass
class ScanResult:
    nick:          str
    is_free:       bool
    tg_status:     str    # 'free'|'taken'|'error'
    frag_status:   str    # 'free'|'taken'|'auction'|'unknown'
    quality:       QualityReport
    family:        str
    checked_at:    float = field(default_factory=time.time)
    confirmed:     bool = False          # True ⇢ підтверджено через MTProto checkUsername
    verify_status: str = "unverified"    # 'free' | 'unverified'


def _prefilter5_enabled() -> bool:
    """PREFILTER_5 (env або bot_config.txt), за замовчуванням увімкнено."""
    try:
        base = os.path.dirname(os.path.abspath(__file__))
        v = (os.environ.get("PREFILTER_5") or tg_verify._read_cfg_file(base).get("PREFILTER_5") or "1")
    except Exception:
        v = "1"
    return v.strip().lower() not in ("0", "false", "no", "off")


class PipelineScanner:
    """
    Безперервний сканер з паралельними воркерами.

    Архітектура:
      ┌─────────────┐    PriorityQueue    ┌────────────────────┐
      │  Генератор  │ ─── кандидати ───▶ │  Worker-пул (N th) │ ─▶ result_cb
      │  (daemon)   │                    │  TG + Fragment      │
      └─────────────┘                    └────────────────────┘
               ▲                                   │
               │       PatternOptimizer ◀──────────┘
               └────── оновлення ваг ──────────────┘

    Використання:
        def on_found(r: ScanResult): ...

        scanner = PipelineScanner(
            on_found=on_found,
            workers=20,
            lengths=(5, 6),
            db_dir="/path/to/bot/",
        )
        scanner.start()
        # … пізніше …
        scanner.stop()
    """

    _QUEUE_MAX_SIZE  = 2000   # не більше N кандидатів у черзі
    _REFILL_TRIGGER  = 300    # поповнюємо коли менше цього
    _FRAG_RETRIES    = 2      # скільки разів перепитати Fragment, якщо він «unknown»
    _VERIFY_MAX_WAIT = 20.0   # макс. очікування однієї MTProto-перевірки у воркері
    _VERIFY_MAX_ERRS = 3      # після стількох «error» поспіль нік відкладаємо (не кешуємо)
    _PREFILTER_LENGTHS = (6,) # довжини зі швидким HTTP-префільтром перед MTProto (базово)

    def __init__(
        self,
        on_found: Callable[[ScanResult], None],
        on_progress: Optional[Callable[[int, int], None]] = None,
        workers: int = 16,
        lengths: Tuple[int, ...] = (5, 6),
        db_dir: str = ".",
        proxies: Optional[List[Dict]] = None,
    ):
        self._on_found    = on_found
        self._on_progress = on_progress
        self._workers     = workers
        # 5 літер: майже всі зайняті → HTTP-префільтр (t.me + Fragment) відсіює їх паралельно,
        # а дорогі MTProto-слоти лишаються для тих, кого префільтр не заперечив.
        # Вимкнути: PREFILTER_5=0 у bot_config.txt / змінній середовища.
        self._prefilter_lengths = tuple(self._PREFILTER_LENGTHS) + (
            (5,) if _prefilter5_enabled() and 5 not in self._PREFILTER_LENGTHS else ())
        self._proxies     = proxies or []
        self._proxy_lock  = threading.Lock()

        # Персистентні компоненти
        self._cache   = get_shared_cache(db_dir)
        self._err_counts: Dict[str, int] = {}
        self._err_lock = threading.Lock()
        self._opt     = PatternOptimizer(os.path.join(db_dir, "pattern_stats.db"))
        self._gen     = SmartCandidateGenerator(
            optimizer=self._opt,
            cache=self._cache,
            lengths=lengths,
        )

        # Черга пріоритетів (кандидати sorted за score)
        self._queue: queue.PriorityQueue = queue.PriorityQueue(maxsize=self._QUEUE_MAX_SIZE)

        # Черга до MTProto-верифікаторів (розмір задається в start())
        self._verify_queue: queue.Queue = queue.Queue(maxsize=8)

        self._stop_event   = threading.Event()
        self._checked_total = 0
        self._found_total   = 0
        self._lock_stats    = threading.Lock()

        self._threads: List[threading.Thread] = []

    # ── Проксі ────────────────────────────────────────────────────────────────
    def _get_proxy(self) -> Optional[Dict]:
        with self._proxy_lock:
            if not self._proxies:
                return None
            return random.choice(self._proxies)

    def _make_session(self) -> requests.Session:
        s = requests.Session()
        proxy = self._get_proxy()
        if proxy:
            s.proxies.update(proxy)
        s.headers.update({"User-Agent": _rand_ua()})
        return s

    # ── Producer: безперервно поповнює чергу ─────────────────────────────────
    def _producer(self):
        while not self._stop_event.is_set():
            if self._queue.qsize() < self._REFILL_TRIGGER:
                batch = self._gen.next_batch(300)
                for cand in batch:
                    if self._stop_event.is_set():
                        break
                    try:
                        self._queue.put_nowait((cand.priority, cand.nick, cand.family))
                    except queue.Full:
                        break
            else:
                time.sleep(0.05)

    # ── Допоміжне ─────────────────────────────────────────────────────────────
    def _count_checked(self):
        with self._lock_stats:
            self._checked_total += 1
            ct = self._checked_total
            ft = self._found_total
        if self._on_progress:
            try:
                self._on_progress(ct, ft)
            except Exception:
                pass

    def _pause(self, secs: float):
        """Пауза, що перривається зупинкою сканера (щоб stop() не чекав до 5 с)."""
        self._stop_event.wait(secs)

    def _verifier_count(self) -> int:
        """Скільки MTProto-верифікаторів тримати: ~2 запити «у польоті» на сесію.

        Більше немає сенсу — швидкість визначає TG_VERIFY_INTERVAL на сесію, а не
        кількість потоків; надлишок лише збільшує чергу слотів і ризик FloodWait.
        """
        try:
            n = len(tg_verify.settings().get("sessions") or [])
        except Exception:
            n = 1
        return max(2, min(8, 2 * max(1, n)))

    def _http_prefilter(self, nick: str, session: requests.Session):
        """HTTP-префільтр (t.me → Fragment) — лише ВІДСІЮЄ зайняті, нічого не підтверджує.

        Повертає (taken_label | None, frag_status, session).
          taken_label = 'taken' | 'auction' → нік зайнятий/виставлений (кешуємо надовго);
          None → «не заперечено»: кандидат іде у фінальну MTProto-перевірку.
        Збій t.me / Fragment (None, 'unknown') НЕ означає «вільний»: кандидат просто
        не відсіяний і все одно мусить пройти MTProto.
        """
        tg = _check_telegram_fast(nick, session)
        if tg is None and not self._stop_event.is_set():
            session = self._make_session()        # інший проксі / UA
            tg = _check_telegram_fast(nick, session)
        if tg is False:
            return "taken", "unknown", session

        frag = _check_fragment_quick(nick, session)
        for _ in range(self._FRAG_RETRIES):
            if frag != "unknown" or self._stop_event.is_set():
                break
            time.sleep(0.3)
            session = self._make_session()
            frag = _check_fragment_quick(nick, session)
        if frag in ("taken", "auction"):
            return frag, frag, session
        return None, frag, session

    def _put_verify(self, item) -> bool:
        """Передає кандидата верифікаторам. Повна черга = природний back-pressure:
        HTTP-воркери не женуть префільтр швидше, ніж MTProto встигає перевіряти."""
        while not self._stop_event.is_set():
            try:
                self._verify_queue.put(item, timeout=0.5)
                return True
            except queue.Full:
                continue
        return False

    # ── Consumer (HTTP-стадія): кеш → префільтр → черга MTProto ──────────────
    def _worker(self):
        session = self._make_session()
        consecutive_errors = 0

        while not self._stop_event.is_set():
            try:
                _prio, nick, family = self._queue.get(timeout=0.5)
            except queue.Empty:
                continue

            try:
                # Подвійна перевірка кешу (producer міг додати до того, як воркер перевірив)
                if self._cache.contains(nick):
                    continue

                # Backoff якщо TG rate-limit
                if consecutive_errors >= 5:
                    self._pause(min(5.0, consecutive_errors * 0.5))

                if not tg_verify.is_configured():
                    consecutive_errors = self._worker_fallback(
                        _prio, nick, family, session, consecutive_errors)
                    continue

                frag_status = "unknown"
                if len(nick) in self._prefilter_lengths:
                    # 5–6 літер: швидкий шлях. Зайняті відсіюються паралельним HTTP,
                    # дорогі MTProto-слоти витрачаються лише на тих, кого префільтр
                    # не заперечив.
                    taken, frag_status, session = self._http_prefilter(nick, session)
                    if taken is not None:
                        self._cache.add(nick, taken)
                        self._opt.record(family, hit=False)
                        self._count_checked()
                        continue

                # решта (і 5 літер при PREFILTER_5=0) — одразу в MTProto.
                self._put_verify((_prio, nick, family, frag_status))
            finally:
                self._queue.task_done()

    # ── Fallback без MTProto-сесії: старий евристичний pipeline ──────────────
    def _worker_fallback(self, _prio, nick, family, session, consecutive_errors) -> int:
        tg = _check_telegram_fast(nick, session)
        if tg is None:
            consecutive_errors += 1
            try:
                self._queue.put_nowait((_prio, nick, family))
            except queue.Full:
                pass
            return consecutive_errors
        if tg is False:
            self._cache.add(nick, "taken")
            self._opt.record(family, hit=False)
            self._count_checked()
            return 0
        frag_status = _check_fragment_quick(nick, session)
        if frag_status in ("taken", "auction"):
            self._cache.add(nick, frag_status)
            self._opt.record(family, hit=False)
            self._count_checked()
            return 0
        self._count_checked()
        # Сесію не налаштовано: показуємо, але чесно позначаємо «не підтверджено»
        self._report_found(nick, family, frag_status, confirmed=False)
        return 0

    # ── Verifier (MTProto-стадія): фінальна, авторитетна перевірка ───────────
    def _verifier(self):
        session = self._make_session()          # лише для довідкового Fragment-запиту
        while not self._stop_event.is_set():
            try:
                _prio, nick, family, frag_pre = self._verify_queue.get(timeout=0.5)
            except queue.Empty:
                continue
            try:
                session = self._verify_one(_prio, nick, family, frag_pre, session)
            except Exception:
                # збій не повинен убивати верифікатор і ніколи не дає «free»
                pass
            finally:
                self._verify_queue.task_done()

    def _verify_one(self, _prio, nick, family, frag_pre, session):
        if self._cache.contains(nick):
            return session
        verdict = tg_verify.verify_username_telegram(
            nick, max_wait=self._VERIFY_MAX_WAIT)

        if verdict in ("taken", "invalid", "fragment"):
            self._count_checked()
            self._cache.add(nick, verdict)
            self._opt.record(family, hit=False)
            self._clear_err(nick)
            return session

        if verdict != "free":
            # 'error' (timeout / FloodWait / мережа) — НЕ вільний і НЕ кешується.
            if self._bump_err(nick) < self._VERIFY_MAX_ERRS:
                try:
                    self._queue.put_nowait((_prio, nick, family))
                except queue.Full:
                    pass
            # не довбемо Telegram, поки сесії у FloodWait
            self._pause(min(5.0, max(0.5, tg_verify.cooldown_remaining())))
            return session

        self._clear_err(nick)
        self._count_checked()
        # Fragment потрібен лише для деталей звіту й не може скасувати вердикт MTProto.
        frag_status = frag_pre
        if frag_status not in ("free", "taken", "auction"):
            frag_status = _check_fragment_quick(nick, session)
        self._report_found(nick, family, frag_status, confirmed=True)
        return session

    def _report_found(self, nick: str, family: str, frag_status: str, confirmed: bool):
        self._cache.add(nick, "free" if confirmed else "unconfirmed")
        self._opt.record(family, hit=True)

        quality = score_username(nick)
        result  = ScanResult(
            nick=nick,
            is_free=True,
            tg_status="free",
            frag_status=frag_status,
            quality=quality,
            family=family,
            confirmed=confirmed,
            verify_status="free" if confirmed else "unverified",
        )
        with self._lock_stats:
            self._found_total += 1
        try:
            self._on_found(result)
        except Exception:
            pass

    def _bump_err(self, nick: str) -> int:
        with self._err_lock:
            self._err_counts[nick] = self._err_counts.get(nick, 0) + 1
            if len(self._err_counts) > 5000:
                self._err_counts.clear()
            return self._err_counts[nick]

    def _clear_err(self, nick: str):
        with self._err_lock:
            self._err_counts.pop(nick, None)

    # ── Керування сканером ────────────────────────────────────────────────────
    def start(self):
        """Запускає producer + N worker-потоків."""
        self._stop_event.clear()

        prod = threading.Thread(target=self._producer, name="producer", daemon=True)
        prod.start()
        self._threads.append(prod)

        if tg_verify.is_configured():
            n_ver = self._verifier_count()
            self._verify_queue = queue.Queue(maxsize=n_ver * 2)
            for i in range(n_ver):
                t = threading.Thread(target=self._verifier, name=f"verifier-{i}", daemon=True)
                t.start()
                self._threads.append(t)

        for i in range(self._workers):
            t = threading.Thread(target=self._worker, name=f"worker-{i}", daemon=True)
            t.start()
            self._threads.append(t)

    def stop(self, timeout: float = 5.0):
        """Зупиняє всі потоки."""
        self._stop_event.set()
        deadline = time.time() + timeout
        for t in self._threads:
            t.join(timeout=max(0.0, deadline - time.time()))
        self._threads.clear()

    def is_running(self) -> bool:
        return not self._stop_event.is_set()

    @property
    def stats(self) -> Dict:
        with self._lock_stats:
            return {
                "checked": self._checked_total,
                "found":   self._found_total,
                "cached":  self._cache.size(),
                "queued":  self._queue.qsize(),
                "top_patterns": self._opt.top_families(5),
            }


# ═══════════════════════════════════════════════════════════════════════════════
# РОЗДІЛ 8 – ОДИНОЧНА ПЕРЕВІРКА (для /scan і /watch)
# ═══════════════════════════════════════════════════════════════════════════════

_SHARED_CACHES: Dict[str, CheckedCache] = {}
_CACHE_LOCK = threading.Lock()


def get_shared_cache(db_dir: str = ".") -> CheckedCache:
    """Один екземпляр кешу на файл (бот і сканер ділять одну пам'ять і TTL)."""
    path = os.path.abspath(os.path.join(db_dir, "checked_cache.db"))
    with _CACHE_LOCK:
        c = _SHARED_CACHES.get(path)
        if c is None:
            st = tg_verify.settings()
            c = CheckedCache(path, ttl_free=st.get("ttl_free", CheckedCache.DEFAULT_TTL_FREE),
                             ttl_final=st.get("ttl_final", CheckedCache.DEFAULT_TTL_FINAL))
            _SHARED_CACHES[path] = c
        return c


def _frag_from_verdict(verdict: str, frag_pre: str) -> str:
    """Що показати у рядку «Fragment» за вердиктом Telegram."""
    if verdict == "fragment":
        return "sale"
    if frag_pre in ("taken", "auction"):
        return frag_pre
    if verdict == "invalid":
        return "invalid"
    return frag_pre if frag_pre in ("free", "unknown") else "unknown"


def check_single(
    nick: str,
    session: Optional[requests.Session] = None,
    cache: Optional[CheckedCache] = None,
    force_recheck: bool = False,
) -> Dict:
    """
    Перевірка одного ніку (для /scan @username і watchlist).

    Повертає:
      nick, tg, frag, is_free, confirmed, verify, quality[, from_cache]
    де is_free=True ТІЛЬКИ якщо:
      • сесія налаштована і verify_username_telegram() == 'free'  (confirmed=True), або
      • сесії нема, префільтр не заперечує                          (confirmed=False, ⚠️).

    Нік, який Telegram вважає taken/invalid/fragment, ніколи не is_free.
    """
    nick = nick.lower().lstrip("@").strip()
    if not re.fullmatch(r"[a-z][a-z0-9_]{3,31}", nick):
        return {"nick": nick, "tg": None, "frag": "invalid", "verify": "invalid",
                "is_free": False, "confirmed": False, "quality": None}

    def _out(is_free, confirmed, verify, frag, tg, **extra):
        d = {"nick": nick, "tg": tg, "frag": frag, "verify": verify,
             "is_free": is_free, "confirmed": confirmed, "quality": score_username(nick)}
        d.update(extra)
        return d

    # ── Кеш (TTL враховано всередині) ─────────────────────────────────────────
    if cache and not force_recheck:
        cached = cache.get_result(nick)
        if cached is not None:
            if cached == "free":
                return _out(True, True, "free", "free", True, from_cache=True)
            if cached == "unconfirmed":
                if not tg_verify.is_configured():
                    return _out(True, False, "unverified", "unknown", True, from_cache=True)
                # з'явилась сесія — «unconfirmed» більше не годиться, перевіряємо заново
            else:
                frag = {"fragment": "sale", "auction": "auction",
                        "invalid": "invalid"}.get(cached, "taken" if cached == "taken" else cached)
                return _out(False, False, cached, frag, False, from_cache=True)

    sess = session or requests.Session()
    configured = tg_verify.is_configured()

    # Якщо MTProto налаштований, це єдина авторитетна перевірка доступності.
    # t.me і Fragment повільні, евристичні та дублюють запит; використовуємо їх
    # лише в окремих звітах після знаходження вільного username.
    if configured:
        verdict = tg_verify.verify_username_telegram(nick)
        if verdict == "free":
            if cache:
                cache.add(nick, "free")
            return _out(True, True, "free", "unknown", True)
        if verdict in ("taken", "invalid", "fragment"):
            if cache:
                cache.add(nick, verdict)
            return _out(False, False, verdict, _frag_from_verdict(verdict, "unknown"), False)
        return _out(False, False, "error", "unknown", None)

    # ── Префільтр: t.me ───────────────────────────────────────────────────────
    tg = _check_telegram_fast(nick, sess)
    if tg is False:                       # профіль на t.me → точно зайнятий
        if cache:
            cache.add(nick, "taken")
        return _out(False, False, "taken", "not_checked", False)
    if tg is None and not configured:     # мережа лягла, а перевірити нічим
        return _out(False, False, "error", "not_checked", None)

    # ── Префільтр: Fragment (unknown → перепитуємо) ───────────────────────────
    frag = "unknown"
    if tg is True:
        frag = _check_fragment_quick(nick, sess)
        for _ in range(PipelineScanner._FRAG_RETRIES):
            if frag != "unknown":
                break
            time.sleep(0.3)
            frag = _check_fragment_quick(nick, requests.Session())
        if frag in ("taken", "auction"):
            if cache:
                cache.add(nick, frag)
            return _out(False, False, frag, frag, True)

    # Сесії нема → «вільний, але не підтверджено»
    if cache:
        cache.add(nick, "unconfirmed")
    return _out(True, False, "unverified", frag, True)


def parallel_check_list(
    nicks: List[str],
    workers: int = 10,
    cache: Optional[CheckedCache] = None,
) -> List[Dict]:
    """
    Перевіряє список ніків паралельно (для /scan @n1 @n2 …).
    Повертає результати в тому ж порядку.
    """
    import concurrent.futures

    results: Dict[str, Dict] = {}
    lock = threading.Lock()

    def _do(nick):
        r = check_single(nick, cache=cache)
        with lock:
            results[nick] = r

    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as ex:
        list(ex.map(_do, nicks))

    return [results.get(n, {"nick": n, "is_free": False, "frag": "error"}) for n in nicks]


# ═══════════════════════════════════════════════════════════════════════════════
# РОЗДІЛ 9 – ФУНКЦІЯ-ОБГОРТКА ДЛЯ ІНТЕГРАЦІЇ З main.py
# ═══════════════════════════════════════════════════════════════════════════════

def find_free_username_fast(
    chat_id: int,
    msg_id: int,
    bot_send_fn: Callable,
    bot_edit_fn: Callable,
    length: int = 6,
    max_workers: int = 20,
    lang: str = "ua",
    db_dir: str = ".",
    on_found: Optional[Callable[[ScanResult], None]] = None,
) -> Optional[ScanResult]:
    """
    Блокуюча функція — знаходить один вільний нік і повертає його.
    Замінює parallel_find_free() у main.py.

    Аргументи:
        chat_id, msg_id   — для оновлення повідомлення в боті
        bot_send_fn       — bot.send_message(chat_id, text)
        bot_edit_fn       — bot.edit_message_text(text, chat_id, msg_id)
        length            — цільова довжина (5 або 6)
        max_workers       — кількість паралельних потоків
        lang              — 'ua' | 'ru' | 'en'
        db_dir            — директорія для SQLite-файлів
        on_found          — callback при знахідці (опційно)

    Повертає ScanResult або None якщо не знайдено за ліміт.
    """
    found_event = threading.Event()
    found_result: List[Optional[ScanResult]] = [None]

    _labels = {
        "ua": f"{'5' if length == 5 else '6'}-літерних ніків",
        "ru": f"{'5' if length == 5 else '6'}-буквенных ников",
        "en": f"{'5' if length == 5 else '6'}-letter usernames",
    }
    label = _labels.get(lang, _labels["en"])

    def _on_found(r: ScanResult):
        if not found_event.is_set() and r.quality.length == length:
            found_result[0] = r
            found_event.set()
            if on_found:
                on_found(r)

    # Прогрес у чат НЕ оновлюємо: часті edit_message_text — зайві запити до Bot API
    # і гальмо. Користувач бачить одне початкове повідомлення та фінальний результат.
    scanner = PipelineScanner(
        on_found=_on_found,
        on_progress=None,
        workers=max_workers,
        lengths=(length,),
        db_dir=db_dir,
    )
    scanner.start()

    # Чекаємо знахідку або таймаут 5 хвилин
    found_event.wait(timeout=300)
    scanner.stop()

    return found_result[0]
