"""
test_tg_verify.py — перевірка авторитетного вердикту Telegram БЕЗ реальної мережі.

Запуск:   python test_tg_verify.py          (або: python -m unittest -v test_tg_verify)

Telethon не потрібен: клієнти підміняються FakeClient, а помилки — класами з
тими самими іменами, що й у Telethon (UsernameOccupiedError, FloodWaitError, …).
tg_verify розпізнає їх за ім'ям/RPC-повідомленням, тому тест рівноцінний реальним помилкам.

Покрито: free, occupied, invalid, purchase, floodwait (пауза+повтор, ротація, ліміт),
rate-limit 1 req/s, unknown-від-Fragment, відсутня сесія, TTL-кеш і міграцію старих «free».
"""
import os
import sqlite3
import sys
import tempfile
import threading
import time
import unittest
from unittest import mock

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import tg_verify                      # noqa: E402
import username_engine as ue          # noqa: E402


# ── Фейкові помилки Telethon (імена як у бібліотеці) ─────────────────────────
class RPCError(Exception):
    pass


class UsernameOccupiedError(RPCError):
    message = "USERNAME_OCCUPIED"


class UsernameInvalidError(RPCError):
    message = "USERNAME_INVALID"


class UsernamePurchaseAvailableError(RPCError):
    message = "USERNAME_PURCHASE_AVAILABLE"


class UsernameNotModifiedError(RPCError):
    message = "USERNAME_NOT_MODIFIED"


class FloodWaitError(RPCError):
    def __init__(self, seconds):
        super().__init__(f"A wait of {seconds} seconds is required")
        self.seconds = seconds


class AuthKeyUnregisteredError(RPCError):
    message = "AUTH_KEY_UNREGISTERED"


class FakeClock:
    def __init__(self):
        self.t = 0.0

    def __call__(self):
        return self.t

    async def sleep(self, d):
        self.t += max(0.0, d)


class FakeClient:
    """Мок TelegramClient: відповідає за сценарієм {nick: [відповідь, ...]}."""

    def __init__(self, script, clock):
        self.script = {k: list(v) for k, v in script.items()}
        self.clock = clock
        self.calls = []

    async def connect(self):
        pass

    async def is_user_authorized(self):
        return True

    async def disconnect(self):
        pass

    async def __call__(self, request):
        nick = request.username
        self.calls.append((nick, self.clock.t))
        out = self.script[nick].pop(0)
        if isinstance(out, BaseException):
            raise out
        return out


def make_verifier(scripts, interval=1.0, max_wait=120.0):
    """scripts: {session_string: {nick: [відповіді]}} → (verifier, {session: FakeClient}, clock)"""
    clock = FakeClock()
    clients = {}

    def factory(ss):
        clients[ss] = FakeClient(scripts[ss], clock)
        return clients[ss]

    st = {"api_id": 1, "api_hash": "x", "sessions": list(scripts), "interval": interval,
          "max_wait": max_wait, "ttl_free": 600.0, "ttl_final": 604800.0}
    v = tg_verify.TelegramVerifier(st, client_factory=factory, clock=clock)
    v._sleep = clock.sleep
    return v, clients, clock, st


def install(scripts, **kw):
    v, clients, clock, st = make_verifier(scripts, **kw)
    tg_verify.configure(settings=st, verifier=v)
    return v, clients, clock


def uninstall_sessions():
    st = {"api_id": 0, "api_hash": "", "sessions": [], "interval": 1.0, "max_wait": 5.0,
          "ttl_free": 600.0, "ttl_final": 604800.0}
    tg_verify.configure(settings=st, verifier=tg_verify.TelegramVerifier(st))


# ══════════════════════════════════════════════════════════════════════════════
class TestVerifyBranches(unittest.TestCase):
    def test_free(self):
        install({"S": {"toshu": [True]}})
        self.assertEqual(tg_verify.verify_username_telegram("toshu"), "free")

    def test_occupied(self):
        install({"S": {"toshu": [UsernameOccupiedError()]}})
        self.assertEqual(tg_verify.verify_username_telegram("toshu"), "taken")

    def test_not_modified_is_taken(self):
        install({"S": {"toshu": [UsernameNotModifiedError()]}})
        self.assertEqual(tg_verify.verify_username_telegram("toshu"), "taken")

    def test_invalid(self):
        install({"S": {"toshu": [UsernameInvalidError()]}})
        self.assertEqual(tg_verify.verify_username_telegram("toshu"), "invalid")

    def test_bad_format_is_invalid_without_request(self):
        _, clients, _ = install({"S": {}})
        self.assertEqual(tg_verify.verify_username_telegram("ab"), "invalid")
        self.assertEqual(tg_verify.verify_username_telegram("1abcd"), "invalid")
        self.assertFalse(clients)   # до клієнта навіть не дійшло

    def test_purchase_available_is_fragment_not_free(self):
        install({"S": {"toshu": [UsernamePurchaseAvailableError()]}})
        self.assertEqual(tg_verify.verify_username_telegram("toshu"), "fragment")

    def test_false_bool_is_not_free(self):
        install({"S": {"toshu": [False]}})
        self.assertEqual(tg_verify.verify_username_telegram("toshu"), "taken")

    def test_unknown_exception_is_error(self):
        install({"S": {"toshu": [RuntimeError("boom")]}})
        self.assertEqual(tg_verify.verify_username_telegram("toshu"), "error")

    def test_no_session_is_error_never_free(self):
        uninstall_sessions()
        self.assertFalse(tg_verify.is_configured())
        self.assertEqual(tg_verify.verify_username_telegram("toshu"), "error")


class TestFloodWait(unittest.TestCase):
    def test_floodwait_pauses_then_retries_and_is_never_free_by_itself(self):
        _, clients, clock = install({"S": {"toshu": [FloodWaitError(5), True]}})
        self.assertEqual(tg_verify.verify_username_telegram("toshu"), "free")
        calls = clients["S"].calls
        self.assertEqual(len(calls), 2)                 # повторили
        self.assertGreaterEqual(calls[1][1] - calls[0][1], 5)   # і дочекались e.seconds

    def test_floodwait_then_occupied(self):
        install({"S": {"toshu": [FloodWaitError(3), UsernameOccupiedError()]}})
        self.assertEqual(tg_verify.verify_username_telegram("toshu"), "taken")

    def test_floodwait_longer_than_limit_is_error_not_free(self):
        v, _, _ = install({"S": {"toshu": [FloodWaitError(3600), True]}}, max_wait=120)
        self.assertEqual(tg_verify.verify_username_telegram("toshu"), "error")
        self.assertGreater(tg_verify.cooldown_remaining(), 3000)

    def test_rotation_to_second_session_on_flood(self):
        _, clients, clock = install({
            "A": {"toshu": [FloodWaitError(3600)]},
            "B": {"toshu": [True]},
        })
        self.assertEqual(tg_verify.verify_username_telegram("toshu"), "free")
        self.assertEqual(len(clients["A"].calls), 1)
        self.assertEqual(len(clients["B"].calls), 1)
        self.assertLess(clock.t, 5)    # не чекали годину — взяли іншу сесію

    def test_dead_session_is_skipped(self):
        _, clients, _ = install({
            "A": {"toshu": [AuthKeyUnregisteredError()]},
            "B": {"toshu": [UsernameOccupiedError()]},
        })
        self.assertEqual(tg_verify.verify_username_telegram("toshu"), "taken")


class TestRateLimitAndCache(unittest.TestCase):
    def test_one_request_per_second_per_session(self):
        _, clients, _ = install({"S": {n: [True] for n in ("aaaa", "bbbb", "cccc")}}, interval=1.0)
        for n in ("aaaa", "bbbb", "cccc"):
            self.assertEqual(tg_verify.verify_username_telegram(n), "free")
        times = [t for _, t in clients["S"].calls]
        self.assertEqual(len(times), 3)
        self.assertTrue(all(b - a >= 1.0 for a, b in zip(times, times[1:])), times)

    def test_verdict_cached_with_ttl(self):
        _, clients, _ = install({"S": {"toshu": [True, UsernameOccupiedError()]}})
        self.assertEqual(tg_verify.verify_username_telegram("toshu"), "free")
        self.assertEqual(tg_verify.verify_username_telegram("toshu"), "free")   # з кешу
        self.assertEqual(len(clients["S"].calls), 1)
        # TTL «free» минув → нова перевірка, нік уже зайняли
        with tg_verify._VERDICT_LOCK:
            st, _exp = tg_verify._VERDICTS["toshu"]
            tg_verify._VERDICTS["toshu"] = (st, time.time() - 1)
        self.assertEqual(tg_verify.verify_username_telegram("toshu"), "taken")

    def test_error_is_not_cached(self):
        _, clients, _ = install({"S": {"toshu": [RuntimeError("x"), True]}})
        self.assertEqual(tg_verify.verify_username_telegram("toshu"), "error")
        self.assertEqual(tg_verify.verify_username_telegram("toshu"), "free")


# ══════════════════════════════════════════════════════════════════════════════
def run_worker(scanner, nick, timeout=20.0):
    """Проганяє один нік через PipelineScanner (HTTP-воркер + MTProto-верифікатор) без мережі."""
    scanner._pause = lambda *_: None        # без реальних пауз (як і раніше з time.sleep)
    scanner._queue.put((0, nick, "fam"))
    threads = [threading.Thread(target=scanner._worker, daemon=True),
               threading.Thread(target=scanner._verifier, daemon=True)]
    for t in threads:
        t.start()
    end = time.time() + timeout
    while time.time() < end:
        if (scanner._queue.unfinished_tasks == 0 and scanner._queue.empty()
                and scanner._verify_queue.unfinished_tasks == 0
                and scanner._verify_queue.empty()):
            time.sleep(0.1)       # дати верифікатору повернути нік у чергу при помилці
            if (scanner._queue.unfinished_tasks == 0
                    and scanner._verify_queue.unfinished_tasks == 0):
                break
        time.sleep(0.05)
    scanner._stop_event.set()
    for t in threads:
        t.join(5)


class TestScannerWorker(unittest.TestCase):
    def setUp(self):
        # Ці тести перевіряють режим «5 літер одразу в MTProto» (PREFILTER_5=0);
        # режим з префільтром покрито в test_fast_path.FiveLetterPath.
        _env = mock.patch.dict("os.environ", {"PREFILTER_5": "0"})
        _env.start()
        self.addCleanup(_env.stop)
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        ue._SHARED_CACHES.clear()
        self.found = []

    def scanner(self, db_dir=None):
        return ue.PipelineScanner(on_found=self.found.append, workers=1,
                                  lengths=(5,), db_dir=db_dir or self.tmp.name)

    def prefilter(self, tg=True, frag="free"):
        self.frag_calls = []

        def _frag(nick, sess):
            self.frag_calls.append(nick)
            return frag

        stack = [mock.patch.object(ue, "_check_telegram_fast", lambda n, s: tg),
                 mock.patch.object(ue, "_check_fragment_quick", _frag),
                 mock.patch.object(ue.time, "sleep", lambda *_: None)]
        for m in stack:
            m.start()
            self.addCleanup(m.stop)

    # ── вердикти Telegram ────────────────────────────────────────────────────
    def test_free_is_found_and_confirmed(self):
        install({"S": {"toshu": [True]}})
        self.prefilter()
        sc = self.scanner()
        run_worker(sc, "toshu")
        self.assertEqual([r.nick for r in self.found], ["toshu"])
        self.assertTrue(self.found[0].confirmed)
        self.assertEqual(sc._cache.get_result("toshu"), "free")

    def test_taken_invalid_fragment_never_reported_free(self):
        for err, cached in ((UsernameOccupiedError(), "taken"),
                            (UsernameInvalidError(), "invalid"),
                            (UsernamePurchaseAvailableError(), "fragment")):
            with self.subTest(verdict=cached):
                self.found.clear()
                ue._SHARED_CACHES.clear()
                with tempfile.TemporaryDirectory() as d:
                    install({"S": {"toshu": [err]}})
                    self.prefilter(tg=True, frag="free")     # префільтр «пропускає» нік
                    sc = self.scanner(d)
                    run_worker(sc, "toshu")
                    self.assertEqual(self.found, [])          # ← головний критерій
                    self.assertEqual(sc._cache.get_result("toshu"), cached)
                    ue._SHARED_CACHES.clear()

    def test_floodwait_in_pipeline_never_free(self):
        install({"S": {"toshu": [FloodWaitError(3600)] * 5}}, max_wait=120)
        self.prefilter()
        sc = self.scanner()
        sc._VERIFY_MAX_WAIT = 20.0
        run_worker(sc, "toshu")
        self.assertEqual(self.found, [])
        self.assertIsNone(sc._cache.get_result("toshu"))   # error не кешуємо

    # ── Fragment «unknown» ──────────────────────────────────────────────────
    def test_fragment_unknown_is_retried_then_handed_to_telegram_taken(self):
        install({"S": {"toshu": [UsernameOccupiedError()]}})
        self.prefilter(frag="unknown")
        sc = self.scanner()
        run_worker(sc, "toshu")
        self.assertEqual(len(self.frag_calls), 0)                       # MTProto вирішує напряму
        self.assertEqual(self.found, [])                               # зайнятий за MTProto

    def test_fragment_unknown_but_telegram_free_is_confirmed(self):
        install({"S": {"toshu": [True]}})
        self.prefilter(frag="unknown")
        sc = self.scanner()
        run_worker(sc, "toshu")
        self.assertEqual(len(self.found), 1)
        self.assertTrue(self.found[0].confirmed)

    def test_no_session_result_is_flagged_unconfirmed(self):
        uninstall_sessions()
        self.prefilter(frag="unknown")
        sc = self.scanner()
        run_worker(sc, "toshu")
        self.assertEqual(len(self.found), 1)
        self.assertFalse(self.found[0].confirmed)                 # ⚠️ не підтверджено
        self.assertEqual(sc._cache.get_result("toshu"), "unconfirmed")   # НЕ 'free'

    def test_fragment_is_details_only_after_telegram_free(self):
        _, clients, _ = install({"S": {"toshu": [True]}})
        self.prefilter(frag="auction")
        sc = self.scanner()
        run_worker(sc, "toshu")
        self.assertEqual([r.nick for r in self.found], ["toshu"])
        # Fragment не може скасувати авторитетний MTProto verdict.
        self.assertTrue(clients.get("S") and clients["S"].calls)


class TestCheckSingleAndCache(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        ue._SHARED_CACHES.clear()
        for target, repl in (("_check_telegram_fast", lambda n, s: True),
                             ("_check_fragment_quick", lambda n, s: "unknown")):
            m = mock.patch.object(ue, target, repl)
            m.start()
            self.addCleanup(m.stop)
        m = mock.patch.object(ue.time, "sleep", lambda *_: None)
        m.start()
        self.addCleanup(m.stop)

    def test_each_verdict(self):
        cases = ((True, True, True, "free"),
                 (UsernameOccupiedError(), False, False, "taken"),
                 (UsernameInvalidError(), False, False, "invalid"),
                 (UsernamePurchaseAvailableError(), False, False, "fragment"),
                 (FloodWaitError(3600), False, False, "error"))
        for out, is_free, confirmed, verify in cases:
            with self.subTest(verify=verify):
                install({"S": {"toshu": [out] * 3}}, max_wait=120)
                r = ue.check_single("toshu", cache=ue.get_shared_cache(self.tmp.name),
                                    force_recheck=True)
                self.assertEqual((r["is_free"], r["confirmed"], r["verify"]),
                                 (is_free, confirmed, verify))
        self.assertEqual(r["frag"], "unknown")

    def test_fragment_purchase_shown_as_sale(self):
        install({"S": {"toshu": [UsernamePurchaseAvailableError()]}})
        r = ue.check_single("toshu", force_recheck=True)
        self.assertEqual(r["frag"], "sale")
        self.assertFalse(r["is_free"])

    def test_without_session_unconfirmed(self):
        uninstall_sessions()
        r = ue.check_single("toshu", force_recheck=True)
        self.assertTrue(r["is_free"])
        self.assertFalse(r["confirmed"])

    def test_legacy_free_rows_are_not_trusted(self):
        path = os.path.join(self.tmp.name, "checked_cache.db")
        c = sqlite3.connect(path)
        c.execute("CREATE TABLE checked (nick TEXT PRIMARY KEY, result TEXT NOT NULL, ts REAL NOT NULL)")
        c.executemany("INSERT INTO checked VALUES (?,?,?)",
                      [("oldfree", "free", time.time()), ("oldtaken", "taken", time.time())])
        c.commit()
        c.close()
        cache = ue.CheckedCache(path)
        self.assertIsNone(cache.get_result("oldfree"))        # евристичний «free» викинуто
        self.assertEqual(cache.get_result("oldtaken"), "taken")

    def test_ttl_expiry(self):
        cache = ue.CheckedCache(os.path.join(self.tmp.name, "c.db"), ttl_free=10, ttl_final=100)
        cache.add("freenick", "free")
        cache.add("takennick", "taken")
        cache.add("errnick", "error")
        self.assertIsNone(cache.get_result("errnick"))
        real = time.time
        with mock.patch.object(ue.time, "time", lambda: real() + 50):
            self.assertIsNone(cache.get_result("freenick"))             # TTL free минув
            self.assertEqual(cache.get_result("takennick"), "taken")    # final ще живий
        with mock.patch.object(ue.time, "time", lambda: real() + 500):
            self.assertIsNone(cache.get_result("takennick"))


# ══════════════════════════════════════════════════════════════════════════════
class TestMainChecker(unittest.TestCase):
    """HighSpeedNetworkChecker з main.py (потрібні pyTelegramBotAPI; без нього — пропуск)."""

    @classmethod
    def setUpClass(cls):
        try:
            import telebot  # noqa: F401
        except ImportError:
            raise unittest.SkipTest("pyTelegramBotAPI не встановлено — тест main.py пропущено")
        os.environ.setdefault("BOT_TOKEN", "123456:TEST")
        try:
            import main
        except SystemExit:
            raise unittest.SkipTest("main.py не стартує без налаштувань")
        cls.main = main

    def setUp(self):
        H = self.main.HighSpeedNetworkChecker
        free = {"status": "free", "auction_price": None, "auction_bids": None,
                "auction_ends": None, "buy_now": None}
        for name, ret in (("_check_telegram", True), ("_check_fragment", free),
                          ("_check_fragment_quick", dict(free, status="unknown"))):
            m = mock.patch.object(H, name, staticmethod(lambda *a, _r=ret, **k: _r))
            m.start()
            self.addCleanup(m.stop)
        m = mock.patch.object(self.main.proxy_manager, "get", lambda: None)
        m.start()
        self.addCleanup(m.stop)
        m = mock.patch.object(self.main.time, "sleep", lambda *_: None)
        m.start()
        self.addCleanup(m.stop)

    def test_all_entry_points_share_the_same_meaning(self):
        H = self.main.HighSpeedNetworkChecker
        for err, expect in ((UsernameOccupiedError(), False), (UsernameInvalidError(), False),
                            (UsernamePurchaseAvailableError(), False), (True, True)):
            with self.subTest(err=repr(err)):
                install({"S": {"toshu": [err] * 4}})
                tg_verify._VERDICTS.clear()
                self.assertEqual(H.is_username_free("toshu"), expect)
                tg_verify._VERDICTS.clear()
                self.assertEqual(H.is_username_free_fast("toshu"), expect)

    def test_unconfirmed_without_session(self):
        uninstall_sessions()
        status, _ = self.main.HighSpeedNetworkChecker.check_availability("toshu", fast=True)
        self.assertEqual(status, "unconfirmed")


if __name__ == "__main__":
    unittest.main(verbosity=2)
