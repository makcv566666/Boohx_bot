"""
five_letter.py — красиві 5-літерні юзернейми: валідатор + генератор.

Ідея: майже всі реальні слова на 5 літер у Telegram давно зайняті, тому шукаємо
НЕ слова, а гарні вимовні «слова-схожі» за чіткими шаблонами. Шаблонів багато
(мільйони комбінацій), тож пул не вичерпується, а кожна родина шаблонів
має власну статистику влучань (PatternOptimizer) — вдалі шаблони крутяться частіше.

Тири (від кращого до гіршого):
  tpl      — шаблонний красивий нік (див. родини нижче)
  pal      — палідром   ABCBA   (tamat, alula)
  abab     — чергування ABABA   (tatat, ototo)
  natural  — вимовне «слово-схоже» (триграмна модель із words5.txt, якщо файл є)
  word     — реальне слово зі словника (майже завжди зайняте → нижчий бал)

Все інше (gbkxk, djwtq, …) — відсікається (score5 == 0).

Родини шаблонів (w5_*):
  w5_cv     CVCVC     zokel, vimar, katus
  w5_cvccv  CVCCV     tarko, velto, mirza
  w5_vcvcv  VCVCV     avelo, ozira, ikuna
  w5_cvvcv  CVVCV     kaizo, noela, taiko
  w5_sfx    CVC+суфікс  zorix, kalyn, tevon, lumex
  w5_pfx    префікс+2   luxor, zenix, novik, kaiza
  w5_dbl    подвоєна  bella, kirro, tosso
  w5_ycv    …y        narky, velly, torly
  w5_pal    ABCBA     tamat
  w5_abab   ABABA     tatat
  + (якщо є words5.txt) w5_word, w5_mut, w5_markov
"""
from __future__ import annotations

import math
import os
import random
from collections import defaultdict
from typing import Dict, List, Optional

_V = frozenset("aeiou")
_ALPHA = "abcdefghijklmnopqrstuvwxyz"
_DIR = os.path.dirname(os.path.abspath(__file__))

# «Красиві» приголосні та їхні ваги при генерації (рідші літери = менше конкурентів)
_W_C: Dict[str, float] = {
    "k": 3, "z": 3, "v": 3, "x": 1.5, "l": 3, "r": 3, "n": 3, "m": 3,
    "s": 2, "t": 3, "d": 2, "b": 2, "g": 2, "f": 2, "p": 2, "j": 1,
}
_NICE_C = "".join(_W_C)                 # літери шаблонних ніків (без c, h, q, w; y — лише в кінці)
_NICE = frozenset(_NICE_C) | _V
_C_LIST = list(_W_C)
_C_WTS = [_W_C[c] for c in _C_LIST]
_END_C = "nrlsxmktdz"                   # гарні кінцеві приголосні
_V_START = "aaeiioou"                   # початкові голосні (a/i/o частіше)

# Дозволені групи з двох приголосних усередині (CVCCV) та подвоєння
_CLUSTERS = frozenset(
    "rk rt rn rm rl rv rd rz lk lt lm ln lv ld lz st sk sp sm sn "
    "nd nt nk mb mp kt ks tr dr br gr pr fr kr vr bl gl pl fl kl zl xt zm zn".split())
_DOUBLES = frozenset("ll rr ss nn mm tt kk zz ff dd bb gg pp".split())
_V_PAIRS = frozenset("ai ei ia io ie ea oi".split())

_SFX2 = ("ex ix ox ax ux on an en in un ar or er ir al ol el il yn ia io "
         "ko to ro vo no mo la ra na ma va za ri li ni ki mi vi zi xi").split()
_PFX3 = "nex zen kai lux vex nox ark neo zed ryn vio kyr dex".split()

_YCL = tuple(_DOUBLES) + tuple("rk lk rt lt nd nt st sk mp rn rm lm".split())   # група перед «y»

FAMILIES_TPL = ("w5_cv", "w5_cvccv", "w5_vcvcv", "w5_cvvcv", "w5_sfx",
                "w5_pfx", "w5_dbl", "w5_ycv", "w5_pal", "w5_abab")
FAMILIES_DICT = ("w5_word", "w5_mut", "w5_markov")

# ── Словник (необов'язковий) ─────────────────────────────────────────────────
# Формат words5.txt: «слово оцінка_частоти» на рядок. Оцінка ≥ 4 = «напевно зайняте».
WORDS: Dict[str, float] = {}
try:
    with open(os.path.join(_DIR, "words5.txt"), encoding="utf-8") as _f:
        for _ln in _f:
            _p = _ln.split()
            if len(_p) == 2 and len(_p[0]) == 5:
                WORDS[_p[0]] = float(_p[1])
except (OSError, ValueError):
    pass  # без словника працюють усі шаблонні родини

def _filter5_enabled() -> bool:
    """FILTER_5=1 (env або bot_config.txt) вмикає шаблони/фільтри. За замовчуванням ВИМКНЕНО:
    для 5 літер перевіряється будь-яка комбінація a–z без відбору."""
    v = os.environ.get("FILTER_5", "")
    if not v:
        try:
            with open(os.path.join(_DIR, "bot_config.txt"), encoding="utf-8") as f:
                for ln in f:
                    k, _, val = ln.partition("=")
                    if k.strip() == "FILTER_5":
                        v = val.strip()
        except OSError:
            pass
    return v.strip().lower() in ("1", "true", "yes", "on")


FILTER5 = _filter5_enabled()
FAMILIES5 = (FAMILIES_TPL + (FAMILIES_DICT if WORDS else ())) if FILTER5 else ("w5_rand",)

# ── Триграмна модель «звучить як слово» (лише коли є словник) ────────────────
_TRI: Dict[str, Dict[str, int]] = defaultdict(lambda: defaultdict(int))
for _w, _z in WORDS.items():
    if _z >= 2.5:
        _s = "^^" + _w + "$"
        for _i in range(2, len(_s)):
            _TRI[_s[_i - 2:_i]][_s[_i]] += 1
_TOT = {k: sum(v.values()) for k, v in _TRI.items()}
_K = 0.05
_N = len(_ALPHA) + 1
_NAT_MIN = -2.5


def _naturalness(nick: str) -> float:
    """Середній log-ймовірності триграм (0 = ідеально, ≈ -4 = сміття)."""
    if not _TOT:
        return -9.0                      # моделі немає → «вимовним» не вважаємо
    s, lp = "^^" + nick + "$", 0.0
    for i in range(2, len(s)):
        ctx = s[i - 2:i]
        lp += math.log((_TRI[ctx].get(s[i], 0) + _K) / (_TOT.get(ctx, 0) + _K * _N)) \
            if ctx in _TRI else math.log(1 / _N)
    return lp / (len(s) - 2)


# ── Структурні перевірки ─────────────────────────────────────────────────────
def _max_cons_run(n: str) -> int:
    best = run = 0
    for ch in n:
        run = 0 if ch in _V else run + 1
        best = max(best, run)
    return best


def _is_pal(n: str) -> bool:
    return n == n[::-1] and len(set(n)) >= 2


def _is_abab(n: str) -> bool:
    return n[0] == n[2] == n[4] and n[1] == n[3] and n[0] != n[1]


def _triple(n: str) -> bool:
    return n[0] == n[1] == n[2] or n[1] == n[2] == n[3] or n[2] == n[3] == n[4]


def _pretty(n: str) -> bool:
    """Шаблонний «гарний» нік: чисті літери, вимовні групи, без каші."""
    body = n[:-1] if n[-1] == "y" else n
    if n[0] == "y" or not all(c in _NICE for c in body):
        return False
    if n[-1] == "y" and n[-2] not in _NICE:
        return False
    if _triple(n):
        return False
    vcount = sum(1 for c in n if c in _V) + (1 if n[-1] == "y" else 0)
    if vcount < 2 or vcount > 3:
        return False
    i = 0
    while i < 4:
        a, b = n[i], n[i + 1]
        if a == b:
            if a in _V:
                if a not in "eo":
                    return False
            elif a + b not in _DOUBLES:
                return False
        elif a in _V and b in _V:
            if a + b not in _V_PAIRS:
                return False
        elif a not in _V and b not in _V and b != "y":
            if a + b not in _CLUSTERS:
                return False
        i += 1
    if _max_cons_run(n[:-1] if n[-1] == "y" else n) > 2:
        return False
    return True


def kind5(nick: str) -> str:
    """'tpl' | 'pal' | 'abab' | 'natural' | 'word' | '' (відхилено)."""
    n = nick.lower().lstrip("@")
    if len(n) != 5 or not n.isalpha() or not n.isascii():
        return ""
    if n in WORDS:
        return "word"
    if _triple(n):
        return ""
    if _is_abab(n) or _is_pal(n):
        if _max_cons_run(n) <= 2 and any(c in _V for c in n):
            return "abab" if _is_abab(n) else "pal"
        return ""
    if _pretty(n):
        return "tpl"
    if _max_cons_run(n) >= 3 or not any(c in _V for c in n):
        return ""
    return "natural" if _naturalness(n) >= _NAT_MIN else ""


def likely_taken(nick: str) -> bool:
    """Поширене слово — у Telegram майже напевно зайняте, не перевіряємо."""
    return WORDS.get(nick.lower(), 0.0) >= 4.0


def score5(nick: str) -> float:
    """0 = сміття (відхилити), інакше 40–100."""
    n = nick.lower().lstrip("@")
    k = kind5(n)
    if not k:
        return 0.0
    if k == "word":
        return min(72.0, 60 + (WORDS[n] - 2.0) * 3)             # слова майже завжди зайняті
    if k in ("pal", "abab"):
        return 72.0 if _max_cons_run(n) <= 1 else 62.0
    if k == "natural":
        return min(70.0, 50 + (_naturalness(n) - _NAT_MIN) * 20)
    # tpl: чим «чистіший» скелет і красивіше закінчення — тим вище
    sc = 62.0
    if all((c in _V) == (i % 2 == 1) for i, c in enumerate(n)):
        sc += 8                                                  # ідеальне CVCVC
    elif all((c in _V) == (i % 2 == 0) for i, c in enumerate(n)):
        sc += 6                                                  # VCVCV
    if n[-1] in "aoi" or n[-1] in _END_C:
        sc += 4                                                  # приємне закінчення
    if n[-2:] in _SFX2 or n[:3] in _PFX3:
        sc += 3                                                  # схоже на ім'я/бренд
    if any(c in "xzk" for c in n):
        sc += 2                                                  # «круті» літери
    return min(sc, 79.0)


# ── Генерація ────────────────────────────────────────────────────────────────
_WLIST = [w for w, z in WORDS.items() if z < 4.0]            # рідкісні слова
_MLIST = [w for w, z in WORDS.items() if 2.5 <= z < 5.5]     # бази для мутацій


def _c(rng: random.Random) -> str:
    return rng.choices(_C_LIST, _C_WTS)[0]


def _ce(rng: random.Random) -> str:
    return rng.choice(_END_C)


def _v(rng: random.Random) -> str:
    return rng.choice("aaaoooeeiiiu")      # u рідше — «круглі» голосні красивіші


def _cluster(rng: random.Random) -> str:
    return rng.choice(tuple(_CLUSTERS))


def _markov(rng: random.Random) -> Optional[str]:
    if not _TRI:
        return None
    out, ctx = "", "^^"
    for _ in range(5):
        nxt = _TRI.get(ctx)
        if not nxt:
            return None
        chars = [c for c in nxt if c != "$"]
        if not chars:
            return None
        ch = rng.choices(chars, [nxt[c] for c in chars])[0]
        out += ch
        ctx = ctx[1] + ch
    return out


def gen5(family: str, rng: random.Random) -> Optional[str]:
    """Один кандидат із родини (може повернути None / сміття — фільтрує score5)."""
    if family == "w5_rand":                     # без фільтрів: будь-які 5 літер a–z
        return "".join(rng.choice(_ALPHA) for _ in range(5))
    if family == "w5_cv":                       # CVCVC
        return _c(rng) + _v(rng) + _c(rng) + _v(rng) + _ce(rng)
    if family == "w5_cvccv":                    # CVCCV
        return _c(rng) + _v(rng) + _cluster(rng) + _v(rng)
    if family == "w5_vcvcv":                    # VCVCV
        return rng.choice(_V_START) + _c(rng) + _v(rng) + _c(rng) + _v(rng)
    if family == "w5_cvvcv":                    # CVVCV
        return _c(rng) + rng.choice(tuple(_V_PAIRS)) + _c(rng) + _v(rng)
    if family == "w5_sfx":                      # CVC + суфікс
        return _c(rng) + _v(rng) + _ce(rng) + rng.choice(_SFX2)
    if family == "w5_pfx":                      # префікс + CV / VC
        p = rng.choice(_PFX3)
        tail = (_c(rng) + _v(rng)) if rng.random() < 0.5 else (_v(rng) + _ce(rng))
        return p + tail
    if family == "w5_dbl":                      # CVDDV (bella, kirro)
        d = rng.choice(tuple(_DOUBLES))
        return _c(rng) + _v(rng) + d + _v(rng)
    if family == "w5_ycv":                      # CVCCy / CVCVy-подібні
        return _c(rng) + _v(rng) + rng.choice(_YCL) + "y"
    if family == "w5_pal":                      # ABCBA: CVCVC або VCVCV
        if rng.random() < 0.7:
            a, b, m = _c(rng), _v(rng), _c(rng)
        else:
            a, b, m = _v(rng), _c(rng), _v(rng)
        return a + b + m + b + a
    if family == "w5_abab":
        a, b = _c(rng), _v(rng)
        if rng.random() < 0.5:
            a, b = b, a
        return a + b + a + b + a
    if family == "w5_word":
        return rng.choice(_WLIST) if _WLIST else None
    if family == "w5_mut":                      # слово з однією зміненою літерою
        if not _MLIST:
            return None
        w = rng.choice(_MLIST)
        i = rng.randrange(5)
        pool = "aeiou" if w[i] in _V else _NICE_C
        return w[:i] + rng.choice(pool) + w[i + 1:]
    if family == "w5_markov":
        return _markov(rng)
    return None
