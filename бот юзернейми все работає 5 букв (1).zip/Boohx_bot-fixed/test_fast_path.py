# -*- coding: utf-8 -*-
"""
Тести швидкого шляху 6-літерних username та безпеки вердиктів.
Мережа і Telegram повністю підмінені — запуск: python -m unittest -v test_fast_path
"""
import asyncio
import tempfile
import threading
import time
import unittest
from unittest import mock

import username_engine as ue
import tg_verify


class _Calls:
    def __init__(self):
        self.tme = []
        self.frag = []
        self.mtproto = []
        self.lock = threading.Lock()

    def add(self, bucket, nick):
        with self.lock:
            getattr(self, bucket).append(nick)


def run_scanner(items, *, configured=True, tme=None, frag=None, verdicts=None,
                verify_delay=0.0, workers=6, timeout=15.0):
    """items: [(nick, family)]. Повертає (found, calls, scanner)."""
    calls = _Calls()
    found = []
    tmp = tempfile.mkdtemp()

    def fake_tme(nick, session):
        calls.add("tme", nick)
        return (tme or {}).get(nick, True)

    def fake_frag(nick, session):
        calls.add("frag", nick)
        return (frag or {}).get(nick, "free")

    def fake_verify(nick, use_cache=True, max_wait=None):
        calls.add("mtproto", nick)
        if verify_delay:
            time.sleep(verify_delay)
        return (verdicts or {}).get(nick, "free")

    patches = [
        mock.patch.object(ue, "_check_telegram_fast", fake_tme),
        mock.patch.object(ue, "_check_fragment_quick", fake_frag),
        mock.patch.object(tg_verify, "is_configured", lambda: configured),
        mock.patch.object(tg_verify, "verify_username_telegram", fake_verify),
        mock.patch.object(tg_verify, "settings", lambda: {"sessions": ["s1"]}),
        mock.patch.object(tg_verify, "cooldown_remaining", lambda: 0.0),
        mock.patch.object(ue.time, "sleep", lambda s: None),   # без реальних пауз
    ]
    for p in patches:
        p.start()
    try:
        sc = ue.PipelineScanner(on_found=found.append, workers=workers,
                                lengths=(6,), db_dir=tmp)
        sc._gen.next_batch = lambda n=200: []          # без випадкового генератора
        sc._pause = lambda *_: None
        sc._VERIFY_MAX_ERRS = 2
        sc.start()
        for i, (nick, fam) in enumerate(items):
            sc._queue.put((float(i), nick, fam))
        deadline = time.time() + timeout
        while time.time() < deadline:
            if (sc._queue.unfinished_tasks == 0
                    and sc._verify_queue.unfinished_tasks == 0):
                time.sleep(0.15)
                if (sc._queue.unfinished_tasks == 0
                        and sc._verify_queue.unfinished_tasks == 0):
                    break
            time.sleep(0.02)
        sc.stop(timeout=2.0)
        return found, calls, sc
    finally:
        for p in patches:
            p.stop()


class SixLetterFastPath(unittest.TestCase):
    def test_tme_taken_never_reaches_mtproto(self):
        found, calls, sc = run_scanner(
            [("kadumi", "f"), ("bonaru", "f")],
            tme={"kadumi": False, "bonaru": False})
        self.assertEqual(calls.mtproto, [])
        self.assertEqual(found, [])
        self.assertEqual(sc._cache.get_result("kadumi"), "taken")

    def test_fragment_taken_or_auction_never_reaches_mtproto(self):
        found, calls, sc = run_scanner(
            [("kadumi", "f"), ("bonaru", "f")],
            frag={"kadumi": "taken", "bonaru": "auction"})
        self.assertEqual(calls.mtproto, [])
        self.assertEqual(found, [])
        self.assertEqual(sc._cache.get_result("kadumi"), "taken")
        self.assertEqual(sc._cache.get_result("bonaru"), "auction")

    def test_survivor_is_confirmed_by_mtproto_only(self):
        found, calls, sc = run_scanner([("kadumi", "f")])
        self.assertEqual(calls.mtproto, ["kadumi"])
        self.assertEqual(len(found), 1)
        self.assertTrue(found[0].confirmed)
        self.assertEqual(found[0].verify_status, "free")
        self.assertEqual(sc._cache.get_result("kadumi"), "free")

    def test_prefilter_free_without_mtproto_verdict_is_not_reported(self):
        # t.me/Fragment кажуть «вільний», а MTProto каже taken → не знахідка
        found, calls, sc = run_scanner(
            [("kadumi", "f")], verdicts={"kadumi": "taken"})
        self.assertEqual(found, [])
        self.assertEqual(sc._cache.get_result("kadumi"), "taken")

    def test_prefilter_failures_do_not_mean_free(self):
        # t.me = None (rate-limit), Fragment = unknown → без MTProto «free» не буде
        found, calls, sc = run_scanner(
            [("kadumi", "f")], tme={"kadumi": None}, frag={"kadumi": "unknown"},
            verdicts={"kadumi": "taken"})
        self.assertEqual(calls.mtproto, ["kadumi"])      # префільтр не відсіяв → фінал
        self.assertEqual(found, [])

    def test_prefilter_runs_for_every_6letter_before_mtproto(self):
        items = [(f"nick{c}{d}", "f") for c in "abc" for d in "xy"]
        _, calls, _ = run_scanner(items)
        self.assertEqual(sorted(calls.tme), sorted(n for n, _ in items))
        self.assertEqual(sorted(calls.frag), sorted(n for n, _ in items))


class FiveLetterPath(unittest.TestCase):
    def test_five_letter_prefilter_then_mtproto(self):
        found, calls, sc = run_scanner([("kadum", "w5_x")])
        self.assertEqual(calls.tme, ["kadum"])          # префільтр увімкнено за замовчуванням
        self.assertEqual(calls.mtproto, ["kadum"])      # «вільний» підтверджує тільки MTProto
        self.assertEqual(len(found), 1)
        self.assertTrue(found[0].confirmed)

    def test_five_letter_taken_on_tme_skips_mtproto(self):
        found, calls, sc = run_scanner([("kadum", "w5_x")], tme={"kadum": False})
        self.assertEqual(calls.mtproto, [])             # слот MTProto не витрачено
        self.assertEqual(found, [])

    def test_five_letter_prefilter_can_be_disabled(self):
        with mock.patch.dict("os.environ", {"PREFILTER_5": "0"}):
            found, calls, sc = run_scanner([("kadum", "w5_x")])
        self.assertEqual(calls.tme, [])
        self.assertEqual(calls.mtproto, ["kadum"])
        self.assertEqual(len(found), 1)

    def test_five_letter_taken_verdict(self):
        found, calls, sc = run_scanner(
            [("kadum", "w5_x")], verdicts={"kadum": "taken"})
        self.assertEqual(found, [])
        self.assertEqual(sc._cache.get_result("kadum"), "taken")


class VerdictSafety(unittest.TestCase):
    def test_error_is_never_free_and_never_cached(self):
        found, calls, sc = run_scanner(
            [("kadumi", "f")], verdicts={"kadumi": "error"})
        self.assertEqual(found, [])
        self.assertIsNone(sc._cache.get_result("kadumi"))
        # повторні спроби обмежені _VERIFY_MAX_ERRS
        self.assertLessEqual(len(calls.mtproto), 3)

    def test_no_session_marks_unconfirmed_not_free(self):
        found, calls, sc = run_scanner([("kadumi", "f")], configured=False)
        self.assertEqual(calls.mtproto, [])
        self.assertEqual(len(found), 1)
        self.assertFalse(found[0].confirmed)
        self.assertEqual(found[0].verify_status, "unverified")
        self.assertEqual(sc._cache.get_result("kadumi"), "unconfirmed")

    def test_taken_not_rechecked_when_cached(self):
        found, calls, sc = run_scanner([("kadumi", "f")], tme={"kadumi": False})
        self.assertEqual(sc._cache.get_result("kadumi"), "taken")
        # другий прогін із тією ж кеш-директорією не повинен ходити в мережу
        self.assertTrue(sc._cache.contains("kadumi"))

    def test_free_ttl_is_short_taken_ttl_is_long(self):
        c = ue.CheckedCache(path=tempfile.mktemp(suffix=".db"))
        self.assertLessEqual(c._ttl_for("free"), 3600)
        self.assertGreaterEqual(c._ttl_for("taken"), 86400)
        c.add("aaaaaa", "error")
        self.assertIsNone(c.get_result("aaaaaa"))          # error не кешується
        c.add("bbbbbb", "free")
        # прострочений free більше не показується як актуальний
        c._mem["bbbbbb"] = ("free", time.time() - c._ttl_free - 1)
        self.assertIsNone(c.get_result("bbbbbb"))


class Throughput(unittest.TestCase):
    def test_http_stage_is_not_blocked_by_slow_mtproto(self):
        # 40 кандидатів: 36 відсіюються t.me, 4 доходять до MTProto (0.25 с кожен).
        # Послідовно було б ≥ 40*0.25=10 с; з розділеними стадіями — ≈ 4*0.25 + HTTP.
        items = [(f"{chr(97 + i // 26)}{chr(97 + i % 26)}tuvw", "f") for i in range(40)]
        tme = {n: (k % 10 == 0) for k, (n, _) in enumerate(items)}   # True = «не заперечено»
        t0 = time.time()
        found, calls, _ = run_scanner(items, tme=tme, verify_delay=0.25, workers=8)
        dt = time.time() - t0
        self.assertEqual(len(calls.mtproto), 4)
        self.assertLess(dt, 5.0)


class NoProgressSpam(unittest.TestCase):
    def test_find_free_username_fast_never_edits_message(self):
        edits, sends = [], []
        calls = _Calls()
        tmp = tempfile.mkdtemp()
        with mock.patch.object(ue, "_check_telegram_fast", lambda n, s: False), \
                mock.patch.object(ue, "_check_fragment_quick", lambda n, s: "free"), \
                mock.patch.object(tg_verify, "is_configured", lambda: True), \
                mock.patch.object(tg_verify, "verify_username_telegram",
                                  lambda n, use_cache=True, max_wait=None: "taken"), \
                mock.patch.object(tg_verify, "settings", lambda: {"sessions": ["s"]}), \
                mock.patch.object(ue.PipelineScanner, "start", lambda self: None), \
                mock.patch.object(ue.threading.Event, "wait", lambda self, timeout=None: False):
            res = ue.find_free_username_fast(
                chat_id=1, msg_id=2,
                bot_send_fn=lambda *a, **k: sends.append(a),
                bot_edit_fn=lambda *a, **k: edits.append(a),
                length=6, max_workers=2, lang="ua", db_dir=tmp)
        self.assertIsNone(res)
        self.assertEqual(edits, [])
        self.assertEqual(sends, [])


class SlotReservationLeak(unittest.TestCase):
    def test_expired_request_does_not_push_session_schedule(self):
        now = [1000.0]
        clock = lambda: now[0]
        settings = {"api_id": 1, "api_hash": "h", "sessions": ["s"], "interval": 1.0,
                    "max_wait": 5.0, "ttl_free": 600.0, "ttl_final": 600.0}

        class _Client:
            async def is_user_authorized(self): return True
            async def connect(self): pass
            async def __call__(self, req): return True

        v = tg_verify.TelegramVerifier(settings, client_factory=lambda ss: _Client(), clock=clock)
        loop = asyncio.new_event_loop()
        try:
            v._pick_lock = asyncio.Lock()
            loop.run_until_complete(v._connect_all())
            s = v._sessions[0]
            s.next_ok = 1010.0                      # сесія зайнята ще 10 с
            before = s.next_ok
            picked = loop.run_until_complete(v._pick(deadline=1005.0))   # слот > deadline
            self.assertIsNotNone(picked)
            self.assertEqual(s.next_ok, before)      # бронь НЕ зсунулась
            picked = loop.run_until_complete(v._pick(deadline=1020.0))   # слот у межах deadline
            self.assertEqual(s.next_ok, before + 1.0)
        finally:
            loop.close()


if __name__ == "__main__":
    unittest.main(verbosity=2)
