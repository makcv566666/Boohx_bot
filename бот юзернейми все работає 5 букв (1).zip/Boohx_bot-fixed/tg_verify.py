"""
tg_verify.py — авторитетна перевірка юзернейма через MTProto (Telethon).

Єдине джерело правди для слова «вільний» у всьому боті:

    verify_username_telegram(nick) -> "free" | "taken" | "invalid" | "fragment" | "error"

  free      account.checkUsername повернув True: нік реально можна встановити
  taken     USERNAME_OCCUPIED (або USERNAME_NOT_MODIFIED — нік уже на самій сесії)
  invalid   USERNAME_INVALID — заборонений / невалідний
  fragment  USERNAME_PURCHASE_AVAILABLE — продається на Fragment, не «вільний»
  error     не вдалося визначити (немає сесії, FloodWait довший за ліміт,
            мережа, мертва сесія …). НІКОЛИ не трактується як «вільний».

Конфігурація (змінні середовища мають пріоритет над bot_config.txt):
    API_ID, API_HASH
    SESSION_STRING                    — одна сесія
    SESSION_STRINGS                   — кілька сесій (через кому / пробіл / новий рядок)
    SESSION_STRING_2, SESSION_STRING_3, …  — додаткові сесії
    TG_VERIFY_INTERVAL   (сек, за замовч. 1.0)   — мінімальний інтервал між запитами на сесію
    TG_VERIFY_MAX_WAIT   (сек, за замовч. 120)   — скільки максимум чекати одну перевірку
    TG_VERIFY_TTL_FREE   (сек, за замовч. 600)   — TTL кешу для «free»
    TG_VERIFY_TTL_FINAL  (сек, за замовч. 604800)— TTL кешу для taken/invalid/fragment

Telethon асинхронний, а бот — на потоках. Тому всі клієнти живуть в одному
фоновому asyncio-loop, а verify_username_telegram() — звичайна блокуюча функція,
яку можна викликати з будь-якого потоку.
"""

from __future__ import annotations

import asyncio
import logging
import os
import re
import threading
import time
from typing import Dict, List, Optional, Tuple

logger = logging.getLogger("BOOHX_TGVerify")

FREE, TAKEN, INVALID, FRAGMENT, ERROR = "free", "taken", "invalid", "fragment", "error"
FINAL_STATUSES = (TAKEN, INVALID, FRAGMENT)

_NICK_RE = re.compile(r"[a-z][a-z0-9_]{3,31}")


# ══════════════════════════════════════════════════════════════════════════════
# Конфігурація
# ══════════════════════════════════════════════════════════════════════════════

def _read_cfg_file(base_dir: str) -> Dict[str, str]:
    cfg: Dict[str, str] = {}
    path = os.path.join(base_dir, "bot_config.txt")
    if not os.path.exists(path):
        return cfg
    try:
        with open(path, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                k, v = line.split("=", 1)
                cfg[k.strip()] = v.strip()
    except OSError:
        pass
    return cfg


def load_settings(base_dir: Optional[str] = None,
                  env: Optional[Dict[str, str]] = None,
                  cfg: Optional[Dict[str, str]] = None) -> Dict:
    """Збирає налаштування з env + bot_config.txt. env/cfg можна підмінити в тестах."""
    base_dir = base_dir or os.path.dirname(os.path.abspath(__file__))
    env = os.environ if env is None else env
    cfg = _read_cfg_file(base_dir) if cfg is None else cfg

    def get(key: str, default: str = "") -> str:
        return (env.get(key) or cfg.get(key) or default).strip()

    sessions: List[str] = []
    for raw in re.split(r"[,\s;]+", get("SESSION_STRINGS")):
        if raw:
            sessions.append(raw)
    if get("SESSION_STRING"):
        sessions.append(get("SESSION_STRING"))
    for i in range(2, 21):
        s = get(f"SESSION_STRING_{i}")
        if s:
            sessions.append(s)
    sessions = list(dict.fromkeys(sessions))  # унікальні, зберігаємо порядок

    try:
        api_id = int(get("API_ID") or 0)
    except ValueError:
        api_id = 0

    def f(key: str, default: float) -> float:
        try:
            return float(get(key) or default)
        except ValueError:
            return default

    return {
        "api_id": api_id,
        "api_hash": get("API_HASH"),
        "sessions": sessions,
        "interval": max(0.2, f("TG_VERIFY_INTERVAL", 1.0)),
        "max_wait": max(1.0, f("TG_VERIFY_MAX_WAIT", 120.0)),
        "ttl_free": f("TG_VERIFY_TTL_FREE", 600.0),
        "ttl_final": f("TG_VERIFY_TTL_FINAL", 7 * 86400.0),
    }


# ══════════════════════════════════════════════════════════════════════════════
# Класифікація відповідей Telethon (за ім'ям класу / RPC-повідомленням,
# щоб не залежати від того, які саме класи є у встановленій версії Telethon)
# ══════════════════════════════════════════════════════════════════════════════

def _err_names(e: BaseException) -> str:
    names = [c.__name__ for c in type(e).__mro__]
    names.append(str(getattr(e, "message", "") or ""))
    names.append(str(e))
    return " ".join(names).upper().replace("_", "")


def classify_exception(e: BaseException) -> Tuple[str, Optional[float]]:
    """
    Повертає (kind, flood_seconds).
    kind: 'taken' | 'invalid' | 'fragment' | 'flood' | 'dead_session' | 'error'
    """
    n = _err_names(e)
    # Порядок важливий: PURCHASEAVAILABLE перевіряємо до OCCUPIED/INVALID
    if "USERNAMEPURCHASEAVAILABLE" in n:
        return "fragment", None
    if "USERNAMEOCCUPIED" in n or "USERNAMENOTMODIFIED" in n:
        return "taken", None
    if "USERNAMEINVALID" in n:
        return "invalid", None
    if "FLOODWAIT" in n or "FLOODPREMIUMWAIT" in n:
        secs = getattr(e, "seconds", None)
        if secs is None:
            m = re.search(r"(\d+)", str(e))
            secs = int(m.group(1)) if m else 30
        return "flood", float(secs)
    if any(x in n for x in ("AUTHKEYUNREGISTERED", "SESSIONREVOKED", "SESSIONEXPIRED",
                            "USERDEACTIVATED", "AUTHKEYDUPLICATED", "AUTHKEYINVALID")):
        return "dead_session", None
    return "error", None


# ══════════════════════════════════════════════════════════════════════════════
# Одна сесія: rate-limit + FloodWait
# ══════════════════════════════════════════════════════════════════════════════

class _Session:
    def __init__(self, idx: int, client, interval: float):
        self.idx = idx
        self.client = client
        self.interval = interval
        self.next_ok = 0.0        # monotonic: раніше цього часу запит не шлемо
        self.blocked_until = 0.0  # monotonic: FloodWait
        self.dead = False

    def ready_at(self) -> float:
        return max(self.next_ok, self.blocked_until)


class TelegramVerifier:
    """Пул Telethon-сесій з ротацією, лімітом частоти та коректним FloodWait."""

    def __init__(self, settings: Dict, client_factory=None, clock=time.monotonic):
        self.api_id = settings["api_id"]
        self.api_hash = settings["api_hash"]
        self.session_strings: List[str] = list(settings["sessions"])
        self.interval = settings["interval"]
        self.max_wait = settings["max_wait"]
        self._factory = client_factory       # для тестів
        self._clock = clock
        self._sessions: List[_Session] = []
        self._loop: Optional[asyncio.AbstractEventLoop] = None
        self._thread: Optional[threading.Thread] = None
        self._start_lock = threading.Lock()
        self._started = False
        self._pick_lock: Optional[asyncio.Lock] = None
        self._sleep = asyncio.sleep          # підміняється в тестах

    # ── Стан ──────────────────────────────────────────────────────────────────
    def is_configured(self) -> bool:
        if not self.session_strings:
            return False
        if self._factory is not None:
            return True
        return bool(self.api_id and self.api_hash)

    def sessions_alive(self) -> int:
        return sum(1 for s in self._sessions if not s.dead)

    def cooldown_remaining(self) -> float:
        """Скільки секунд до моменту, коли хоч одна сесія знову зможе робити запит."""
        live = [s for s in self._sessions if not s.dead]
        if not live:
            return 0.0
        now = self._clock()
        return max(0.0, min(s.ready_at() for s in live) - now)

    # ── Запуск loop ───────────────────────────────────────────────────────────
    def _ensure_started(self) -> bool:
        if self._started:
            return bool(self._sessions)
        with self._start_lock:
            if self._started:
                return bool(self._sessions)
            ready = threading.Event()

            def _run():
                self._loop = asyncio.new_event_loop()
                asyncio.set_event_loop(self._loop)
                self._pick_lock = asyncio.Lock()
                ready.set()
                self._loop.run_forever()

            self._thread = threading.Thread(target=_run, name="tg-verify-loop", daemon=True)
            self._thread.start()
            ready.wait(5)
            fut = asyncio.run_coroutine_threadsafe(self._connect_all(), self._loop)
            try:
                fut.result(timeout=60)
            except Exception as e:  # noqa: BLE001
                logger.error("[TG_VERIFY] Не вдалося підключити сесії: %s", e)
            self._started = True
            return bool(self._sessions)

    async def _connect_all(self):
        for i, ss in enumerate(self.session_strings):
            try:
                if self._factory is not None:
                    client = self._factory(ss)
                else:
                    from telethon import TelegramClient
                    from telethon.sessions import StringSession
                    client = TelegramClient(StringSession(ss), self.api_id, self.api_hash,
                                            receive_updates=False)
                await client.connect()
                if hasattr(client, "is_user_authorized"):
                    ok = await client.is_user_authorized()
                    if not ok:
                        logger.error("[TG_VERIFY] Сесія #%d не авторизована — пропускаю", i + 1)
                        continue
                self._sessions.append(_Session(i, client, self.interval))
            except Exception as e:  # noqa: BLE001
                logger.error("[TG_VERIFY] Сесія #%d не підключилась: %s", i + 1, e)
        logger.info("[TG_VERIFY] Активних сесій: %d/%d", len(self._sessions), len(self.session_strings))

    # ── Публічна синхронна функція ───────────────────────────────────────────
    def verify(self, nick: str, max_wait: Optional[float] = None) -> str:
        max_wait = self.max_wait if max_wait is None else max_wait
        nick = (nick or "").strip().lower().lstrip("@")
        if not _NICK_RE.fullmatch(nick):
            return INVALID
        if not self.is_configured():
            return ERROR
        if not self._ensure_started():
            return ERROR
        try:
            fut = asyncio.run_coroutine_threadsafe(
                self._verify_async(nick, max_wait), self._loop)
            return fut.result(timeout=max_wait + 30)
        except Exception as e:  # noqa: BLE001
            logger.warning("[TG_VERIFY] @%s: збій виклику: %s", nick, e)
            return ERROR

    # ── Основна логіка ────────────────────────────────────────────────────────
    async def _pick(self, deadline: Optional[float] = None) -> Optional[Tuple[_Session, float]]:
        """Вибирає живу сесію, готову найраніше, і резервує їй слот. → (сесія, час слоту).

        Якщо слот випадає ПІСЛЯ deadline, його НЕ резервуємо: виклик усе одно
        завершиться помилкою, а «прострочена» бронь зсувала б розклад сесії вперед
        і змушувала б наступні виклики теж отримувати помилку при простаюючій сесії.
        """
        async with self._pick_lock:
            live = [s for s in self._sessions if not s.dead]
            if not live:
                return None
            s = min(live, key=lambda x: x.ready_at())
            start = max(self._clock(), s.ready_at())
            if deadline is not None and start > deadline:
                return s, start               # без резервації — викликач віддасть ERROR
            s.next_ok = start + s.interval    # резервуємо слот до відправки
            return s, start

    async def _verify_async(self, nick: str, max_wait: float) -> str:
        deadline = self._clock() + max_wait
        while True:
            picked = await self._pick(deadline)
            if picked is None:
                return ERROR
            s, slot_at = picked
            if slot_at > deadline:
                # усі сесії у FloodWait довше за ліміт — не вигадуємо «free»
                return ERROR
            wait = slot_at - self._clock()
            if wait > 0:
                await self._sleep(wait)

            try:
                res = await s.client(self._request(nick))
            except Exception as e:  # noqa: BLE001
                kind, secs = classify_exception(e)
                if kind == "taken":
                    return TAKEN
                if kind == "invalid":
                    return INVALID
                if kind == "fragment":
                    return FRAGMENT
                if kind == "flood":
                    s.blocked_until = self._clock() + secs + 1.0
                    logger.warning("[TG_VERIFY] FloodWait %ss на сесії #%d", int(secs), s.idx + 1)
                    continue   # інша сесія або чекаємо, але ніколи не «free»
                if kind == "dead_session":
                    s.dead = True
                    logger.error("[TG_VERIFY] Сесія #%d мертва (%s)", s.idx + 1, type(e).__name__)
                    continue
                logger.warning("[TG_VERIFY] @%s: %s: %s", nick, type(e).__name__, e)
                return ERROR

            # Telegram повертає Bool
            if res is True:
                return FREE
            if res is False:
                # Bool false у відповіді account.checkUsername = нік недоступний
                return TAKEN
            return ERROR

    def _request(self, nick: str):
        if self._factory is not None:      # тестовий режим: Telethon не потрібен
            from types import SimpleNamespace
            return SimpleNamespace(username=nick)
        from telethon.tl import functions
        return functions.account.CheckUsernameRequest(username=nick)

    def close(self):
        if not self._loop:
            return

        async def _bye():
            for s in self._sessions:
                try:
                    await s.client.disconnect()
                except Exception:  # noqa: BLE001
                    pass

        try:
            asyncio.run_coroutine_threadsafe(_bye(), self._loop).result(timeout=10)
        except Exception:  # noqa: BLE001
            pass
        self._loop.call_soon_threadsafe(self._loop.stop)


# ══════════════════════════════════════════════════════════════════════════════
# Глобальний екземпляр + TTL-кеш вердиктів
# ══════════════════════════════════════════════════════════════════════════════

_VERIFIER: Optional[TelegramVerifier] = None
_SETTINGS: Optional[Dict] = None
_INIT_LOCK = threading.Lock()

_VERDICTS: Dict[str, Tuple[str, float]] = {}   # nick -> (status, expires_at)
_VERDICT_LOCK = threading.Lock()


def configure(base_dir: Optional[str] = None, settings: Optional[Dict] = None,
              verifier: Optional[TelegramVerifier] = None) -> TelegramVerifier:
    """Явна ініціалізація (main.py викликає на старті). Для тестів можна підсунути verifier."""
    global _VERIFIER, _SETTINGS
    with _INIT_LOCK:
        _SETTINGS = settings or load_settings(base_dir)
        _VERIFIER = verifier or TelegramVerifier(_SETTINGS)
        with _VERDICT_LOCK:
            _VERDICTS.clear()
        return _VERIFIER


def _get() -> TelegramVerifier:
    global _VERIFIER
    if _VERIFIER is None:
        configure()
    return _VERIFIER  # type: ignore[return-value]


def is_configured() -> bool:
    return _get().is_configured()


def cooldown_remaining() -> float:
    return _get().cooldown_remaining()


def settings() -> Dict:
    _get()
    return _SETTINGS or {}


def verify_username_telegram(nick: str, use_cache: bool = True,
                             max_wait: Optional[float] = None) -> str:
    """
    ФІНАЛЬНА авторитетна перевірка. Повертає 'free'|'taken'|'invalid'|'fragment'|'error'.
    'error' (включно з відсутньою сесією) ніколи не означає «вільний».
    """
    nick = (nick or "").strip().lower().lstrip("@")
    if not _NICK_RE.fullmatch(nick):
        return INVALID

    st = _SETTINGS or {}
    now = time.time()
    if use_cache:
        with _VERDICT_LOCK:
            hit = _VERDICTS.get(nick)
            if hit and hit[1] > now:
                return hit[0]

    v = _get()
    status = v.verify(nick, max_wait=max_wait)

    if status != ERROR:
        ttl = (st.get("ttl_free", 600.0) if status == FREE
               else st.get("ttl_final", 7 * 86400.0))
        with _VERDICT_LOCK:
            _VERDICTS[nick] = (status, now + ttl)
    return status
