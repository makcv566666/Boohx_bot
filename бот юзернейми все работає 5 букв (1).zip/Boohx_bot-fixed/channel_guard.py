"""
channel_guard.py — Модуль перевірки підписки на канал для BOOHX бота.

Логіка:
  1. Якщо user_id є у WHITELIST → одразу пропускаємо, жодних перевірок.
  2. Інакше → перевіряємо підписку через Telegram API (до 3 спроб з паузою).
  3. Кешуємо результат на 60 секунд, щоб не спамити API.
  4. Якщо API недоступний після всіх спроб → повертаємо UNKNOWN,
     і в цьому випадку бот пропускає користувача (fail-open),
     щоб адмін та інші підписані не застрягали.
"""

import time
import logging
import threading
from typing import Optional

logger = logging.getLogger("BOOHX_ChannelGuard")

# ── Налаштування ──────────────────────────────────────────────────────────────

REQUIRED_CHANNEL: str = "@boohx"

# Час кешування результату (секунди)
CACHE_TTL_SEC: int = 60

# Кількість повторних спроб при помилці API
MAX_RETRIES: int = 3

# Пауза між спробами (секунди)
RETRY_DELAY_SEC: float = 1.0

# ── Вайтліст ──────────────────────────────────────────────────────────────────
# Ці ID завжди проходять без перевірки (власник + адміни).
# Заповнюється під час init_guard() з OWNER_ID та bot_config.txt → WHITELIST_IDS

_whitelist: set[int] = set()
_whitelist_lock = threading.Lock()


def init_guard(owner_id: int, extra_ids: Optional[list[int]] = None) -> None:
    """Викликати ОДИН РАЗ при старті бота після зчитування конфігу.

    owner_id   — значення OWNER_ID з bot_config.txt / env
    extra_ids  — додаткові ID з поля WHITELIST_IDS у bot_config.txt
    """
    with _whitelist_lock:
        _whitelist.clear()
        _whitelist.add(owner_id)
        if extra_ids:
            for uid in extra_ids:
                _whitelist.add(uid)
    logger.info(
        "[ChannelGuard] Ініціалізовано. Вайтліст: %s",
        sorted(_whitelist),
    )


def is_whitelisted(user_id: int) -> bool:
    """True якщо user_id у вайтліст — перевірку підписки пропускаємо."""
    with _whitelist_lock:
        return user_id in _whitelist


# ── Кеш результатів ───────────────────────────────────────────────────────────

_cache: dict[int, tuple[bool, float]] = {}   # {user_id: (is_subscribed, expire_ts)}
_cache_lock = threading.Lock()


def _cache_get(user_id: int) -> Optional[bool]:
    with _cache_lock:
        entry = _cache.get(user_id)
        if entry is None:
            return None
        subscribed, expire_ts = entry
        if time.time() > expire_ts:
            del _cache[user_id]
            return None
        return subscribed


def _cache_set(user_id: int, subscribed: bool) -> None:
    with _cache_lock:
        _cache[user_id] = (subscribed, time.time() + CACHE_TTL_SEC)


def invalidate_cache(user_id: int) -> None:
    """Примусово скидає кеш для користувача (наприклад, після натискання кнопки)."""
    with _cache_lock:
        _cache.pop(user_id, None)


# ── Основна перевірка ─────────────────────────────────────────────────────────

# Статуси Telegram, що означають «є в каналі»
_MEMBER_STATUSES = {"member", "administrator", "creator"}


def check_subscription(bot, user_id: int) -> Optional[bool]:
    """Перевіряє підписку через Telegram API.

    Повертає:
      True  — підписаний
      False — НЕ підписаний (явно «left» або «kicked»)
      None  — не вдалося перевірити (API недоступний / бот не адмін каналу)
    """
    # 1. Вайтліст — одразу True без будь-яких запитів до API
    if is_whitelisted(user_id):
        logger.debug("[ChannelGuard] uid=%s у вайтліст, пропускаємо.", user_id)
        return True

    # 2. Перевіряємо кеш
    cached = _cache_get(user_id)
    if cached is not None:
        logger.debug("[ChannelGuard] uid=%s — результат з кешу: %s", user_id, cached)
        return cached

    # 3. Запит до Telegram API (з повторними спробами)
    last_exc = None
    for attempt in range(1, MAX_RETRIES + 1):
        try:
            member = bot.get_chat_member(REQUIRED_CHANNEL, user_id)
            subscribed = member.status in _MEMBER_STATUSES
            _cache_set(user_id, subscribed)
            logger.info(
                "[ChannelGuard] uid=%s → статус=%s підписаний=%s (спроба %d)",
                user_id, member.status, subscribed, attempt,
            )
            return subscribed
        except Exception as exc:
            last_exc = exc
            logger.warning(
                "[ChannelGuard] uid=%s — помилка API (спроба %d/%d): %s",
                user_id, attempt, MAX_RETRIES, exc,
            )
            if attempt < MAX_RETRIES:
                time.sleep(RETRY_DELAY_SEC)

    logger.error(
        "[ChannelGuard] uid=%s — не вдалося перевірити після %d спроб. "
        "Остання помилка: %s. Підказка: додайте бота як адміністратора каналу %s.",
        user_id, MAX_RETRIES, last_exc, REQUIRED_CHANNEL,
    )
    return None   # невідомо


# ── Надсилання повідомлення-запиту ────────────────────────────────────────────

def send_subscribe_prompt(bot, chat_id: int, lang: str) -> None:
    """Надсилає красиве повідомлення з кнопками: перейти на канал + перевірити."""
    from telebot import types   # імпорт тут, щоб модуль не залежав від telebot глобально

    channel_url = f"https://t.me/{REQUIRED_CHANNEL.lstrip('@')}"

    texts = {
        "ua": (
            "📢 *Доступ до BOOHX*\n\n"
            f"Щоб користуватися ботом, підпишіться на наш канал:\n"
            f"👉 {REQUIRED_CHANNEL}\n\n"
            "Після підписки натисніть *«✅ Перевірити підписку»* нижче."
        ),
        "ru": (
            "📢 *Доступ к BOOHX*\n\n"
            f"Чтобы пользоваться ботом, подпишитесь на наш канал:\n"
            f"👉 {REQUIRED_CHANNEL}\n\n"
            "После подписки нажмите *«✅ Проверить подписку»* ниже."
        ),
        "en": (
            "📢 *Access to BOOHX*\n\n"
            f"To use the bot, subscribe to our channel:\n"
            f"👉 {REQUIRED_CHANNEL}\n\n"
            "After subscribing, press *«✅ Check subscription»* below."
        ),
    }

    btn_channel = {
        "ua": f"📢 Підписатись на {REQUIRED_CHANNEL}",
        "ru": f"📢 Подписаться на {REQUIRED_CHANNEL}",
        "en": f"📢 Subscribe to {REQUIRED_CHANNEL}",
    }
    btn_check = {
        "ua": "✅ Перевірити підписку",
        "ru": "✅ Проверить подписку",
        "en": "✅ Check subscription",
    }

    l = lang if lang in texts else "ua"

    kb = types.InlineKeyboardMarkup(row_width=1)
    kb.add(
        types.InlineKeyboardButton(
            btn_channel[l],
            url=channel_url,
        ),
        types.InlineKeyboardButton(
            btn_check[l],
            callback_data=f"sub_check_{l}",
        ),
    )

    bot.send_message(
        chat_id,
        texts[l],
        reply_markup=kb,
        parse_mode="Markdown",
    )


def handle_check_callback(bot, call, open_main_menu_fn) -> None:
    """Обробляє натискання кнопки «Перевірити підписку».

    bot              — екземпляр telebot.TeleBot
    call             — об'єкт CallbackQuery
    open_main_menu_fn — функція (chat_id, lang) → None, яка відкриває головне меню
    """
    from telebot import types   # noqa

    lang = call.data.split("_")[-1]
    if lang not in ("ua", "ru", "en"):
        lang = "ua"

    uid      = call.from_user.id
    chat_id  = call.message.chat.id
    msg_id   = call.message.message_id

    # Скидаємо кеш, щоб отримати свіжий результат
    invalidate_cache(uid)

    result = check_subscription(bot, uid)

    # ── Підписаний або вайтліст ──
    if result is True:
        bot.answer_callback_query(call.id, "✅")
        try:
            bot.delete_message(chat_id, msg_id)
        except Exception:
            pass
        open_main_menu_fn(chat_id, lang)
        return

    # ── Не підписаний ──
    if result is False:
        not_yet = {
            "ua": f"❌ Ви ще не підписані на {REQUIRED_CHANNEL}.\nПідпишіться і спробуйте ще раз!",
            "ru": f"❌ Вы ещё не подписаны на {REQUIRED_CHANNEL}.\nПодпишитесь и попробуйте снова!",
            "en": f"❌ You are not subscribed to {REQUIRED_CHANNEL} yet.\nPlease subscribe and try again!",
        }
        bot.answer_callback_query(call.id, not_yet[lang], show_alert=True)
        return

    # ── result is None → API не відповідає, пропускаємо (fail-open) ──
    logger.warning("[ChannelGuard] uid=%s — API недоступний, пропускаємо (fail-open).", uid)
    bot.answer_callback_query(call.id, "✅")
    try:
        bot.delete_message(chat_id, msg_id)
    except Exception:
        pass
    open_main_menu_fn(chat_id, lang)
