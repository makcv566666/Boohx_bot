"""
make_session.py — одноразовий вхід в акаунт для перевірки ніків (Telethon).

Запуск:  python make_session.py

Два способи входу:
  1) QR-код (РЕКОМЕНДОВАНО — код з повідомлення не потрібен):
     Telegram на телефоні → Налаштування → Пристрої → Підключити пристрій
     → наведіть камеру на QR, який покаже скрипт.
  2) Номер телефону + код. Код приходить НЕ по SMS, а повідомленням у самому
     Telegram від чату «Telegram» (service notifications) на пристрої, де ви
     вже залогінені. SMS приходить, тільки якщо активних пристроїв немає.

Результат зберігається у файли — шукати нічого не треба:
  • session_string.txt  (поруч зі скриптом)
  • bot_config.txt      (рядки API_ID / API_HASH / SESSION_STRING оновляться самі)

⚠️ SESSION_STRING = повний доступ до акаунта. Не комітьте і нікому не показуйте.
Краще використовувати окремий акаунт.
"""

import asyncio
import getpass
import os
import re
import sys

try:
    from telethon import TelegramClient
    from telethon.errors import SessionPasswordNeededError
    from telethon.sessions import StringSession
except ImportError:
    sys.exit("Встановіть залежності:  pip install -r requirements.txt")

BASE = os.path.dirname(os.path.abspath(__file__))


def _ask(prompt, env="", secret=False):
    val = os.environ.get(env, "").strip() if env else ""
    if val:
        return val
    return (getpass.getpass(prompt) if secret else input(prompt)).strip()


def _save(api_id, api_hash, session):
    path = os.path.join(BASE, "session_string.txt")
    with open(path, "w", encoding="utf-8") as f:
        f.write(session + "\n")

    cfg = os.path.join(BASE, "bot_config.txt")
    lines = []
    if os.path.exists(cfg):
        with open(cfg, encoding="utf-8", newline="") as f:
            lines = f.read().splitlines()
    vals = {"API_ID": str(api_id), "API_HASH": api_hash, "SESSION_STRING": session}
    done = set()
    for i, line in enumerate(lines):
        m = re.match(r"\s*([A-Z_]+)\s*=", line)
        if m and m.group(1) in vals:
            lines[i] = f"{m.group(1)}={vals[m.group(1)]}"
            done.add(m.group(1))
    for k, v in vals.items():
        if k not in done:
            lines.append(f"{k}={v}")
    with open(cfg, "w", encoding="utf-8", newline="") as f:
        f.write("\r\n".join(lines) + "\r\n")
    return path, cfg


async def _password_step(client):
    pwd = getpass.getpass("Пароль двоетапної перевірки (2FA): ")
    await client.sign_in(password=pwd)


async def login_qr(client):
    try:
        import qrcode
    except ImportError:
        qrcode = None
    print("\nУ Telegram на телефоні: Налаштування → Пристрої → Підключити пристрій")
    print("і скануйте QR нижче. Він оновлюється кожні ~30 с.\n")
    while True:
        qr = await client.qr_login()
        if qrcode:
            q = qrcode.QRCode(border=1)
            q.add_data(qr.url)
            q.print_ascii(invert=True)
        else:
            print("(Для показу QR у консолі: pip install qrcode)")
            print("Посилання для QR:", qr.url)
        try:
            await qr.wait(timeout=30)
            return
        except asyncio.TimeoutError:
            print("QR застарів, генерую новий…")
        except SessionPasswordNeededError:
            await _password_step(client)
            return


async def login_phone(client):
    phone = input("Номер телефону (з +, напр. +380501234567): ").strip()
    sent = await client.send_code_request(phone)
    kind = type(getattr(sent, "type", None)).__name__
    print(f"\nТип доставки коду: {kind}")
    print("Шукайте код у САМОМУ Telegram — чат «Telegram» (синя галочка) на вашому")
    print("телефоні/ПК, а не в SMS. Якщо не прийшов — введіть  r  для повторної відправки.")
    while True:
        code = input("Код (або r — надіслати ще раз): ").strip().replace(" ", "")
        if code.lower() == "r":
            sent = await client.send_code_request(phone)
            print("Надіслано повторно:", type(getattr(sent, "type", None)).__name__)
            continue
        try:
            await client.sign_in(phone, code, phone_code_hash=sent.phone_code_hash)
        except SessionPasswordNeededError:
            await _password_step(client)
        return


async def main():
    api_id = int(_ask("API_ID: ", "API_ID"))
    api_hash = _ask("API_HASH: ", "API_HASH")
    client = TelegramClient(StringSession(), api_id, api_hash)
    await client.connect()

    mode = input("Вхід: 1 — QR-код (рекомендовано), 2 — номер + код [1]: ").strip() or "1"
    if mode == "2":
        await login_phone(client)
    else:
        await login_qr(client)

    me = await client.get_me()
    session = client.session.save()
    await client.disconnect()

    sfile, cfg = _save(api_id, api_hash, session)
    print("\n✅ Увійшли як:", me.first_name, f"(@{me.username})" if me.username else "")
    print("\nСесію збережено автоматично:")
    print("  •", sfile)
    print("  •", cfg, "(API_ID / API_HASH / SESSION_STRING)")
    print("\nSESSION_STRING:\n" + session)
    print("\n⚠️ Не комітьте і нікому не показуйте цей рядок.")


if __name__ == "__main__":
    asyncio.run(main())
