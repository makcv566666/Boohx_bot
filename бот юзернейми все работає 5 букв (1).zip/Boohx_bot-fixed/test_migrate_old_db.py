# -*- coding: utf-8 -*-
import os
import sqlite3
import tempfile
import unittest

import migrate_old_db as m


def _mk_old(path):
    c = sqlite3.connect(path)
    c.executescript("""
    CREATE TABLE users (user_id INTEGER PRIMARY KEY, username TEXT, attempts INTEGER DEFAULT 10,
        is_premium INTEGER DEFAULT 0, premium_until REAL DEFAULT 0.0, referrals INTEGER DEFAULT 0,
        is_admin INTEGER DEFAULT 0, referrer_id INTEGER, registration_date TEXT, lang TEXT DEFAULT 'ua',
        total_scans INTEGER DEFAULT 0, last_scan_ts REAL DEFAULT 0.0, lang_chosen INTEGER DEFAULT 0,
        quiz_date TEXT DEFAULT '', quiz_count INTEGER DEFAULT 0, nick_style TEXT DEFAULT 'readable',
        nick_digits INTEGER DEFAULT 0, banned INTEGER DEFAULT 0, partner_percent INTEGER DEFAULT 0,
        nick_sell_price REAL DEFAULT 0.0);
    CREATE TABLE found_nicks (id INTEGER PRIMARY KEY AUTOINCREMENT, nick TEXT, length INTEGER, found_by INTEGER, found_at TEXT);
    CREATE TABLE known_taken_nicks (nick TEXT PRIMARY KEY, checked_at TEXT);
    INSERT INTO users (user_id,username,attempts,is_premium,premium_until,referrals,lang,total_scans,quiz_count)
        VALUES (1,'alice',7,1,1999999999.0,2,'ru',40,3), (2,'bob',10,0,0,0,'ua',0,0);
    INSERT INTO found_nicks (nick,length,found_by,found_at) VALUES ('kadumi',6,1,'2026-01-01');
    INSERT INTO known_taken_nicks VALUES ('taken1','2026-01-01');
    """)
    c.commit(); c.close()


def _mk_new(path):
    c = sqlite3.connect(path)
    c.executescript("""
    CREATE TABLE users (user_id INTEGER PRIMARY KEY, username TEXT, attempts INTEGER DEFAULT 10,
        is_premium INTEGER DEFAULT 0, premium_until REAL DEFAULT 0.0, referrals INTEGER DEFAULT 0,
        is_admin INTEGER DEFAULT 0, referrer_id INTEGER, registration_date TEXT, lang TEXT DEFAULT 'ua',
        total_scans INTEGER DEFAULT 0, last_scan_ts REAL DEFAULT 0.0);
    CREATE TABLE found_nicks (id INTEGER PRIMARY KEY AUTOINCREMENT, nick TEXT, length INTEGER, found_by INTEGER, found_at TEXT);
    INSERT INTO users (user_id,username,attempts) VALUES (1,'alice_fresh',10), (3,'carol',10);
    INSERT INTO found_nicks (nick,length,found_by,found_at) VALUES ('newnic',6,3,'2026-10-11');
    """)
    c.commit(); c.close()


class MigrateTests(unittest.TestCase):
    def setUp(self):
        self.d = tempfile.mkdtemp()
        self.old = os.path.join(self.d, "old.db")
        self.new = os.path.join(self.d, "new.db")
        _mk_old(self.old); _mk_new(self.new)

    def test_merge_rules(self):
        m.migrate(self.old, self.new)
        c = sqlite3.connect(self.new)
        rows = {r[0]: r for r in c.execute(
            "select user_id,username,attempts,is_premium,referrals,lang,total_scans,quiz_count from users")}
        self.assertEqual(set(rows), {1, 2, 3})                 # старі + унікальні нові
        self.assertEqual(rows[1][1:], ("alice", 7, 1, 2, "ru", 40, 3))   # конфлікт: стара база перемагає
        self.assertEqual(rows[3][1], "carol")                  # унікальний новий запис збережено
        nicks = sorted(r[0] for r in c.execute("select nick from found_nicks"))
        self.assertEqual(nicks, ["kadumi", "newnic"])
        tables = {r[0] for r in c.execute("select name from sqlite_master where type='table'")}
        self.assertNotIn("known_taken_nicks", tables)          # кеш перевірок НЕ переноситься

    def test_idempotent_and_backup(self):
        m.migrate(self.old, self.new)
        rep = m.migrate(self.old, self.new)
        self.assertIn("backup", rep)
        c = sqlite3.connect(self.new)
        self.assertEqual(c.execute("select count(*) from users").fetchone()[0], 3)
        self.assertEqual(c.execute("select count(*) from found_nicks").fetchone()[0], 2)

    def test_old_db_untouched(self):
        with open(self.old, "rb") as fh:
            before = fh.read()
        m.migrate(self.old, self.new)
        with open(self.old, "rb") as fh:
            self.assertEqual(before, fh.read())


if __name__ == "__main__":
    unittest.main()
