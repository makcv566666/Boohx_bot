"""Запуск: python test_five_letter.py — самоперевірка 5-літерного валідатора."""
import random
import os
os.environ["FILTER_5"] = "1"   # тестуємо режим із шаблонами
import five_letter as f

def main():
    # сміття відсікається
    for bad in ("gbkxk", "djwtq", "rjwfn", "iaigt", "aaabc", "ab1cd", "toolong", "bkxzy", "zxqwk"):
        assert f.score5(bad) == 0, bad
    # шаблони проходять
    assert f.kind5("tamat") == "pal" and f.kind5("tatat") == "abab"
    for good in ("zokel", "tarko", "avelo", "kaizo", "zorix", "bella", "karky", "luxor"):
        assert f.kind5(good) in ("tpl", "pal", "abab", "word"), good
        assert f.score5(good) >= 50, good
    # пул не вичерпується швидко: багато унікальних кандидатів
    rng = random.Random(0)
    uniq = set()
    for fam in f.FAMILIES5:
        for _ in range(3000):
            c = f.gen5(fam, rng)
            if c and len(c) == 5 and f.score5(c) >= 50 and not f.likely_taken(c):
                uniq.add(c)
    assert len(uniq) > 15000, len(uniq)
    # кожна родина щось видає
    for fam in f.FAMILIES5:
        if fam == "w5_word" and not any(z < 4.0 for z in f.WORDS.values()):
            continue                                # усі слова словника вважаються зайнятими
        assert any(f.score5(c or "") for c in (f.gen5(fam, rng) for _ in range(500))), fam
    # випадкове сміття проходить рідко (а те, що проходить, — вимовне)
    rnd = ["".join(rng.choice("abcdefghijklmnopqrstuvwxyz") for _ in range(5)) for _ in range(20000)]
    assert sum(1 for r in rnd if f.score5(r)) / len(rnd) < 0.05
    print("OK")

if __name__ == "__main__":
    main()
